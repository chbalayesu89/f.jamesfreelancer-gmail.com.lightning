({
   openModel: function(component, event, helper) {
      // for Display Model,set the "isOpen" attribute to "true"
      component.set("v.isOpen", true);
   },
    doInit: function(component, event, helper) {
      // This is doInit Method
      // ID from param
      var caseID='';
        
        caseID=component.get('v.recordId');
        console.log('ID is '+caseID);
        
      component.set("v.caseID", caseID);
   },
 
   closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
      component.set("v.isOpen", false);
   },
 
   saveRecord: function(component, event, helper) {
      // Display alert message on the click on the "Like and Close" button from Model Footer 
      // and set set the "isOpen" attribute to "False for close the model Box.
      var selectedValue = component.find("pick1").get("v.value");
       var selectedValue1= component.find("pick2").get("v.value");
     	var action = component.get("c.saveRec");
       var caseID = component.get("v.caseID");
       action.setParams({"status":selectedValue,"reason":selectedValue1,"caseID":caseID});
        action.setCallback(this, function(a) {
           // component.set("v.contacts", a.getReturnValue());
           console.log(a);
        });
        $A.enqueueAction(action);
      component.set("v.isOpen", false);
   },
})