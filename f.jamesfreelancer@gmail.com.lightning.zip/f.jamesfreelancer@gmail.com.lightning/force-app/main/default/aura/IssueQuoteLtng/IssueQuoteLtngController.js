({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        component.set("v.showSpinner",true);
        try{
            console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
            var action = component.get("c.getOpportunity");
            action.setParams({ recId : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.opp",response.getReturnValue());
                    console.log('opp: '+JSON.stringify(component.get("v.opp")));                  
                    component.set("v.showSpinner",false);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    savepsf : function(component,event,helper){
        console.log('save psf >> ');  
        // var mabox=component.find("ma").get("v.checked");
        // if(mabox){
        //     document.getElementById("errmsg").innerHTML='';
        var iqobj=component.get("v.iq");    
         console.log('iqobj: '+JSON.stringify(iqobj));
        
        if(!iqobj.Has_customer_already_accepted_the_quote__c && 
          iqobj.Select_a_date_for_the_follow_up_task__c==null){
            document.getElementById('followup_msg').innerHTML='Please select followup date';
        }        
		
        if((!iqobj.Has_customer_already_accepted_the_quote__c &&
           iqobj.Select_a_date_for_the_follow_up_task__c!=null) || 
           iqobj.Has_customer_already_accepted_the_quote__c){ 
        if(iqobj.Referral_Contact__c!=null)
            iqobj.Referral_Contact__c=''+iqobj.Referral_Contact__c;
        if(iqobj.Referral_Account__c!=null)
            iqobj.Referral_Account__c=''+iqobj.Referral_Account__c;
        if(iqobj.Referral_Campaign__c!=null)
            iqobj.Referral_Campaign__c=''+iqobj.Referral_Campaign__c;
        component.set("v.iq",iqobj);
        console.log('iq:'+JSON.stringify(component.get("v.iq")));
        var action = component.get("c.saveIssueQuote");
        action.setParams({ oppId : component.get("v.recordId"),iq:component.get("v.iq"),p_opp:component.get("v.opp") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            component.set("v.isFollowupModalOpen",false);
             $A.get("e.force:closeQuickAction").fire();
            if (state === "SUCCESS") {
                var iq=response.getReturnValue();
                if(iq!=null){
                    component.set("v.iq",iq);                    
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+component.get("v.iq").Id
                    });
                    urlEvent.fire();
                    //   }else{
                    //     document.getElementById("errmsg").innerHTL='';     	  
                }
            }
        });
        $A.enqueueAction(action);
        }       
        
    },
    cancel : function(component,event,helper){      
        /*  var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": "/"+component.get("v.recordId")
                        });
                        urlEvent.fire();*/
        $A.get("e.force:closeQuickAction").fire();
    },
    enablesavebtn : function(component,event,helper){
        console.log('----------enablesavebtn-------');
        
        //console.log('>>> enable save button >>>');
        var iq=component.get("v.iq");  
        
        console.log('iq: '+JSON.stringify(iq));
        if(iq.Referral_Partner_Amount__c=='' || iq.Referral_Partner_Amount__c==null){
            iq.Referral_Partner_Amount__c=0;
        }
        if(iq.Other_Supplier_Costs__c=='' || iq.Other_Supplier_Costs__c==null){  
            iq.Other_Supplier_Costs__c=0;
        }
        //do calculations
        iq.TotalCost__c=parseFloat(iq.Referral_Partner_Amount__c)+parseFloat(iq.Other_Supplier_Costs__c);
        
        //calculate total quote
        if(iq.Total_Price__c==null || iq.Total_Price__c==''){
            iq.Total_Price__c=0;
        }        
        //set quotegrossprofilt__c   
        iq.QuoteGrossProfit__c=iq.Total_Price__c-iq.TotalCost__c;   
        component.set("v.iq",iq);
        
        if(iq.B1_Consultant__c!='' && iq.B1_Consultant__c!=null &&
           iq.B1_Percentage__c!='' && iq.B1_Percentage__c!=null &&
           iq.B2_Consultant__c!='' && iq.B2_Consultant__c!=null &&
           iq.B2_Percentage__c!='' && iq.B2_Percentage__c!=null &&
           iq.A_Consultant__c!='' && iq.A_Consultant__c!=null &&
           iq.A_Percentage__c!='' && iq.A_Percentage__c!=null &&
           iq.C_Consultant__c!='' && iq.C_Consultant__c!=null &&
           iq.C_Percentage__c!='' && iq.C_Percentage__c!=null            
          ){
            document.getElementById('msg').innerHTML='';
            component.find("savebtn").set("v.disabled",false);
          //  var sum=parseFloat(iq.B1_Percentage__c)+parseFloat(iq.B2_Percentage__c);
            // component.set("v.iq",iq);
            // console.log('sum: '+sum);
          /*  if(sum>40){
                document.getElementById('msg').innerHTML='Sum of B1 and B2 could not exceed 40';
                component.find("savebtn").set("v.disabled",true);
            }
            else{            
                document.getElementById('msg').innerHTML='';
                component.find("savebtn").set("v.disabled",false);
            } */
        }else{
            document.getElementById('msg').innerHTML='Please fill required fields';
            component.find("savebtn").set("v.disabled",true);
        }
        
    },
    enablefollowup:function(component,event,helper){
         var iq=component.get("v.iq");    
        var option=event.getParam("value");
        console.log('option: '+option);
        if(option=='Yes'){
             iq.Has_customer_already_accepted_the_quote__c=true; 
            component.set("v.iq",iq);                                                                
            component.set("v.showfollowup",false);
        }else{
             iq.Has_customer_already_accepted_the_quote__c=false;  
            component.set("v.iq",iq);                                                
            component.set("v.showfollowup",true);
        }   
        console.log('iq:'+JSON.stringify(component.get("v.iq")));
    }
    , toggleSection : function(component, event, helper) {
        try{
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
        }catch(err){
            console.log(''+err.stack);
        }
    },
     closeModel: function(component, event, helper) {
      // Set isFollowupModalOpen attribute to false  
      component.set("v.isFollowupModalOpen", false);
   },
  
   submitDetails: function(component, event, helper) {
      // Set isFollowupModalOpen attribute to false
      //Add your code to call apex method or do some processing
       console.log('submitDetails >> iq:'+JSON.stringify(component.get("v.iq")));
      component.set("v.isFollowupModalOpen", true);
   },
})