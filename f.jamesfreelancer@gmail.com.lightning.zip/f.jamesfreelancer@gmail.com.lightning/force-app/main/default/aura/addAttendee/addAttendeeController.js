({
    AddNewRow : function(component, event, helper){
       // fire the AddNewRowEvt Lightning Event 
        component.getEvent("attendeeAddNewRowEvt").fire();     
    },
    
    removeRow : function(component, event, helper){
     // fire the DeleteRowEvt Lightning Event and pass the deleted Row Index to Event parameter/attribute
       component.getEvent("attendeeDeleteRowEvt").setParams({"indexVar" : component.get("v.rowIndex") }).fire();
        component.getEvent("attendeeRowChangeEvt").fire();     
    }, 
    
    rowChanged : function(component,event,helper){
        component.getEvent("attendeeRowChangeEvt").fire();     
    }
})