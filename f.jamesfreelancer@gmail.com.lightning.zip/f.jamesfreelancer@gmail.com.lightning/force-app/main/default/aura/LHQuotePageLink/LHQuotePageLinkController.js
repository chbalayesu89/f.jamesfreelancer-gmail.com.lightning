({
	myAction : function(component, event, helper) {
		
	},
     doInit :function(component,event,helper){    
        var recordID = component.get("v.recordId");
        //alert(recordID);
        var action = component.get("c.getOpportunityId");
        action.setParams({ p_recordId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.oppId",response.getReturnValue());
                var oppId=component.get("v.oppId");
                //alert(recordID);
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/apex/LHGlobalQoute?Id="+oppId+"&QId="+recordID
                    });
                    urlEvent.fire();                   
                }
        });
        $A.enqueueAction(action);
    }
})