({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
  console.log('doInit success');       
        var flist=[];
        var recordId=component.get("v.recordId");
        console.log('recordId: '+recordId);
        try{
        if(recordId==null){
            var loc_url=window.location.href;
             console.log('location: '+loc_url);
            var loc=[];
            loc=loc_url.split("/");
            for(var x=0;x<loc.length;x++){
                var data=loc[x];
                if(data.includes("="))
                    data=data.split("=")[1];
                if(data.startsWith("001")){
                    recordId=data;
                	break;
                }
            }
            console.log('recordId: '+recordId);
        }
        }catch(err){
            console.log("ERROR: "+err.stack);
        }
        var action = component.get("c.getContactFeeds");
        action.setParams({ conId : recordId });       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.flist",JSON.parse( response.getReturnValue()));
                console.log('flist: '+JSON.stringify(component.get('v.flist')));
            }
        });
        $A.enqueueAction(action);
 },
    expand : function(component, event, helper){
        console.log('expando success');
        try{
       	var cmpTarget = component.find('expanding_section');
       	$A.util.toggleClass(cmpTarget, 'slds-is-open');
        }catch(err){
            console.log("ERROR: "+err.stack);
        }
    }
})