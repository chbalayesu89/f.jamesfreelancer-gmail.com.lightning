({
	populdateEmployeeByuserId : function(component,event) {
        var uId=component.get("v.userId");
		 console.log('userId: '+uId);
            //  getEmployeeProfile
            var action = component.get("c.getEmployeeProfile");
            action.setParams({ userId : uId });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.empwpr",response.getReturnValue());
                    component.set("v.stafflist",component.get("v.empwpr").stafflist);
                    component.set("v.managerlist",component.get("v.empwpr").managerlist);
                    component.set("v.emp",component.get("v.empwpr").empprofile);
                    component.set("v.targetlist",component.get("v.emp").quarter_budget_targets__r);
                    component.set("v.lrlist",component.get("v.emp").leave_requests__r);
                    component.set("v.recordId",component.get("v.emp").Id);
                    console.log('stafflist: '+JSON.stringify(component.get("v.stafflist")));
                    console.log('emp: '+JSON.stringify(component.get("v.emp")));
                }
            });
            $A.enqueueAction(action); 
	}
})