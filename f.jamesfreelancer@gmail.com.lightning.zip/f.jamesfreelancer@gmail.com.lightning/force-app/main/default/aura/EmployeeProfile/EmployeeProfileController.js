({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        console.log('>>> doInit <<<<<');
        var uId=component.get("v.userId");                
        console.log('uId: '+uId);
        if(uId==undefined){
            console.log('setting current user');
            uId = $A.get("$SObjectType.CurrentUser.Id");
            component.set("v.userId",uId);
        } 
        helper.populdateEmployeeByuserId(component,event);
    },
    fruitsTab: function(component, event, helper) {
        var tab1 = component.find('fruitId');
        var TabOnedata = component.find('fruTabDataId');
        
        var tab2 = component.find('VegeId');
        var TabTwoData = component.find('vegeTabDataId');
        
        //   var tab3 = component.find('ColorId');
        //   var TabThreeData = component.find('ColorTabDataId');
        //show and Active fruits tab
        $A.util.addClass(tab1, 'slds-is-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
        //  $A.util.removeClass(tab3, 'slds-is-active');
        //  $A.util.removeClass(TabThreeData, 'slds-show');
        //  $A.util.addClass(TabThreeData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        //  component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
    },
    vegeTab: function(component, event, helper) {
        
        var tab1 = component.find('fruitId');
        var TabOnedata = component.find('fruTabDataId');
        
        var tab2 = component.find('VegeId');
        var TabTwoData = component.find('vegeTabDataId');
        
        //   var tab3 = component.find('ColorId');
        //   var TabThreeData = component.find('ColorTabDataId');
        
        //show and Active vegetables Tab
        $A.util.addClass(tab2, 'slds-is-active');
        $A.util.addClass(tab2, 'slds-has-focus');        
        
        $A.util.removeClass(TabTwoData, 'slds-hide');
        $A.util.addClass(TabTwoData, 'slds-show');
        // Hide and deactivate others tab
        $A.util.removeClass(tab1, 'slds-is-active');
        $A.util.removeClass(tab1, 'slds-has-focus');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
        //  $A.util.removeClass(tab3, 'slds-is-active');
        //  $A.util.removeClass(TabThreeData, 'slds-show');
        //  $A.util.addClass(TabThreeData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",true);
        //  component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        
    },
    colorTab: function(component, event, helper) {
        /*
        var tab1 = component.find('fruitId');
        var TabOnedata = component.find('fruTabDataId');
 
        var tab2 = component.find('VegeId');
        var TabTwoData = component.find('vegeTabDataId');
 
        var tab3 = component.find('ColorId');
        var TabThreeData = component.find('ColorTabDataId');
 
        //show and Active color Tab
        $A.util.addClass(tab3, 'slds-is-active');
        $A.util.addClass(tab3, 'slds-has-focus');
        $A.util.removeClass(TabThreeData, 'slds-hide');
        $A.util.addClass(TabThreeData, 'slds-show');
        // Hide and deactivate others tab
        $A.util.removeClass(tab1, 'slds-is-active');
        $A.util.removeClass(tab1, 'slds-has-focus');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
 
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(tab2, 'slds-has-focus');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
 		
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",true);
        */
    },
    opentargetmodal : function(component,event,helper){
        component.set("v.isTargetOpen",true);
    }    ,
    closetargetmodal : function(component,event,helper){
        component.set("v.isTargetOpen",false);
    },
    savetarget: function(component,event,helper){
        console.log('target: '+JSON.stringify(component.get("v.target")));
        var action = component.get("c.createTargetRecord");
        action.setParams({ tg : component.get("v.target"),
                          empId:component.get("v.emp").Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.targetlist",response.getReturnValue());
                component.set("v.isTargetOpen",false);
            }
        });
        $A.enqueueAction(action);          
    },
    loadprofile : function(component,event,helper){
        console.log('<<< loadprofile >>>');
        var staffId=event.target.id;
        console.log('staffId: '+staffId);
        
         var action = component.get("c.getEmployeeProfileForStaff");
            action.setParams({ userId : staffId });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.empwpr",response.getReturnValue());
                    component.set("v.stafflist",component.get("v.empwpr").stafflist);
                    component.set("v.managerlist",component.get("v.empwpr").managerlist);
                    component.set("v.emp",component.get("v.empwpr").empprofile);
                    component.set("v.targetlist",component.get("v.emp").quarter_budget_targets__r);
                    component.set("v.lrlist",component.get("v.emp").leave_requests__r);
                    component.set("v.recordId",component.get("v.emp").Id);
                    console.log('stafflist: '+JSON.stringify(component.get("v.stafflist")));
                }
            });
            $A.enqueueAction(action);  
       /*
        try{
            var appEvent = $A.get("e.c:StaffSelected");            
            appEvent.setParams({
            "userId" : staffId });
            appEvent.fire();
        }catch(err){
            console.log(err.stack);
        }    */
      /*  $A.createComponent(
            "c:EmployeeProfile",
            {
                "userId": staffId
                
            },
            function(newButton, status, errorMessage){
                //Add the new button to the body array
                if (status === "SUCCESS") {
                    var body = component.get("v.body");
                    body.push(newButton);
                    component.set("v.body", body);
                }
                else if (status === "INCOMPLETE") {
                    console.log("No response from server or client is offline.")
                    // Show offline error
                }
                else if (status === "ERROR") {
                    console.log("Error: " + errorMessage);
                    // Show error message
                }
            }
        );*/
	},
    staffSelectedAction: function(component,event,helper){
        console.log('<<< staffSelectedAction >>>');
         var staffId = event.getParam("userId");
        console.log('staffId: '+staffId);
        component.set("v.userId",staffId);		     
        helper.populdateEmployeeByuserId(component,event);        
    }
})