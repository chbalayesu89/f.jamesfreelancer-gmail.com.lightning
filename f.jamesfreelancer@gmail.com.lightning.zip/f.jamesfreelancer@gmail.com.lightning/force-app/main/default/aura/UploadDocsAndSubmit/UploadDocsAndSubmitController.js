({
	myAction : function(component, event, helper) {
		
	},
     handleUploadFinished: function (cmp, event) {
        //Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
         cmp.set("v.docslist",uploadedFiles);
         if(uploadedFiles.length>0){
             cmp.find("save_btn").set("v.disabled",false);
         }
         console.log('uploadedFiles: '+JSON.stringify(uploadedFiles));
        //Show success message – with no of files uploaded
      /*  var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": "Success!",
            "type" : "success",
            "message": uploadedFiles.length+" files has been uploaded successfully!"
        });
        toastEvent.fire(); */
         
        $A.get('e.force:refreshView').fire();
         
        //Close the action panel
       // var dismissActionPanel = $A.get("e.force:closeQuickAction");
       // dismissActionPanel.fire();
    },
    saveandSubmit : function(component,event){
        //Close the action panel
        var p_lr=component.get("v.lr");
        var doclist=component.get("v.docslist");
        if(p_lr.Leave_Type__c=='Personal Leave' && doclist.length==0 ){            
                document.getElementById("msg").innerHTML='Supporting docs required for Personal Leave type';
        }else{           
             var action = component.get("c.submitLR");
            action.setParams({ p_lrId : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                  //  component.set("v.lr",response.getReturnValue());
                   // console.log('opp: '+JSON.stringify(component.get("v.opp")));                  
        			//component.set("v.showSpinner",false);  
        			var result=response.getReturnValue(); 
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
        			dismissActionPanel.fire();
                    if(result){            		
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Success!",
                            "type" : "success",
                            "message": " Leave Request has been submitted for Approval successfully!"
                        });
                        toastEvent.fire();
                    }else{
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error!",
                            "type" : "error",
                            "message": " Failed to submit Leave Request. Please ensure it is not already submitted. For more details contact Administrator"
                        });
                        toastEvent.fire();
                    }
                }
            });
            $A.enqueueAction(action);
        }        
    },
    cancel : function(component,event){
        //Close the action panel
        //remove uploaded files from the list
         var action = component.get("c.cancelUploads");
            action.setParams({ p_docslist_str : JSON.stringify(component.get("v.docslist")) });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    $A.get('e.force:refreshView').fire();
                    var dismissActionPanel = $A.get("e.force:closeQuickAction");
       				 dismissActionPanel.fire();  
                    
                }
            });
            $A.enqueueAction(action);       
    },
    doInit: function(component, event, helper){
        //component.set("v.showSpinner",true);
        try{
            console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
            var action = component.get("c.getLeaveRequest");
            action.setParams({ p_lrId : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.lr",response.getReturnValue());
                    var lr=component.get("v.lr");
                    if(lr.Leave_Type__c!='Personal Leave'){
                        component.find("save_btn").set("v.disabled",false);
                    }
                   // console.log('opp: '+JSON.stringify(component.get("v.opp")));                  
        			//component.set("v.showSpinner",false);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
        toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    }
})