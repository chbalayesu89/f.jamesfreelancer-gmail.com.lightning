({
	myAction : function(component, event, helper) {
		
	},
    afterScriptsLoaded : function(component, event, helper) {
		console.log('----------- afterScriptsLoaded -------------------');
         $(document).ready(function(){
             /*   $('.slds-vertical-tabs__nav-item').on('click', function(){
                    // alert('item clicked');
                    $(this).addClass('slds-is-active');
                    $(this).find('a').attr('aria-selected', true);
                    var $contentToShow = $('#'+$(this).find('a').attr('aria-controls'));
                    $contentToShow.removeClass('slds-hide');
                    $contentToShow.addClass('slds-show');
                    
                    $(this).siblings().removeClass('slds-is-active');
                    $(this).siblings().find('a').attr('aria-selected', false);
                    $contentToShow.siblings('.slds-vertical-tabs__content').removeClass('slds-show');
                    $contentToShow.siblings('.slds-vertical-tabs__content').addClass('slds-hide');
                }); 
             
              $('.slds-tabs_default__item').on('click', function(){
                $(this).addClass('slds-is-active');
                $(this).find('a').attr('aria-selected', true);
                var $contentToShow = $('#'+$(this).find('a').attr('aria-controls'));
                $contentToShow.removeClass('slds-hide');
                $contentToShow.addClass('slds-show');
                
                $(this).siblings().removeClass('slds-is-active');
                $(this).siblings().find('a').attr('aria-selected', false);
                $contentToShow.siblings('.slds-tabs_default__content').removeClass('slds-show');
                $contentToShow.siblings('.slds-tabs_default__content').addClass('slds-hide');
            }); */
            }); 
	},
    doInit: function(component, event, helper){
        try{
        console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
         var action = component.get("c.getItem");
        action.setParams({ ItemId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.Itm",response.getReturnValue());
                var recordtype=component.get("v.Itm").Record_Type__c;
                console.log('recordtype: '+recordtype);
                if(recordtype!='Attractions' && recordtype!='Restaurants' && recordtype!='Shops' && recordtype!='Car hire'){
                   component.set("v.showRTandPM",true);
                 }
                else{
                    component.set("v.showRTandPM",false);
                }
                console.log("showRTandPM:"+component.get("v.showRTandPM"));
                component.set("v.roomtypeslist",component.get("v.Itm").Room_Types__r);
                component.set("v.priceseasonlist",component.get("v.Itm").Price_Period__r);
                component.set("v.itclist",component.get("v.Itm").Item_Content__r);
                console.log('Itm: '+JSON.stringify(component.get("v.Itm")));
                //==================================== begin map logic =========================================
                 try{
        var itcomp=component.get("v.Itm");           
            console.log('itcomp:'+JSON.stringify(itcomp));
           // var itc=JSON.stringify(itcomp);
            var st='';
            var ct='';
            var ste=''; 
            var lat='';
            var lon='';
            if(itcomp.Destination_Street__c!=null)
                st=itcomp.Destination_Street__c;
            if(itcomp.Destination_City__c!=null)
                ct=itcomp.Destination_City__c;
            if(itcomp.Destination_State__c!=null)
                ste=itcomp.Destination_State__c;
            if(itcomp.LatitudeTEXT__c!=null)
                lat=itcomp.LatitudeTEXT__c;
            if(itcomp.LongitudeTEXT__c!=null)
                lon=itcomp.LongitudeTEXT__c;
            console.log('lat: '+lat);
            console.log('lon: '+lon);
        component.set('v.mapMarkers', [
            {
                location: {
                    Street: ''+st,
                    City: ''+ct,
                    State: ''+ste
                },

                title: ''+st,
                description: ''+ct+','+ste
            }
        ]);
          /*  component.set('v.mapMarkers', [
            {
                location: {
                   'Latitude': lat,
                   'Longitude': lon
                },

                title: ''+st,
                description: ''+ct+','+ste
            }]); */
        component.set('v.zoomLevel', 17);
        }catch(err){
            
            console.log(err.stack);
        }        
        console.log('zoomlevel: '+component.get('v.zoomLevel'));
                //====================================  end map logic  ==========================================
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    overviewTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
        
        //show and Active fruits tab
        $A.util.addClass(tab1, 'slds-is-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
        }catch(err){
            console.log(err.stack);
        }
	},
    roomtypesTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
        
        //show and Active fruits tab
        $A.util.addClass(tab2, 'slds-is-active');
        $A.util.addClass(TabTwoData, 'slds-show');
        $A.util.removeClass(TabTwoData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab1, 'slds-is-active');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
        }catch(err){
            console.log(err.stack);
        }
	},
    pricemanagerTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
        
        //show and Active fruits tab
        $A.util.addClass(tab3, 'slds-is-active');
        $A.util.addClass(TabThreeData, 'slds-show');
        $A.util.removeClass(TabThreeData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
        }catch(err){
            console.log(err.stack);
        }
	},
    contentTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
        
        //show and Active fruits tab
        $A.util.addClass(tab4, 'slds-is-active');
        $A.util.addClass(TabFourData, 'slds-show');
        $A.util.removeClass(TabFourData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
        }catch(err){
            console.log(err.stack);
        }
	},
    mediaTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
        
        //show and Active fruits tab
        $A.util.addClass(tab5, 'slds-is-active');
        $A.util.addClass(TabFiveData, 'slds-show');
        $A.util.removeClass(TabFiveData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",true);
        }catch(err){
            console.log(err.stack);
        }
	}
})