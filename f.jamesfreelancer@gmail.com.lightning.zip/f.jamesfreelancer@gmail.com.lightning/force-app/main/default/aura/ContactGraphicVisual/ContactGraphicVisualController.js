({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
  	console.log('doInit success');       
        var prlist=[];
        console.log('recordId: '+component.get("v.recordId"));
        
        var action = component.get("c.getContact");
        action.setParams({ conId : component.get("v.recordId") });       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.con",response.getReturnValue());
                console.log('contact: '+JSON.stringify(component.get('v.con')));
            }
        });
        $A.enqueueAction(action);
 }
})