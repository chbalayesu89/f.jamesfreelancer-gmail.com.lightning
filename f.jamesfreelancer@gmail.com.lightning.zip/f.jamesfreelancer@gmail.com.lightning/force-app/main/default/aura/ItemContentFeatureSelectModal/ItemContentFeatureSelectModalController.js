({
	save : function(component, event, helper) {
        console.log('---save---');
        console.log('dpfId: '+component.get("v.dpfId"));
        console.log('parentId: '+component.get("v.parentId"));
		component.set("v.showSpinner",true);
        var action = component.get("c.setFeaturedImage");
        action.setParams({ dpfId : component.get("v.dpfId"),
                          parentId: component.get("v.parentId")
                          });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('response: '+response.getReturnValue());
                try{
                    var appEvent = $A.get("e.c:FeaturedImageSelect");            
                    appEvent.setParams({
                        "FeaturedImageLink" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
                component.set("v.isOpen",false);                
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action);       
	},
    closeModel : function(component, event, helper) {
		component.set("v.isOpen",false);
	},
    setImage : function(component,event,helper){
        console.log('setImage');
        var dpfId=event.target.id;
        console.log('dpfId: '+dpfId);
            //event.target.id;        
        component.set("v.dpfId",dpfId);
    }
})