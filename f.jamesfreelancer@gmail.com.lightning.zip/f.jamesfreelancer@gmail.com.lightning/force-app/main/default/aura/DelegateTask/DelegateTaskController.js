({
    myAction : function(component, event, helper) {
        
    },
    save :function(component, event, helper){                
        var recordId=component.get("v.recordId");
        var dtaskobj=component.get("v.dtask");
        console.log('save >>> dtask: '+JSON.stringify(dtaskobj));
        dtaskobj.TaskId__c=recordId;
        dtaskobj.Status__c='Assigned';
        //clean staff Id
        var sId=dtaskobj.Staff__c;
        console.log('staff__c: '+sId);
        dtaskobj.Staff__c=''+sId;
        component.set("v.dtask",dtaskobj);
        console.log('dtask: '+JSON.stringify(dtaskobj));
        var action = component.get("c.saveDelegatedTask");
        action.setParams({ p_dtask : dtaskobj });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var dtaskId=response.getReturnValue();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/"+dtaskId
                });
                urlEvent.fire();
            }
        });
        $A.enqueueAction(action);                               
    },
    cancel :function(component, event, helper){        
        var recordId=component.get("v.recordId");
        console.log('<<< cancel >>> recordId: '+recordId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+recordId
        });
        urlEvent.fire();
    }
})