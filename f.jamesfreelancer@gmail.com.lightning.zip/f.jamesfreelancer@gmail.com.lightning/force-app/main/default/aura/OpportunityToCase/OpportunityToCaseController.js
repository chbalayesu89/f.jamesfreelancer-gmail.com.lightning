({
	myAction : function(component, event, helper) {
		
	},
    cancelbtn : function(component,event,helper){
        $A.get("e.force:closeQuickAction").fire();
    },    
    doInit :function(component,event,helper){
        // create a Default RowItem [Contact Instance] on first time Component Load
        // by call this helper function  
        helper.createObjectData(component, event);
        
        console.log('>> doInit >>');
        var action = component.get("c.getOpportunity");
        action.setParams({ p_recordId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.opp",response.getReturnValue());
                var opp=component.get("v.opp");
                console.log('opp:'+JSON.stringify(opp));
                component.set("v.region",opp.Account.XERO_Region__c);
                component.set("v.oppgrossprofit",opp.Quote_Gross_Profit__c);
                 console.log('opp: '+JSON.stringify(component.get("v.opp"))); 
                component.set("v.showProgress",true);
                if(opp.StageName=='Closed Won'){
                if(opp.Is_opp_to_case_conversion_approved__c==false){
                    $A.get("e.force:closeQuickAction").fire();
                    var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Not yet approved!",
                    "message": "Split percent need to approve from quote manager."
                });
                toastEvent.fire(); 
                }
                else if(opp.Is_opp_to_case_conversion_approved__c==true){
                //   component.find("btn_convert").set("v.disabled",false);     
                }
                else if(opp.opportunity_to_case_converted_Id__c &&
                   opp.opportunity_to_case_converted_Id__c!=''){
                    //already converted, show case page
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+opp.opportunity_to_case_converted_Id__c
                    });
                    urlEvent.fire();
                    //component.set("v.showProgress",true);
                }
                   
                }
            }
        });
        $A.enqueueAction(action);
    },
    convertbtn : function(component,event,helper){
        // if (helper.validateRequired(component, event)) {               
        var action = component.get("c.saveCaseRecord");
        action.setParams({ p_oppId : component.get("v.recordId"),
                          p_milestoneList:component.get("v.contactList")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
        		$A.get("e.force:closeQuickAction").fire();
                component.set("v.caseId",response.getReturnValue());
                var csId=component.get("v.caseId");
                if(csId!='undefined' &&
                   csId!=''){
                    // show case page
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+csId
                    });
                    urlEvent.fire();
                    //component.set("v.showProgress",true);
                }
            }
        });
        $A.enqueueAction(action);
        // }
    },
    // function for create new object Row in Contact List 
    addNewRow: function(component, event, helper) {
        // call the comman "createObjectData" helper method for add new Object Row to List  
        helper.createObjectData(component, event);
    },
 
    // function for delete the row 
    removeDeletedRow: function(component, event, helper) {
        // get the selected row Index for delete, from Lightning Event Attribute  
        var index = event.getParam("indexVar");
        // get the all List (contactList attribute) and remove the Object Element Using splice method    
        var AllRowsList = component.get("v.contactList");
        AllRowsList.splice(index, 1);
        // set the contactList after remove selected row element  
        component.set("v.contactList", AllRowsList);
    },
    // function for save the Records 
    Save: function(component, event, helper) {
        // first call the helper function in if block which will return true or false.
        // this helper function check the "first Name" will not be blank on each row.
        if (helper.validateRequired(component, event)) {
            // call the apex class method for save the Contact List
            // with pass the contact List attribute to method param.  
            var action = component.get("c.saveContacts");
            action.setParams({
                "ListContact": component.get("v.contactList")
            });
            // set call back 
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    // if response if success then reset/blank the 'contactList' Attribute 
                    // and call the common helper method for create a default Object Data to Contact List 
                    component.set("v.contactList", []);
                    helper.createObjectData(component, event);
                    alert('record Save');
                }
            });
            // enqueue the server side action  
            $A.enqueueAction(action);
        }
    },
    
    rowChangeEvt:function(component,event,helper){
         if (helper.validateRequired(component, event)) {
             component.find("btn_convert").set("v.disabled",false);     
         }else{
             component.find("btn_convert").set("v.disabled",true);     
         }
    },
    toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    }
})