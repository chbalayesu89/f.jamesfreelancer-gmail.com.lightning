({
    createObjectData: function(component, event) {
        // get the contactList from component and add(push) New Object to List  
        var RowItemList = component.get("v.contactList");
        RowItemList.push({
            'sobjectType': 'Milestone__c',
            'Item_Name__c': '',
            'Quantity__c': '1',
            'Milestone_Value__c': '0',
            'Tax_Type__c':'',
            'Item_Description__c':'',
            'Date__c':''
        });
        // set the updated list to attribute (contactList) again    
        component.set("v.contactList", RowItemList);
    },
    // helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        var isValid = true;
        var allContactRows = component.get("v.contactList");
        var txt='';
        var sum_milestones=0.0;
        for (var indexVar = 0; indexVar < allContactRows.length; indexVar++) {
            if (allContactRows[indexVar].Item_Description__c == '') {
                isValid = false;
                txt='Description Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
            }   
            var region=component.get("v.region");
            console.log('region:'+region);
            console.log('XERO_UK_Items__c:'+allContactRows[indexVar].XERO_UK_Items__c);
            if(region=='UK'){
                if (allContactRows[indexVar].XERO_UK_Items__c == undefined || allContactRows[indexVar].XERO_UK_Items__c =='') {
                    isValid = false;
                    txt='Item Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
                } 
            }
            else{
                if (allContactRows[indexVar].Item_Name__c == '') {
                    isValid = false;
                    txt='Item Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
                } 
            }
            if(region=='UK'){
              /*  if (allContactRows[indexVar].XERO_UK_Tax_Type__c == '') {
                    isValid = false;
                    txt='Tax Type Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
                } */
            }
            else{
                if (allContactRows[indexVar].Tax_Type__c == '') {
                    isValid = false;
                    txt='Tax Type Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
                } 
            }
             if (allContactRows[indexVar].Date__c == '') {
                isValid = false;
                txt='Date Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
            }   
            if (allContactRows[indexVar].Quantity__c == '') {
                isValid = false;
                txt='Quantity Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
            }            
          /*  if (allContactRows[indexVar].Milestone_Value__c == '') {
                isValid = false;
                txt='Milestone value Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
            } */
            if (allContactRows[indexVar].Milestone_Value__c != '' && allContactRows[indexVar].Milestone_Value__c != undefined) {
                sum_milestones+=parseFloat(allContactRows[indexVar].Milestone_Value__c);
            }
        }
        console.log('sum_milestones: '+sum_milestones);
        component.set('v.summilestone',sum_milestones);
        var oppgrossprofit=component.get("v.oppgrossprofit");
        if(sum_milestones!=oppgrossprofit){
          isValid = false;
          txt="Sum of Milestone amounts must be equal to QUOTE GROSS PROFIT"+'<br />' ;  
        }
        document.getElementById('msg').innerHTML=txt;
        
        return isValid;
    },
})