({
	myAction : function(component, event, helper) {
		
	},
    save : function(component, event, helper) {
        console.log('--- save ---');
        try{        
        	component.find("itmedit").get("e.recordSave").fire();  
        }catch(err){
            console.log(err.stack);
        }
        component.set("v.flag",true);
          var action = component.get("c.getItem");
        action.setParams({ ItemId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.itm",response.getReturnValue());  
                try{
                    component.find("itmedit").get('e.refreshView').fire();
                }catch(err){
                    console.log(err.stack);
                }
                var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
      "url": '/'+component.get("v.itm").Id
    });
    urlEvent.fire();
            }
        });
        $A.enqueueAction(action); 
        try{
            component.find("itmedit").get('e.refreshView').fire();
        }catch(err){
            console.log(err.stack);
        }
       
        
    },
    edit : function(component, event, helper) {
        component.set("v.flag",false);
    },
    cloneedit : function(component, event, helper) {
        console.log('--- cloneedit ---');
        component.set("v.cloneflag",true);
    },
    cloneItemCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.cloneflag",false);
    },
    cancel : function(component, event, helper) {
        component.set("v.flag",true);
    },
    delete : function(component, event, helper) {
         var action = component.get("c.deleteItem");
        action.setParams({ ItemId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                window.location.href='https://lightning-sandbox--lightning.lightning.force.com/lightning/o/Items__c/list?filterName=Recent';
            }
        });
        $A.enqueueAction(action);
    },
    clone : function(component, event, helper) {
        try{ 
          // component.find("cedit").get("e.recordSave").fire();   
           var itm=component.get("v.cItm");
            console.log('itm: '+JSON.stringify(itm));
         var action = component.get("c.cloneItem");
        action.setParams({ cItem : JSON.stringify(component.get("v.cItm")) });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var cId=response.getReturnValue();
                console.log('redirecting...'+cId);
                window.location.href='/'+cId;
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Excetion: '+err.stack);
        }
    }
})