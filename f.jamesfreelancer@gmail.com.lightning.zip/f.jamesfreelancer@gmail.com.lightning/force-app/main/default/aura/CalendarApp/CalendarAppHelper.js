({
	loadDataToCalendar :function(component,data){
        console.log('loadData: '+JSON.stringify(data));
        //Find Current date for default date
        var d = new Date();
        var month = d.getMonth()+1;
        var day = d.getDate();
        var currentDate = d.getFullYear() + '/' +
            (month<10 ? '0' : '') + month + '/' +
            (day<10 ? '0' : '') + day;
         
        var self = this;
        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,basicWeek,basicDay'
            },
            selectable : true,
            defaultDate: currentDate,
            editable: true,
            eventLimit: true,
            events:data,
            dragScroll : true,
             droppable: true,
            weekNumbers : true,
  eventDrop: function(event, delta, revertFunc) {

    alert(event.title + " was dropped on " + event.start.format());

    if (!confirm("Are you sure about this change?")) {
      revertFunc();
    }
      else{
          var eventid = event.id;
          var eventdate = event.start.format();
          self.editEvent(component,eventid,eventdate);
      }

  },
            eventClick: function(event, jsEvent, view) {
           
                /*
              var editRecordEvent = $A.get("e.force:editRecord");
              editRecordEvent.setParams({
              "recordId": event.id
           });
           editRecordEvent.fire();
                */
                
                try{
            console.log('Items >> getMeetingDetails initiated >>'); 
            var action = component.get("c.getMeetingDetails");
            action.setParams({ p_meetingId : event.id });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var meeting=response.getReturnValue();
                    console.log("meeting: "+JSON.stringify(meeting));
                    component.set("v.cm",meeting.cm);
                    component.set("v.contactList",meeting.malist);              
        			component.set("v.showpopup",true);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
                
          },
            dayClick :function(date, jsEvent, view) {
              
                var datelist = date.format().toString().split('-');
             
              var datetime = new Date(datelist[0],parseInt(datelist[1])-1,parseInt(datelist[2])+1,0,0,0,0);
           /* 
             var createRecordEvent = $A.get("e.force:createRecord");
    createRecordEvent.setParams({
        "entityApiName": "Event",
        "defaultFieldValues": {
        'StartDateTime' :  datetime
        
    }
    });
    createRecordEvent.fire();
                */
                
                component.set("v.showpopup",true);
                //console.log("showpopup: "+component.get("v.showpopup"));
          },
            
            eventMouseover : function(event, jsEvent, view) {
            
          }
    });
        
        
         $("#calendar").fullCalendar('removeEvents');
         $("#calendar").fullCalendar('addEventSource', data);
         $("#calendar").fullCalendar('rerenderEvents');
        
    },
       
    
    formatFullCalendarData : function(component,events) {
        var josnDataArray = [];
        for(var i = 0;i < events.length;i++){
            var startdate = events[i].Start_Time__c;
                //$A.localizationService.formatDate(events[i].StartDateTime);
            var enddate = events[i].End_Time__c;
                //$A.localizationService.formatDate(events[i].EndDateTime);
            josnDataArray.push({
                'title':events[i].Name,
                'start':startdate,
                'end':enddate,
                'id':events[i].Id
            });
        }
      
        return josnDataArray;
    },
     
    fetchCalenderEvents : function(component) {
         var action=component.get("c.getAllEvents");
       
         action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var data= response.getReturnValue();
               
                 var josnArr = this.formatFullCalendarData(component,response.getReturnValue());
                this.loadDataToCalendar(component,josnArr);
                component.set("v.Objectlist",josnArr);
                console.log('Objectlist: '+JSON.stringify(component.get("v.Objectlist")));
            } else if (state === "ERROR") {
                                 
            }
        });
        
        $A.enqueueAction(action);
       
    }, 
    
    editEvent : function(component,eventid,eventdate){
         var action=component.get("c.updateEvent");

         action.setParams({ eventid : eventid ,
                           eventdate : eventdate});

         action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
            
           
            } else if (state === "ERROR") {
                                 
            }
        });
        
        $A.enqueueAction(action);

    },
    
    createObjectData: function(component, event) {
        // get the contactList from component and add(push) New Object to List  
        var RowItemList = component.get("v.contactList");
        RowItemList.push({
            'sobjectType': 'Meeting_Attendee__c',
            'Attendee__c': ''
        });
        // set the updated list to attribute (contactList) again    
        component.set("v.contactList", RowItemList);
    },
    // helper function for check if first Name is not null/blank on save  
    validateRequired: function(component, event) {
        var isValid = true;
        var allContactRows = component.get("v.contactList");
        var txt='';
        var sum_milestones=0.0;
        for (var indexVar = 0; indexVar < allContactRows.length; indexVar++) {
            if (allContactRows[indexVar].Attendee__c == '') {
                isValid = false;
                txt='Attendee Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
            }
        } 
        var cm=component.get("v.cm");
        console.log("cm: "+JSON.stringify(cm));
        if(cm.Name==''){
            isValid = false;
                txt='Meeting Name Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
        }
        if(cm.Organiser__c==''){
            isValid = false;
                txt='Organiser Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
        }
        if(cm.Location__c==''){
            isValid = false;
                txt='Location__c Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
        }
        if(cm.Start_Time__c==''){
            isValid = false;
                txt='Start Time Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
        }
        if(cm.End_Time__c==''){
            isValid = false;
                txt='End Time Can\'t be Blank on Row Number ' + (indexVar + 1)+'<br />';
        }
        document.getElementById('msg').innerHTML=txt;
        if(isValid){
        	component.find("btn_save").set("v.disabled",false);
        }else{
            component.find("btn_save").set("v.disabled",true);
        }
        return isValid;
    },

})