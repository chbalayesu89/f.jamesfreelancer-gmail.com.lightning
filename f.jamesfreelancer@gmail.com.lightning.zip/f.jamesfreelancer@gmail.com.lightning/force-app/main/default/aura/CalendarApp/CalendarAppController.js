({
	 afterScriptsLoaded: function(cmp,evt,helper){
         
         helper.fetchCalenderEvents(cmp);
    },
    
     handleClick : function(component, event, helper){ 
      
         var buttonstate = component.get("v.buttonstate");
         component.set("v.buttonstate",!buttonstate);
         if(!buttonstate){
          $("#listcalendar").show();
         $("#calendar").hide();
         $('#listcalendar').fullCalendar({
        	defaultView: 'listWeek',
             listDayFormat : true,
             events : component.get("v.Objectlist")
		});
        
         }
         else{
              $("#calendar").show();
           $("#listcalendar").hide();   
             helper.fetchCalenderEvents(component);
         }
        
    },
    cancel:function(component,event,helper){
        component.set("v.showpopup",false);
    },
    closeModel:function(component,event,helper){
        component.set("v.showpopup",false);
    },
    enablesavebtn:function(component,event,helper){
        helper.validateRequired(component,event);
    },
    savecm:function(component,event,helper){
        console.log('p_maList');
        // if (helper.validateRequired(component, event)) {               
        var action = component.get("c.saveCalendarMeeting");
        action.setParams({ p_cm : component.get("v.cm"),
                          p_maList:component.get("v.contactList")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
        	//	$A.get("e.force:closeQuickAction").fire();
        		var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": "/lightning/n/Calendar_App"
                        });
                        urlEvent.fire();
                component.set("v.showpopup",false);                   
            }
        });
        $A.enqueueAction(action);
        // }
    },
    toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
     },
    // function for create new object Row in Contact List 
    addNewRow: function(component, event, helper) {
        // call the comman "createObjectData" helper method for add new Object Row to List  
        helper.createObjectData(component, event);
    },
 
    // function for delete the row 
    removeDeletedRow: function(component, event, helper) {
        // get the selected row Index for delete, from Lightning Event Attribute  
        var index = event.getParam("indexVar");
        // get the all List (contactList attribute) and remove the Object Element Using splice method    
        var AllRowsList = component.get("v.contactList");
        AllRowsList.splice(index, 1);
        // set the contactList after remove selected row element  
        component.set("v.contactList", AllRowsList);
    },
    doInit :function(component,event,helper){
        // create a Default RowItem [Contact Instance] on first time Component Load
        // by call this helper function  
        helper.createObjectData(component, event);
    },
     rowChangeEvt:function(component,event,helper){
         if (helper.validateRequired(component, event)) {
             component.find("btn_save").set("v.disabled",false);     
         }else{
             component.find("btn_save").set("v.disabled",true);     
         }
    },
})