({
    myAction : function(component, event, helper) {
        
    },
    doInit : function(component, event, helper) { 
        console.log('doInit success');
        //  component.find('savtbtn').set("v.disabled",true);
        console.log('recordId: '+component.get("v.recordId"));       
        var action = component.get("c.getReviewRecord");
        action.setParams({ rId : component.get("v.recordId") });        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                console.log('response: '+JSON.stringify(response.getReturnValue()));
                component.set("v.rview",response.getReturnValue());   
                component.set("v.targetrecordId",component.get("v.rview").Which_target_is_this_review_related_to__c);
                console.log('targetrecordId: '+component.get("v.targetrecordId"));
            }             
        });
        $A.enqueueAction(action);        
    },
    closeModal: function(component, event, helper) {
        component.set("v.isEditReviewOpen",false);
    },
    saveModal: function(component, event, helper) {
        console.log('saving data to server');        
        var action = component.get("c.saveReviewRecord");
        var rdataobj=component.get("v.rview");
        // rdataobj.Which_target_is_this_review_related_to__c=component.get("v.targerrecordId");
        /*  var msg=''
       // console.log('Leads__c'+rdataobj.Leads__c);
        if(rdataobj.Leads__c==undefined){
            msg='Leads Required!';
        } 
        if(rdataobj.Opportunities__c==undefined){
            msg='Opportunities__c Required!';
        } 
        if(rdataobj.Quotes_out__c==undefined){
            msg='Quotes_out__c Required!';
        } 
        if(rdataobj.Meetings_Consultations__c==undefined){
            msg='Meetings_Consultations__c Required!';
        } 
        alert('msg: '+msg);
          var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": 'Error',
                "message": msg,
                "type": "fail"
            });
            toastEvent.fire();
        component.set("v.msg",msg);
        if(msg==''){ 
             component.set("v.msg",'');
             component.find('savtbtn').set("v.disabled",false);
        } */
        component.set("v.rview",rdataobj);
        console.log('review: '+JSON.stringify(component.get("v.rview")));
        action.setParams({ rdata : component.get("v.rview") });          
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                console.log('data saved.');                                        
                component.set("v.isEditReviewOpen",false);
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/"+response.getReturnValue()
                });
                urlEvent.fire(); 
            }       
            
            //	window.open('/'+component.get("v.recordId"),"_self");
        });
        $A.enqueueAction(action);         
    },    
    enablesavebtn : function(component,event,helper){
        var rdataobj=component.get("v.rview");
        //  rdataobj.Which_target_is_this_review_related_to__c=component.get("v.recordId");
        var msg=''
        // console.log('Leads__c'+rdataobj.Leads__c);
        if(rdataobj.Leads__c==undefined){
            msg='Leads Required!';
        } 
        if(rdataobj.Opportunities__c==undefined){
            msg='Opportunities__c Required!';
        } 
        if(rdataobj.Quotes_out__c==undefined){
            msg='Quotes_out__c Required!';
        } 
        if(rdataobj.Meetings_Consultations__c==undefined){
            msg='Meetings_Consultations__c Required!';
        } 
        if(msg==''){
            component.find("savebtn").set("v.disabled",false); 
        }
    },
    editreview : function(component,event,helper){        
        component.set("v.isEditReviewOpen",true);
    },
    gotoTarget : function(component,event,helper){
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+component.get("v.targetrecordId")
        });
        urlEvent.fire();
    }
})