({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        var spId=component.get("v.sp").Id;
        console.log('PriceSeasonModal >> doInit initiated >>'+spId);
        var pp=component.get("v.pp");
        pp.Supplier_Product__c=spId;
        component.set("v.pp",pp);
      /*  var action = component.get("c.setPriceSeason");
        action.setParams({ spId : component.get("v.sp").Id });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.crecordId",response.getReturnValue());
                console.log('crecordId: '+component.get("v.crecordId"));                
                component.set("v.isOpen",true);
            }
        });
        $A.enqueueAction(action); */
    }, 
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    roomTypeCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.roomtype",false);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
          component.set("v.isOpen",false);
        		try{
                    var appEvent = $A.get("e.c:PriceSeasonCancel");            
                    appEvent.setParams({
                        "cloneedit" : false });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
        
       
    }, 
    save: function(component, event, helper) {       
        console.log('---RoomTypeModel >> Save ----');       
        // var roomtypeslist=[];
        var action = component.get("c.savePriceSeason");
        action.setParams({ ps : component.get("v.pp") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               // component.set("v.sp",response.getReturnValue());               
              //  console.log('new priceseasonlist: '+JSON.stringify(component.get("v.sp").Price_Period__r));
                component.set("v.isOpen",false); 
                try{
                    var appEvent = $A.get("e.c:PriceSeasonAdded");            
                    appEvent.setParams({
                        "priceseasonlist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
            } 
        });
        $A.enqueueAction(action);       
    }
})