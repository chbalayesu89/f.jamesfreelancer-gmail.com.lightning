({
	myAction : function(component, event, helper) {
		
	},
    doInit: function(component, event, helper){      
        component.set("v.showSpinner",true);
        try{
            console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
            var action = component.get("c.getIqWrapper");
            action.setParams({ oppId : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.iqw",response.getReturnValue());
                    console.log('iqw: '+JSON.stringify(component.get("v.iqw")));
                    component.set("v.opp",component.get("v.iqw").opp);
                    var opp=component.get("v.opp");
                    console.log('opp: '+JSON.stringify(opp));
                    
                  //  if(opp.RecordTypeId!=null &&
                  //     opp.RecordType.Name=='Tourism'){                        
                       component.set("v.iq",component.get("v.iqw").iq);                        
                    	var iq=component.get('v.iq');
                        //redirect to issue quote page
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": "/apex/IssueQuoteDays?Id="+iq.Id
                        });
                        urlEvent.fire();
                  //  }else{
                        //standard opportunity, show form
                   //     component.set("v.isStandard",true);
                  //  }                    
        			component.set("v.showSpinner",false);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
})