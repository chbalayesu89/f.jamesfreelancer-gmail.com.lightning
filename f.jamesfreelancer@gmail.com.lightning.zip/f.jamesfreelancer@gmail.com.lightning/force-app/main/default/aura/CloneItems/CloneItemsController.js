({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        console.log('CloneItems >> doInit initiated >>'+component.get("v.recordId"));
        var action = component.get("c.setCloneItem");
        action.setParams({ itmId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.crecordId",response.getReturnValue());
                console.log('crecordId: '+component.get("v.crecordId"));                
                component.set("v.isOpen",true);
            }
        });
        $A.enqueueAction(action);
    }, 
    closeModel: function(component, event, helper) {
        var action = component.get("c.cancelCloneItem");
        action.setParams({ cItmId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                try{
                    var appEvent = $A.get("e.c:CloneItemsCancel");            
                    appEvent.setParams({
                        "cloneedit" : false });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
                component.set("v.isOpen",false);
            }
        });
        $A.enqueueAction(action);
    }, 
    cloneItemClick: function(component, event, helper) {       
        try{
            component.find("citmre").get("e.recordSave").fire();   
        }catch(err){
            console.log('Exception: '+err.stack);
        }   
        component.set("v.isOpen",false);
        window.location.href='/'+component.get("v.crecordId");
    }
})