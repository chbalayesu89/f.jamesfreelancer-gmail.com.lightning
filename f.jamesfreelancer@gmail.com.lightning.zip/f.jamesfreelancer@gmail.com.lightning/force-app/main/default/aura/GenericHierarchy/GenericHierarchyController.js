({
	 afterScriptLoaded : function(component, event, helper) {
        helper.getHierarchyData(component, helper);
	}
})