({
	upload: function(component, file, fileContents) {
       // var attachId='';
        var action = component.get("c.saveTheFile");
        action.setParams({
            parentId: component.get("v.parentId"),
            fileName: file.name,
            base64Data: encodeURIComponent(fileContents), 
            contentType: file.type
        });
        action.setCallback(this, function(a) {
            try{
                    var appEvent = $A.get("e.c:DpfileAdded");            
                    appEvent.setParams({
                        "dpflist" : a.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
           // attachId = a.getReturnValue();
          //  console.log('attachId: '+attachId);
            component.set("v.isOpen",false);  
            component.set("v.showSpinner",false);  
        });            
     	$A.enqueueAction(action);  
    }
})