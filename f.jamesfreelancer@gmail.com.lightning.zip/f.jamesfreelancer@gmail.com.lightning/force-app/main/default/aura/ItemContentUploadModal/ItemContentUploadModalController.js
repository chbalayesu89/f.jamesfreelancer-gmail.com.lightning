({    
    save : function(component,event,helper) { 
        var MAX_FILE_SIZE=1750000;
        var fileInput = component.find("file").getElement();
    	var file = fileInput.files[0];   
        if (file.size > MAX_FILE_SIZE) {
            alert('File size cannot exceed ' + MAX_FILE_SIZE + ' bytes.\n' +
    	          'Selected file size: ' + file.size);
    	    return;
        }    
        var fr = new FileReader();  
       	fr.onload = function() {            
       component.set("v.showSpinner",true); 
            var fileContents = fr.result;
    	    var base64Mark = 'base64,';
            var dataStart = fileContents.indexOf(base64Mark) + base64Mark.length;
            fileContents = fileContents.substring(dataStart);        
    	    helper.upload(component, file, fileContents); 
        };

        fr.readAsDataURL(file);
    },       
    
    closeModel: function(component,event,helper){
        component.set("v.isOpen",false);
    }    
    ,
    handleUploadFinished: function (component, event,helper) {         
         component.set("v.isModalOpen",false);  
         component.set("v.showSpinner",true);
        // Get the list of uploaded files
        var uploadedFiles = event.getParam("files");    
         console.log("Files uploaded : " + JSON.stringify(uploadedFiles));        
         var action = component.get("c.saveUploads");
        action.setParams({
            recordId: component.get("v.parentId"),
            uploadedFiles: JSON.stringify(uploadedFiles)
        });
        action.setCallback(this, function(a) {
           // helper.checkForChanges(component,event); 
           // component.set("v.isuploadfinishedModalOpen",true);
            try{
                    var appEvent = $A.get("e.c:DpfileAdded");            
                    appEvent.setParams({
                        "dpflist" : uploadedFiles }); 
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
           component.set("v.isOpen",false);
                component.set("v.showSpinner",false);
        });            
     	$A.enqueueAction(action);        
    }
})