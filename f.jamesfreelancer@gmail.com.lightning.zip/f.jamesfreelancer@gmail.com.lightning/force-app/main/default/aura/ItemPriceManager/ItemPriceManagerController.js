({
    myAction : function(component, event, helper) {
        
    },
    managePrice : function(component, event, helper){
       console.log('---- manage Price ---->> loading component');       
     //  window.location.href="/"+component.get("v.itm").Price_Manager_Sheet__c;
        var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
        "url": "/"+component.get("v.itm").Price_Manager_Sheet__c
    });

    urlEvent.fire();
    }
})