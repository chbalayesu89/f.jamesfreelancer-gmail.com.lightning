({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
  console.log('doInit success');       
        var prlist=[];
        console.log('recordId: '+component.get("v.recordId"));
        var action2 = component.get("c.getCase2");
        action2.setParams({ csId : component.get("v.recordId") });       
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.cs2",JSON.parse( response.getReturnValue()));
                console.log('cs2: '+JSON.stringify(component.get('v.cs2')));
            }
        });
        var action = component.get("c.getCase");
        action.setParams({ csId : component.get("v.recordId") });       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.cs",response.getReturnValue());
               // console.log(JSON.parse( response.getReturnValue()));
                console.log('cs: '+JSON.stringify(component.get('v.cs')));
            }
        });
        $A.enqueueAction(action);
        $A.enqueueAction(action2);
 }
})