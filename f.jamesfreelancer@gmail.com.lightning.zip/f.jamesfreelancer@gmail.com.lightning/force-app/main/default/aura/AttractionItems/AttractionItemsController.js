({
    myAction : function(component, event, helper) {
        
    },
    save: function(component, event, helper) { 
        console.log('--- save --->> '+component.get("v.sp").Id);
        // console.log('spa: '+JSON.stringify(component.get("v.spa")));
        var action = component.get("c.saveAttractionItemDetails");
        action.setParams({ itcstr : JSON.stringify(component.get("v.attitem")),
                          itmId: component.get("v.sp").Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                component.set("v.attitemlist",response.getReturnValue()); 
                var itcreset=component.get("v.attitem"); 
                itcreset.Name='';
                itcreset.Description__c='';
                component.set("v.attitem",itcreset);               
            } 
        });
        $A.enqueueAction(action);
    },
    gotoItemContent: function(component,event,helper){
        console.log('gotoItemContent');
        var contentId=event.target.id;
        console.log('contentId: '+contentId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+contentId
        });
        urlEvent.fire();
    },
    edit:function(component,event,helper){
        var aId=event.target.id;
        console.log('edit:'+aId);
        var attlist=component.get("v.attitemlist");
        console.log('attlist:'+JSON.stringify(attlist));
        var eattitem=component.get("v.eattitem");
        for(var x=0;x<attlist.length;x++){
            if(attlist[x].Id==aId){
                console.log('entry matched');
                eattitem.Id=attlist[x].Id;
                eattitem.Name=attlist[x].Name;
                eattitem.Description__c=attlist[x].Description__c;
                break;
            }
        }
        component.set("v.eattitem",eattitem);
        console.log("eattitem:"+JSON.stringify(component.get("v.eattitem")));
        //component.set("v.attitemId",aId); 
        component.set("v.isEditOpen",true);
    },
    delete:function(component,event,helper){
    var contentId=event.target.id;
    component.set("v.attitemId",contentId);
    console.log('delete:'+contentId);
    component.set("v.isDelOpen",true);
	},
 	editAction:function(component,event,helper){    
    var action = component.get("c.editAttractionItemDetails");
    action.setParams({ itcstr : JSON.stringify(component.get("v.eattitem")),
                      itmId: component.get("v.sp").Id});
    action.setCallback(this, function(response) {
        var state = response.getState();
        console.log('state: '+state);
        if (state === "SUCCESS") {
            component.set("v.attitemlist",response.getReturnValue()); 
            var itcreset=component.get("v.eattitem"); 
            itcreset.Name='';
            itcreset.Description__c='';
            component.set("v.eattitem",itcreset);   
			component.set("v.isEditOpen",false);            
        } 
    });
    $A.enqueueAction(action);
	},
    delAction:function(component,event,helper){
         var action = component.get("c.delAttractionItemDetails");
    action.setParams({ itcstrId : component.get("v.attitemId"),
                      itmId: component.get("v.sp").Id});
    action.setCallback(this, function(response) {
        var state = response.getState();
        console.log('state: '+state);
        if (state === "SUCCESS") {
            component.set("v.attitemlist",response.getReturnValue()); 
            var itcreset=component.get("v.eattitem"); 
            itcreset.Name='';
            itcreset.Description__c='';
            component.set("v.eattitem",itcreset);   
    		component.set("v.isDelOpen",false);            
        } 
    });
    $A.enqueueAction(action);
    },
    closeModel:function(component,event,helper){
            component.set("v.isEditOpen",false);
            component.set("v.isDelOpen",false);
    }
})