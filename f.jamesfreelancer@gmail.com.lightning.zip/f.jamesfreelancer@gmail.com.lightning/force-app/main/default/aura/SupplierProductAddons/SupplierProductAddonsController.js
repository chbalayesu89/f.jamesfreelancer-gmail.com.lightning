({
	myAction : function(component, event, helper) {
		
	},
    save: function(component, event, helper) { 
        console.log('--- save --->> '+component.get("v.sp").Id);
        console.log('spa: '+JSON.stringify(component.get("v.spa")));
        var action = component.get("c.saveAddonDetails");
        action.setParams({ itcstr : JSON.stringify(component.get("v.spa")),
                          itmId: component.get("v.sp").Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                component.set("v.spalist",response.getReturnValue()); 
				var itcreset=component.get("v.spa"); 
                itcreset.Name='';
                itcreset.Description__c='';
                component.set("v.spa",itcreset);               
            } 
        });
        $A.enqueueAction(action);
    },
    gotoItemContent: function(component,event,helper){
        console.log('gotoItemContent');
        var contentId=event.target.id;
        console.log('contentId: '+contentId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+contentId
        });
        urlEvent.fire();
    },
    managePrice : function(component, event, helper){
       console.log('---- manage Price ---->> loading component');       
     //  window.location.href="/"+component.get("v.itm").Price_Manager_Sheet__c;
        var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
        "url": "/"+component.get("v.sp").Price_Manager_Sheet__c
    });

    urlEvent.fire();
    }
    ,
    edit:function(component,event,helper){
        var aId=event.target.id;
        console.log('edit:'+aId);
        var spalist=component.get("v.spalist");
      //  console.log('spalist:'+JSON.stringify(spalist));
        var espa=component.get("v.espa");
        for(var x=0;x<spalist.length;x++){
            if(spalist[x].Id==aId){
                console.log('entry matched');
                espa.Id=spalist[x].Id;
                espa.Name=spalist[x].Name;
                espa.Description__c=spalist[x].Description__c;
                break;
            }
        }
        component.set("v.espa",espa);
       // console.log("eattitem:"+JSON.stringify(component.get("v.eattitem")));
        //component.set("v.attitemId",aId); 
        component.set("v.isEditOpen",true);
    },
    delete:function(component,event,helper){
    var contentId=event.target.id;
    component.set("v.espaId",contentId);
    console.log('delete:'+contentId);
    component.set("v.isDelOpen",true);
	},
 	editAction:function(component,event,helper){    
    var action = component.get("c.editAddonDetails");
    action.setParams({ itcstr : JSON.stringify(component.get("v.espa")),
                      itmId: component.get("v.sp").Id});
    action.setCallback(this, function(response) {
        var state = response.getState();
        console.log('state: '+state);
        if (state === "SUCCESS") {
            component.set("v.spalist",response.getReturnValue()); 
            var itcreset=component.get("v.espa"); 
            itcreset.Name='';
            itcreset.Description__c='';
            component.set("v.espa",itcreset);   
			component.set("v.isEditOpen",false);            
        } 
    });
    $A.enqueueAction(action);
	},
    delAction:function(component,event,helper){
         var action = component.get("c.delAddonDetails");
    action.setParams({ itcstrId : component.get("v.espaId"),
                      itmId: component.get("v.sp").Id});
    action.setCallback(this, function(response) {
        var state = response.getState();
        console.log('state: '+state);
        if (state === "SUCCESS") {
            component.set("v.spalist",response.getReturnValue()); 
            var itcreset=component.get("v.espa"); 
            itcreset.Name='';
            itcreset.Description__c='';
            component.set("v.espa",itcreset);   
    		component.set("v.isDelOpen",false);            
        } 
    });
    $A.enqueueAction(action);
    },
    closeModel:function(component,event,helper){
            component.set("v.isEditOpen",false);
            component.set("v.isDelOpen",false);
    }
})