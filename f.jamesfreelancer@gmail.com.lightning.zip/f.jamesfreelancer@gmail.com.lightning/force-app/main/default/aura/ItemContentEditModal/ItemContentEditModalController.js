({
	myAction : function(component, event, helper) {
		
	},
    save: function(component, event, helper) {       
        console.log('---RoomTypeModel >> Save ----');          
        component.set("v.showSpinner",true);
        // var roomtypeslist=[];
        var action = component.get("c.saveItemContent");
        action.setParams({ itc : component.get("v.itc") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {component.set("v.isOpen",false);              
                try{
                    var appEvent = $A.get("e.c:ItemContentEdit");            
                    appEvent.setParams({
                        "itc" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }                   
        		component.set("v.showSpinner",false);
            } 
        });
        $A.enqueueAction(action);   
    },
    closeModel:function(component,event,helper){
        console.log('closeModel');
        component.set("v.isOpen",false);
    }
})