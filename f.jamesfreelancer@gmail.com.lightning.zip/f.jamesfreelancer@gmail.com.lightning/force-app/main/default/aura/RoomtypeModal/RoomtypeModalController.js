({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
       // console.log('RoomTyeModal >> doInit initiated >>'+component.get("v.itm").Id);
       var rt=component.get("v.roomtype");
        rt.Supplier_Product__c=component.get("v.sp").Id;
        component.set("v.roomtype",rt);
    }, 
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    roomTypeCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.roomtype",false);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
       component.set("v.roomtype",false);
         var appEvent = $A.get("e.c:RoomTypeCancel");            
                    appEvent.setParams({
                        "roomtype" : false });
                    appEvent.fire();
    },    
    save : function(component,event,helper){
        component.set("v.showSpinner",true);
    	console.log('---- savess -----');
		var action = component.get("c.addRoomType");
        action.setParams({ rt : component.get("v.roomtype") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                try{
                    var appEvent = $A.get("e.c:RoomTypeAdded");            
                    appEvent.setParams({
                        "roomtypeslist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }
                component.set("v.isOpen",false);                
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action);       
	}
})