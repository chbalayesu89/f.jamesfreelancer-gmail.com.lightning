({
	myAction : function(component, event, helper) {
		
	},
    doInit :function(component,event,helper){
        console.log('>> doInit >>');
        var action = component.get("c.getCampaignChilds");
        action.setParams({ p_cmpId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.campaignlist",response.getReturnValue());                
            }
        });
        $A.enqueueAction(action);
    }
})