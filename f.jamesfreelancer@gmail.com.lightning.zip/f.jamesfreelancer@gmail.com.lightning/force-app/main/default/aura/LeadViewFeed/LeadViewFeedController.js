({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
  console.log('doInit success');       
        var flist=[];
        var recordId=component.get("v.recordId");
        console.log('recordId: '+recordId);
        try{
        if(recordId==null){
            var loc_url=window.location.href;
             console.log('location: '+loc_url);
            var loc=[];
            loc=loc_url.split("/");
            for(var x=0;x<loc.length;x++){
                var data=loc[x];
                if(data.includes("="))
                    data=data.split("=")[1];
                if(data.startsWith("001")){
                    recordId=data;
                	break;
                }
            }
            console.log('recordId: '+recordId);
        }
        }catch(err){
            console.log("ERROR: "+err.stack);
        }
        var action = component.get("c.getLeadFeeds");
        action.setParams({ leadId : recordId });       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resData=response.getReturnValue();
                resData = JSON.parse(resData);
                for(var r in resData){
                    console.log('VJ! Test! ',r );
                    console.log('VJ! Test! ',resData[r] );
                    //resData[r]['CreatedDate']=new Date(resData[r]['CreatedDate']).toDateString();
				}
                component.set("v.flist",resData);
                console.log('VJ! ',component.get('v.flist'));
                console.log('flist: '+JSON.stringify(component.get('v.flist')));
            }
        });
        $A.enqueueAction(action);
 },
    
    expand : function(component, event, helper){
        console.log('expando success');
        try{
       	var cmpTarget = component.find('expanding_section');
       	$A.util.toggleClass(cmpTarget, 'slds-is-open');
        }catch(err){
            console.log("ERROR: "+err.stack);
        }
    }
})