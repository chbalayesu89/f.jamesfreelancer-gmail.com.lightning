({
    // Fetch the timeservices from the Apex controller
    getTimeServiceList: function(component) {
        var action = component.get('c.gettslist');
        // Set up the callback
        var self = this;
        action.setParams({ cmpId : component.get("v.recordId") });
        action.setCallback(this, function(actionResult) {
            component.set('v.tslist', actionResult.getReturnValue());
            console.log('tslist: '+JSON.stringify(component.get('v.tslist')));
        });
        $A.enqueueAction(action);
    }
})