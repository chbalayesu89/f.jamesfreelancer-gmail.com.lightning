({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper) {
        // Fetch the attachment list from the Apex controller
        helper.getTimeServiceList(component);
    }
})