({
    myAction : function(component, event, helper) {
        
    },    
    openRoomTypeModal : function(component, event, helper) {
        component.set("v.showSpinner", true);
        console.log('--- cloneedit ---');
        component.set("v.roomtype",true);
        setTimeout(function()
                   { 
                       component.set("v.showSpinner", false);
                   }, 2000);
    },
    roomTypeCancel: function(component, event, helper) {
        console.log('--- cloneedit ---');
        component.set("v.roomtype",false);
    },
    roomTypeAdded: function(component, event, helper) {
        console.log('--- roomTypeAdded ---');
        var rtlist = event.getParam("roomtypeslist");
        component.set("v.roomtypeslist",rtlist);
    },
    save: function(component, event, helper){
        console.log('--- save ----');
        var action = component.get("c.saveboardbasisAction");
        var sp=component.get("v.sp");
        console.log('sp:'+JSON.stringify(sp));
        action.setParams({spId:sp.Id,
                          roomonly:sp.Board_Basis_Room_Only__c,
                          catering:sp.Board_Basis_Catering__c,
                          bandb:sp.Board_Basis_B_B__c,
                          hb:sp.Board_Basis_Half_Board__c,
                          fb:sp.Board_Basis_Full_Board__c,
                          fullyinclusive:sp.BB_Fully_Inclusive_with_Local_beverages__c});
        action.setCallback(this, function(response) {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": "Board Basis has been Saved successfully."
            });
            toastEvent.fire();        	
        });
        $A.enqueueAction(action);
    },
    edit :function(component,event,helper){  
        component.set("v.rt",{'sobjectType':'Room_Type__c'});
        console.log('edit is clicked >> event target Id:'+event.target.id);
        component.set("v.crecordId",event.target.id);
        console.log('crecordId: '+component.get("v.crecordId")); 
        var action = component.get("c.getRoomType");
        action.setParams({ rtId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.rt",response.getReturnValue());
                component.set("v.isOpen",false);                
                component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action); 
        component.set("v.editflag",true);        
    },
    delete :function(component,event,helper){  
    component.set("v.crecordId",event.target.id);      
    component.set("v.deleteflag",true);
}, 	
 managePrice: function(component, event, helper) { 
    try{
        component.set("v.isModalOpen", true);
        var psoptionsvals=[];
        psoptionsvals.push({ value: '', label: '-- None --' });
        component.set("v.psoptions",psoptionsvals);
        var psId=component.get("v.psId");
        var roomtypeId=event.target.id;
        component.set("v.rtId",roomtypeId);
        component.set("v.rwplist",[]);
        // Set isModalOpen attribute to false  
        //  console.log('add price');
        var rooms=component.get("v.roomtypeslist");
        var addons=component.get("v.addonslist");
        var priceseason=component.get("v.priceseasonlist");
        
        // set ps options
        for(var x=0;x<priceseason.length;x++){
            psoptionsvals.push({ value: priceseason[x].Id, label: priceseason[x].Name });
        }
        component.set("v.psoptions",psoptionsvals);
        console.log('priceseasons: '+JSON.stringify(priceseason));
        var sp=component.get("v.sp");
        var rwp=component.get("v.rwp");
        var bblist=[];
        if(sp.Board_Basis_Room_Only__c==true){
            bblist.push('Room Only');
        }
        if(sp.Board_Basis_Catering__c==true){
            bblist.push('Catering');
        }
        if(sp.Board_Basis_B_B__c==true){
            bblist.push('B&B');
        }        
        if(sp.Board_Basis_Half_Board__c==true){
            bblist.push('Half-Board');
        }
        if(sp.Board_Basis_Full_Board__c==true){
            bblist.push('Full-Board');
        }
        if(sp.BB_Fully_Inclusive_with_Local_leverages__c==true){
            bblist.push('Fully Inclusive with Local beverages');
        }
        component.set("v.bblist",bblist);
        var rwplist=component.get("v.rwplist");
        //  console.log('rooms.length:'+JSON.stringify(rooms));
        /*  if(rooms!=null){
        for(var p=0;p<rooms.length;p++){
            if(rooms[p].Id==roomtypeId){
                if(bblist!=null){
            for(var q=0;q<bblist.length;q++){
                rwplist.push({'Room_type__c':rooms[p],
                                  'Board_basis__c':bblist[q]
                                  });
                if(addons!=null){
                for(var r=0;r<addons.length;r++){
                    rwplist.push({'Room_type__c':rooms[p],
                                  'Board_basis__c':bblist[q],
                                  'addon__c':addons[r]});
                }
                }
            }
                }
            }
       }
        } */
        //  component.set("v.rwplist",rwplist);
        console.log('rwplist:'+JSON.stringify(rwplist));
        component.set("v.psId",'');
        var roomtypeId=event.target.id;
        component.set("v.roomtypeId",roomtypeId);
        var spId=component.get("v.sp").Id;
        console.log('managePrice roomtype Id:'+roomtypeId);
        
        var action = component.get("c.doManagePrice");
        action.setParams({rtId : roomtypeId
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
                console.log('pmlist'+JSON.stringify(response.getReturnValue()));
                component.set("v.pmlist",response.getReturnValue());
                component.set("v.opmlist",component.get("v.pmlist"));
                var duppmlist=[];
                var pmlist=component.get("v.pmlist");
                if(pmlist!=null){
                    for(var a=0;a<pmlist.length;a++){
                        var rtId='';
                        var bb='';
                        var addId='';
                        if(pmlist[a].Room_type__r!=null){
                            rtId=pmlist[a].Room_type__r.Id;
                        }                        
                        if(pmlist[a].Board_basis__c!=null){
                            bb=pmlist[a].Board_basis__c;
                        }
                        if(pmlist[a].Addon__r!=null){
                            addId=pmlist[a].Addon__r.Id;
                        }
                        duppmlist.push(rtId+'_'+addId+'_'+bb);
                    }
                }
                console.log('duppmlist:'+JSON.stringify(duppmlist));
                if(rooms!=null){
                    for(var p=0;p<rooms.length;p++){
                        if(rooms[p].Id==roomtypeId){
                            if(bblist!=null){
                                for(var q=0;q<bblist.length;q++){
                                    if(!duppmlist.includes(rooms[p].Id+'_'+''+'_'+bblist[q])){
                                        rwplist.push({'Room_type__c':rooms[p],
                                                      'Board_basis__c':bblist[q],
                                                      'Name':rooms[p].Name+'+'+bblist[q]+'+'
                                                     });
                                    }
                                    if(addons!=null){
                                        for(var r=0;r<addons.length;r++){
                                            if(!duppmlist.includes(rooms[p].Id+'_'+addons[r].Id+'_'+bblist[q])){
                                                rwplist.push({'Room_type__c':rooms[p],
                                                              'Board_basis__c':bblist[q],
                                                              'addon__c':addons[r],
                                                              'Name':rooms[p].Name+'+'+bblist[q]+'+'+addons[r].Name});
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                var epmlist=[];
                //remove zero and replace it as empty string
                for(var b=0;b<pmlist.length;b++){
                    if(pmlist[b].Name==null || pmlist[b].Name==''){
                        var roomtypeName='';
                        var addonName='';
                        var bbName=pmlist[b].Board_Basis__c;
                        if(pmlist[b].Room_Type__c!=null){
                            roomtypeName=pmlist[b].Room_Type__r.Name;
                        }
                        if(pmlist[b].Addon__c!=null){
                            addonName=pmlist[b].Addon__r.Name;
                        }
                        pmlist[b].Name=roomtypeName+'+'+bbName+'+'+addonName;
                    }
                    if(pmlist[b].Value__c==0){
                        pmlist[b].Value__c='';
                    }
                    if(pmlist[b].Selling_Price__c==0){
                        pmlist[b].Selling_Price__c='';
                    }
                    if(pmlist[b].Margin_Value__c==0){
                        pmlist[b].Margin_Value__c='';
                    }
                    if(pmlist[b].Margin_Percent__c==0){
                        pmlist[b].Margin_Percent__c='';
                    }
                    epmlist.push(pmlist[b]);                   
                }
                component.set("v.pmlist",epmlist);
            }
        });
        $A.enqueueAction(action); 
    }catch(err){
        console.log('Exception:'+err.stack);
    }
},
    submitDetails:function(component,event,helper){
        try{
            var rtId=component.get("v.rtId");
            var rwplist=component.get("v.rwplist");
            var psId=component.get("v.psId");
            
            // console.log('rwplist:'+JSON.stringify(rwplist));
            var rwpselectedlist=[];
            var validated=true;
            for(var x=0;x<rwplist.length;x++){
                if(rwplist[x].selected__c==true){ 
                    if((rwplist[x].Value__c!=null && rwplist[x].Value__c!='') && (rwplist[x].Selling_Price__c==null || rwplist[x].Selling_Price__c=='')){
                        //  component.find("savebtn").set("v.disabled",true);
                        validated=false;
                    }
                    var roomtypeId='';
                    var addonId='';
                    if(rwplist[x].Room_type__c!=undefined){
                        roomtypeId=rwplist[x].Room_type__c.Id;
                    }
                    if(rwplist[x].addon__c!=undefined){
                        addonId=rwplist[x].addon__c.Id;
                    }
                    
                    
                    if(rwplist[x].Name==null || rwplist[x].Name==''){
                        var roomtypeName='';
                        var addonName='';
                        var bbName=rwplist[x].Board_basis__c;
                        if(rwplist[x].Room_type__c!=null){
                            roomtypeName=rwplist[x].Room_type__c.Name;
                        }
                        if(rwplist[x].addon__c!=null){
                            addonName=rwplist[x].addon__c.Name;
                        }
                        rwplist[x].Name=roomtypeName+'+'+bbName+'+'+addonName;
                    }
                    
                    rwpselectedlist.push({'Room_Type__c':roomtypeId,
                                          'Addon__c':addonId,                                      
                                          'Price_Manager_sheet__c':component.get("v.pmsId"),
                                          'Board_Basis__c':rwplist[x].Board_basis__c,
                                          'Value__c':rwplist[x].Value__c,
                                          'Selling_Price__c':rwplist[x].Selling_Price__c,
                                          'Margin_Value__c':rwplist[x].Margin_Value__c,
                                          'Margin_Percent__c':rwplist[x].Margin_Percent__c,
                                          'Price_Period__c':psId,
                                          'Name':rwplist[x].Name,
                                          'Description__c':rwplist[x].Description__c});
                }
            }
            console.log('rwpselectedlist:'+JSON.stringify(rwpselectedlist));
            var pmlist=component.get("v.pmlist");
            var selectedpmlist=[];
            for(var j=0;j<pmlist.length;j++){
                if(pmlist[j].selected__c==true){
                    if((pmlist[j].Value__c!=null && pmlist[j].Value__c!='') && (pmlist[j].Selling_Price__c==null || pmlist[j].Selling_Price__c=='')){
                        // component.find("savebtn").set("v.disabled",true);
                        validated=false;
                    }
                    else{
                        pmlist[j].Price_Period__c=psId;
                        pmlist[j].selected__c=false;
                        selectedpmlist.push(pmlist[j]);
                    }
                    if(pmlist[j].Name==null || pmlist[j].Name==''){
                        var roomtypeName='';
                        var addonName='';
                        var bbName=pmlist[j].Board_Basis__c;
                        if(pmlist[j].Room_Type__c!=null){
                            roomtypeName=pmlist[j].Room_Type__r.Name;
                        }
                        if(pmlist[j].Addon__c!=null){
                            addonName=pmlist[j].Addon__r.Name;
                        }
                        pmlist[j].Name=roomtypeName+'+'+bbName+'+'+addonName;
                    }
                }
            }
            console.log('selectedpmlist:'+JSON.stringify(selectedpmlist));
            if(validated==true){
                var action = component.get("c.saveRoomwiseprices");
                action.setParams({rtId : rtId,
                                  rwplist:JSON.stringify(rwpselectedlist),
                                  pmlist:JSON.stringify(selectedpmlist)});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {                
                        // console.log('response'+JSON.stringify(response.getReturnValue()));
                        component.set("v.pmlist",response.getReturnValue());
                        component.set("v.opmlist",component.get("v.pmlist"));
                        component.set("v.isModalOpen", false);
                    }
                });
                $A.enqueueAction(action); 
                document.getElementById("errmsg").innerHTML='';
            }else{
                document.getElementById("errmsg").innerHTML='Selling Price Required';
            }
        }catch(err){
            console.log('Exception:'+err.stack);
        }
    } ,
        closeModel: function(component, event, helper) {
            // Set isModalOpen attribute to false  
            component.set("v.isModalOpen", false);
        },
            deleteRows:function(component,event,helper){
                var rwplist=component.get("v.rwplist");
                //  console.log('rwplist:'+JSON.stringify(rwplist));
                var rwpselectedlist=[];
                for(var x=0;x<rwplist.length;x++){
                    if(rwplist[x].selected__c!=true){                
                        rwpselectedlist.push(rwplist[x]);
                    }
                }
                component.set("v.rwplist",rwpselectedlist); 
                
                //delete pm selected list also
                var pmlist=component.get("v.pmlist");
                console.log('pmlist:'+JSON.stringify(pmlist));
                var pmselectedlist=[];
                var pmdeletelist=[];
                for(var y=0;y<pmlist.length;y++){
                    if(pmlist[y].selected__c!=true){                
                        pmselectedlist.push(pmlist[y]);
                    }
                    else{
                        pmdeletelist.push(pmlist[y]);   
                    }
                }
                component.set("v.pmlist",pmselectedlist); 
                console.log('pmdeletelist:'+JSON.stringify(pmdeletelist));
                //delete from backend
                var action = component.get("c.deletepmselected");
                action.setParams({
                    delpmlist:JSON.stringify(pmdeletelist)});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {                
                        console.log('response'+JSON.stringify(response.getReturnValue()));               
                    }
                });
                $A.enqueueAction(action);
            },
                doFilter:function(component,event,helper){
                    console.log('doFilter success');
                    var pmlist=component.get("v.opmlist");              
                    var psId=component.get("v.psId");
                    console.log('psId:'+psId);
                    var npmlist=[];
                    for(var x=0;x<pmlist.length;x++){
                        if(pmlist[x].Price_Period__c==psId){
                            npmlist.push(pmlist[x]);
                        }
                    }
                    component.set("v.pmlist",npmlist);
                    console.log('npmlist:'+JSON.stringify(npmlist));
                    var duppmlist=[];
                    var rwplist=component.get("v.rwplist");
                    var orwplist=[];
                    
                    var pmlist=component.get("v.pmlist");
                    if(pmlist!=null){
                        for(var a=0;a<pmlist.length;a++){
                            var rtId='';
                            var bb='';
                            var addId='';
                            if(pmlist[a].Room_Type__r!=null){
                                rtId=pmlist[a].Room_Type__r.Id;
                            }                        
                            if(pmlist[a].Board_Basis__c!=null){
                                bb=pmlist[a].Board_Basis__c;
                            }
                            if(pmlist[a].Addon__r!=null){
                                addId=pmlist[a].Addon__r.Id;
                            }
                            duppmlist.push(rtId+'_'+addId+'_'+bb);
                        }
                    }
                    console.log('duppmlist:'+JSON.stringify(duppmlist));
                    var rooms=component.get("v.roomtypeslist");
                    var bblist=component.get("v.bblist");
                    var addons=component.get("v.addonslist");
                    var roomtypeId=component.get("v.roomtypeId");
                    if(rooms!=null){
                        for(var p=0;p<rooms.length;p++){
                            if(rooms[p].Id==roomtypeId){
                                if(bblist!=null){
                                    for(var q=0;q<bblist.length;q++){
                                        if(!duppmlist.includes(rooms[p].Id+'_'+''+'_'+bblist[q])){
                                            orwplist.push({'Room_type__c':rooms[p],
                                                           'Board_basis__c':bblist[q],
                                                           'Name':rooms[p].Name+'+'+bblist[q]+'+'
                                                          });
                                        }
                                        if(addons!=null){
                                            for(var r=0;r<addons.length;r++){
                                                if(!duppmlist.includes(rooms[p].Id+'_'+addons[r].Id+'_'+bblist[q])){
                                                    orwplist.push({'Room_type__c':rooms[p],
                                                                   'Board_basis__c':bblist[q],
                                                                   'addon__c':addons[r],
                                                                   'Name':rooms[p].Name+'+'+bblist[q]+'+'+addons[r].Name});
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    component.set("v.rwplist",orwplist);
                }
})