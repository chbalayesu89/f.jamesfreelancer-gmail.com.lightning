({
	doInit : function(cmp, event, helper) {
        console.log('getDocslist success');
		  var action = cmp.get("c.getDocslist");
        action.setParams({ p_recordId : cmp.get("v.spId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
              // console.log(‘response’+JSON.stringify(response.getReturnValue()));
                cmp.set("v.flist",response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 
	},
    handleUploadFinished: function (cmp, event) {
        console.log('recordId:'+cmp.get("v.spId"));
        // This will contain the List of File uploaded data and status
        var uploadedFiles = event.getParam("files");
      //  alert("Files uploaded : " + uploadedFiles.length);
        console.log('files uploaded:'+uploadedFiles.length);
         var action = cmp.get("c.getDocslist");
        action.setParams({ p_recordId : cmp.get("v.spId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
              // console.log(‘response’+JSON.stringify(response.getReturnValue()));
                cmp.set("v.flist",response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 

    }
})