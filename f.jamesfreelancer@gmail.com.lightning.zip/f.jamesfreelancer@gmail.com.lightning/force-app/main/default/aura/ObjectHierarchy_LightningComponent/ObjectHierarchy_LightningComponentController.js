({
	myAction : function(component, event, helper) {
		
	},
    afterScriptLoaded : function(component, event, helper) {
        helper.getHierarchyData(component, helper);
	},
    
})