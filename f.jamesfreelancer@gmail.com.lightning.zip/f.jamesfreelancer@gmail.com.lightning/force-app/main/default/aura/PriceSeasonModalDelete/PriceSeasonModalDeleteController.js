({
	myAction : function(component, event, helper) {
		
	},
    delete: function(component, event, helper){
			component.set("v.showSpinner",true);
    var action = component.get("c.deletePriceSeason");
        action.setParams({ psId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               component.set("v.isOpen",false);              
                try{
                    var appEvent = $A.get("e.c:PriceSeasonAdded");            
                    appEvent.setParams({
                        "priceseasonlist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }                   
        		component.set("v.showSpinner",false);
            } 
        });
        $A.enqueueAction(action);   
	}
})