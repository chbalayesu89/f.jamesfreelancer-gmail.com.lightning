({
	getQuoteDetails : function(component,event) {
        component.set("v.showSpinner",true);
		var action = component.get("c.getQuoteWrapper");
        action.setParams({ p_recordId : component.get("v.recordId")  });        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            console.log('state: '+state);
            if (state === "SUCCESS") {
                var presult=response.getReturnValue();
                console.log('presult:'+JSON.stringify(presult));
                component.set("v.qw",presult);
                component.set("v.iq",presult.quote);
               // component.set("v.attId",'');
            }   
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action); 
	},
    getAccommodationPrices:function(component,event){
        console.log('getAccommodationPrices success');
        var dayId=component.get("v.selectedDayId");
        var action = component.get("c.getAccpmList");
        action.setParams({ p_dayId : dayId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                var resp=response.getReturnValue();
                console.log('accpmList:'+JSON.stringify(resp));
                component.set("v.accpmList",resp);
            }
        });
        $A.enqueueAction(action);
    },
    /********** Added by 360 degree akash lavaniya *************/
    getCarHirePrices:function(component,event){
        
        var dayId=component.get("v.selectedDayId");
        var action = component.get("c.getCarHire");
        action.setParams({ p_dayId : dayId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                var resp=response.getReturnValue();
                console.log('carHire:'+JSON.stringify(resp));
                component.set("v.carHire",resp);
            }
        });
        $A.enqueueAction(action);
    },
    getAttractionPrices:function(component,event){
        console.log('getAttractionPrices success');
        var dayId=component.get("v.selectedDayId");
        var action = component.get("c.getAttpmList");
        action.setParams({ p_dayId : dayId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                var resp=response.getReturnValue();
                console.log('attpmList:'+JSON.stringify(resp));
                component.set("v.attpmList",resp);
                var attpmList=component.get("v.attpmList");  
                alert('attpmList2222:'+JSON.stringify(attpmList));
                var attId=component.get("v.attId");
                console.log('attId:'+attId);
                var nattpmList=[];
                component.set("v.nattpmList",nattpmList);
                for(var x=0;x<attpmList.length;x++){
                    console.log('ref item Id:'+attpmList[x].Attraction_Id__c);
                    if(attpmList[x].Attraction_Id__c==attId){
                        nattpmList.push(attpmList[x]);
                    }
                }
                component.set("v.nattpmList",nattpmList);
            }
        });
        $A.enqueueAction(action);
    },
    getRestaurantPrices:function(component,event){
        console.log('getRestaurantPrices success');
        var dayId=component.get("v.selectedDayId");
        var action = component.get("c.getRespmList");
        action.setParams({ p_dayId : dayId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                var resp=response.getReturnValue();
                component.set("v.respmList",resp);
                
                var restaurantList=component.get("v.respmList");  
                var restaurantId=component.get("v.resName");
                var filteredRestaurantList=[];
                component.set("v.nRespmList",filteredRestaurantList);
                var selectMealTime = restaurantId.toLowerCase();
                if(selectMealTime !== 'none'){
                    for(var x=0;x<restaurantList[selectMealTime].length;x++){
                        filteredRestaurantList.push(restaurantList[selectMealTime][x]);
                    }
                }
                component.set("v.nRespmList",filteredRestaurantList);
            }
        });
        $A.enqueueAction(action);
    },
    getAttValues:function(component,event){
        console.log('getAttValues success');
        var dayId=component.get("v.selectedDayId");
        var action = component.get("c.getAttractionList");
        action.setParams({ dayId : dayId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") { 
                var resp=response.getReturnValue();
                console.log('respmList:'+JSON.stringify(resp));
                var attvals=resp;
                var attoptionsvals=[];
                //attoptionsvals.push({ value: '', label: '-- None --' });
                
                //  var attpmList=component.get("v.attpmList");
                for(var x=0;x<attvals.length;x++){
                    attoptionsvals.push({ value: attvals[x].Id, label: attvals[x].Name });
                }
                component.set("v.attoptions",attoptionsvals);              
            }
        });
        $A.enqueueAction(action);
    },
    /********** Added by 360 degree akash lavaniya *************/
    filterRestaurant:function(component,event){
        console.log('doFilter success');
        var restaurantList=component.get("v.respmList");  
        var restaurantId=component.get("v.resName");
        var filteredRestaurantList=[];
        component.set("v.nRespmList",filteredRestaurantList);
        var selectMealTime = restaurantId.toLowerCase();
        for(var x=0;x<restaurantList[selectMealTime].length;x++){
            filteredRestaurantList.push(restaurantList[selectMealTime][x]);
        }
        component.set("v.nRespmList",filteredRestaurantList);
    },
    filterAttractions:function(component,event){
        console.log('doFilter success');
        var attpmList=component.get("v.attpmList");  
        var attId=component.get("v.attId");
        console.log('attId:'+attId);
        var nattpmList=[];
        for(var x=0;x<attpmList.length;x++){
            console.log('ref item Id:'+attpmList[x].Attraction_Id__c);
            if(attpmList[x].Attraction_Id__c==attId){
                nattpmList.push(attpmList[x]);
            }
        }
        component.set("v.nattpmList",nattpmList);
    }
})