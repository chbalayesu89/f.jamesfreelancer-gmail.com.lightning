({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) {
        console.log('doInit');
        helper.getQuoteDetails(component,event);
    },
    closeModel:function(component,event,helper){
        component.set("v.isAttModalOpen",false);        
        component.set("v.isSelectContentModalOpen",false);       
        component.set("v.isEditModalOpen",false);             
        component.set("v.isDeleteModalOpen",false);
        component.set("v.isAddDayModalOpen",false);
        component.set('v.isEditQuoteModalOpen',false);
        component.set("v.isCostingsModalOpen",false);
    },
    openAttPopup:function(component,event,helper){
        component.set("v.isAttModalOpen",true);
        var dayId=event.target.id;
        component.set("v.selectedDayId",dayId);
        helper.getAttValues(component,event);
    },
    saveAttId:function(component,event,helper){
        var selectedattid=component.get("v.selectedAttId");
        var dayId=component.get("v.selectedDayId");
        console.log('selectedAttId:'+selectedattid);
        console.log('dayId:'+dayId);
        
		var action = component.get("c.saveAttractionToDay");
        action.setParams({ 
            attId : selectedattid,
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                 
        		component.set("v.isAttModalOpen",false);                
                helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action); 
    },
    openSelectContent:function(component,event,helper){
        component.set("v.showSpinner",true);
        component.set("v.isSelectContentModalOpen",true);
        var dayId=event.target.id;
        component.set("v.selectedDayId",dayId);
         var action = component.get("c.getContentLibrary");
        action.setParams({ 
           dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {       
                var resp=response.getReturnValue();
               console.log('response'+JSON.stringify(resp));
                 component.set("v.contentLibrary",resp);  
            }
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action); 
    },
    saveContentData:function(component,event,helper){
        console.log('save content data success');
        var dayId=component.get("v.selectedDayId");
        var contentLibrary=component.get("v.contentLibrary");
        var counter=0;
        var featuredimagelinks='';
        for(var x=0;x<contentLibrary.length;x++){
            if(contentLibrary[x].selectbox==true){
                counter++;
                featuredimagelinks+=contentLibrary[x].featuredImage+',';
            }
        }
        if(counter!=3){
            document.getElementById('errmsg').innerHTML='Please select 3 Images';
        }else{
            document.getElementById('errmsg').innerHTML='';
             var action = component.get("c.saveContentLibrary");
            action.setParams({ 
                imglinks:featuredimagelinks,
                dayId:dayId
            });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {                 
                    component.set("v.isSelectContentModalOpen",false);                
                    helper.getQuoteDetails(component,event);
                }
            });
            $A.enqueueAction(action); 
        }
    },
    openDayEditModal:function(component,event,helper){
        console.log('openDayEditModal success');
        var dayId=event.target.id;
        console.log('dayId:'+dayId);
        component.set("v.selectedDayId",dayId);
        var action = component.get("c.getIssueQuoteDay");
        action.setParams({ 
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {       
               var resp=response.getReturnValue();
               console.log('response'+JSON.stringify(resp));
               component.set("v.iqd",resp.objIQD); 
               //component.set("v.attIdSet",resp.setOfIDs);
        	   component.set("v.isEditModalOpen",true);
            }
        });
        $A.enqueueAction(action); 
    },
    saveDayDetails :function(component,event,helper){
        console.log('saveDayDetails success');
        var iqd=component.get("v.iqd");
        if(iqd.Supplier_Product_Accommodation__c!=undefined){
         	iqd.Supplier_Product_Accommodation__c= ''+iqd.Supplier_Product_Accommodation__c;
        }else{
            iqd.Supplier_Product_Accommodation__c=null;
        }
        if(iqd.Supplier_Product_Restaurant__c!=undefined){
        	iqd.Supplier_Product_Restaurant__c=''+iqd.Supplier_Product_Restaurant__c;   
        }else{
            iqd.Supplier_Product_Restaurant__c=null;
        }
        var action = component.get("c.updateIssueQuoteDay");
        action.setParams({ 
            iqd:iqd
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {       
                component.set("v.isEditModalOpen",false);
                helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action); 
    },
    openDayDeleteModal:function(component,event,helper){
        component.set("v.isDeleteModalOpen",true);
        var dayId=event.target.id;
        component.set("v.selectedDayId",dayId);
    },
    deleteDay:function(component,event,helper){
        var dayId=component.get("v.selectedDayId");
         var action = component.get("c.deleteIssueQuoteDay");
        action.setParams({ 
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {       
                component.set("v.isDeleteModalOpen",false);
                helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action); 
    },
    createnewday:function(component,event,helper){
        var qw=component.get("v.qw");
        var quoteId=qw.quote.Id;
        var iqd=component.get("v.iqd"); 
        component.set("v.iqd",{'sobjecttype':'Issue_Quote_Day__c'});
        //console.log('iqd:'+JSON.stringify(component.get("v.iqd"));
        component.set("v.isAddDayModalOpen",true);
    },
    addDayDetails:function(component,event,helper){
        console.log('saveDayDetails success');
        var iqd=component.get("v.iqd");    
        if(iqd.Supplier_Product_Accommodation__c!=undefined){
         	iqd.Supplier_Product_Accommodation__c= ''+iqd.Supplier_Product_Accommodation__c;
        }else{
            iqd.Supplier_Product_Accommodation__c=null;
        }
        if(iqd.Supplier_Product_Restaurant__c!=undefined){
        	iqd.Supplier_Product_Restaurant__c=''+iqd.Supplier_Product_Restaurant__c;   
        }else{
            iqd.Supplier_Product_Restaurant__c=null;
        }
        console.log('iqd:'+JSON.stringify(iqd));
         var qw=component.get("v.qw");
        var iq=component.get("v.iq");
        var quoteId=iq.Id;
        
        var action = component.get("c.addIssueQuoteDay");
        action.setParams({ quoteId:quoteId,
            				iqd:iqd});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {         
                component.set("v.isAddDayModalOpen",false);
                helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action);
    },
    editquote:function(component,event,helper){
        console.log('editquote success');
        component.set('v.isEditQuoteModalOpen',true);
    },
    updateIQDetails:function(component,event,helper){
        var iq=component.get("v.iq");
    	 var action = component.get("c.saveQuoteDetails");
        action.setParams({ iq:iq});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {             
                component.set("v.isEditQuoteModalOpen",false);
                helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action);
	},
    doSyncup:function(component,event,helper){
        helper.getQuoteDetails(component,event);
    },
    openCostings:function(component,event,helper){
        console.log('openCostings success');
         var dayId=event.target.id;
        console.log('dayId:'+dayId);
        component.set("v.selectedDayId",dayId);
        component.set("v.isCostingsModalOpen",true);
    },
    accselectTab : function(component, event, helper) { 
        console.log('accselectTab success');
        component.set("v.selectedTab",'accTab');
        var dayId=component.get("v.selectedDayId");        
        helper.getAccommodationPrices(component,event);
    },
    /********** Added by 360 degree akash lavaniya *************/
    carselectTab : function(component, event, helper) { 
        console.log('accselectTab success');
        component.set("v.selectedTab",'carHire');
        var dayId=component.get("v.selectedDayId");        
        helper.getCarHirePrices(component,event);
    },
    attselectTab : function(component, event, helper) { 
        component.set("v.selectedTab",'attTab');
        console.log('attselectTab success');
        //component.set("v.nattpmList",[]);
        var dayId=component.get("v.selectedDayId"); 
        helper.getAttractionPrices(component,event);         
        helper.getAttValues(component,event);
    }
    ,
    resselectTab : function(component, event, helper) { 
        component.set("v.selectedTab",'resTab');
        console.log('attselectTab success');
        var dayId=component.get("v.selectedDayId");       
        helper.getRestaurantPrices(component,event);
    },
    
    savecostings: function(component, event, helper) { 
        console.log('savecostings success');
        var dayId=component.get("v.selectedDayId");  
        var accpmList=component.get("v.accpmList");
        var attpmList=component.get("v.nattpmList");
        var respmList=component.get("v.nRespmList");
        var carHireVal=component.get("v.carHire"); /********** Added by 360 degree akash lavaniya *************/
        var action = component.get("c.saveCostingData");
        action.setParams({ 
            p_accpmList : accpmList,
            p_attpmList:attpmList,
            p_respmList:respmList,
            p_carHire:carHireVal, /********** Added by 360 degree akash lavaniya *************/
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
               //console.log(‘response’+JSON.stringify(response.getReturnValue()));
                var selTab=component.get('v.selectedTab');
               
                if(selTab==undefined){
                    selTab='accTab';
                }          
                if(selTab=='accTab')
                 	helper.getAccommodationPrices(component,event);
                if(selTab=='attTab'){
                	helper.getAttractionPrices(component,event);                        
                }
                if(selTab=='carHire'){
                	helper.getCarHirePrices(component,event);   /********** Added by 360 degree akash lavaniya *************/                      
                }
                if(selTab=='resTab'){
                    helper.getRestaurantPrices(component,event);
                    helper.filterRestaurant(component,event)
                }
                 	
                helper.getQuoteDetails(component,event);
            }
            else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        alert("Error message: " + 
                                    errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
           // component.set("v.isCostingsModalOpen",false);
        });
        $A.enqueueAction(action); 

    },
    doFilter:function(component,event,helper){
        helper.filterAttractions(component,event);       
    },
    /********** Added by 360 degree akash lavaniya *************/
    doFilterRestaurant:function(component,event,helper){
        helper.filterRestaurant(component,event);       
    },
    
    saveallcostings: function(component, event, helper) { 
        console.log('saveallcostings success');
        var dayId=component.get("v.selectedDayId");  
        var accpmList=component.get("v.accpmList");
        var attpmList=component.get("v.nattpmList");
        var respmList=component.get("v.respmList"); /********** Added by 360 degree akash lavaniya *************/
        var carHireVal=component.get("v.carHire"); /********** Added by 360 degree akash lavaniya *************/
      	var action = component.get("c.saveCostingData");
        action.setParams({ 
            p_accpmList : accpmList,
            p_attpmList:attpmList,
            p_respmList:respmList,
            p_carHire:carHireVal, /********** Added by 360 degree akash lavaniya *************/
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
               //console.log(‘response’+JSON.stringify(response.getReturnValue()));
               helper.getQuoteDetails(component,event);
               helper.getAccommodationPrices(component,event);
               helper.getAttractionPrices(component,event);         
               helper.getRestaurantPrices(component,event);
               helper.getCarHirePrices(component,event); 
            }
            component.set("v.isCostingsModalOpen",false);
        });
        $A.enqueueAction(action); 
    },
    updateAttractionIdSet: function(component, event, helper) { 
        var selectedattid = event.getSource().get("v.value");        
        var dayId=component.get("v.selectedDayId");
        console.log('selectedAttId:'+selectedattid);
        console.log('dayId:'+dayId);
        
		var action = component.get("c.removeAttractionFromDay");
        action.setParams({ 
            attId : selectedattid,
            dayId:dayId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                                 
                component.set("v.isAttModalOpen",false);
        		//helper.getAttValues(component,event);
        		helper.getQuoteDetails(component,event);
            }
        });
        $A.enqueueAction(action);       
    }
})