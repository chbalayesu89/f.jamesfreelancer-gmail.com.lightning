({
    myAction : function(component, event, helper) {
        
    },
    
    doInit: function(component, event, helper){
        try{
            console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
            helper.doRefresh(component,event);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    addImage : function(component,event,helper){
        console.log('addImage');        
        var accId=component.get("v.sId");
        console.log('accId:'+accId);
        if(accId==null || accId=='' || accId==undefined){
            component.set("v.showAccountAlert",true);
        }
        else{
            var accountFolderId=component.get("v.accountFolderId");
            var contentFolderId=component.get("v.contentFolderId");
            console.log('accountFolderId:'+accountFolderId);
            console.log('contentFolderId:'+contentFolderId);
            if(accountFolderId==undefined && contentFolderId==undefined){
                component.set("v.showSpinner",true);
                var sId=component.get("v.sId");
                var spId=component.get("v.spId");
                var itc=component.get("v.itc");
                var action = component.get("c.createOnedriveFolder");
                action.setParams({ p_accId : sId,
                                  p_spId:spId,
                                  p_itcId:itc.Id
                                 });
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS") {         
                        var resp=response.getReturnValue();
                        console.log("response"+JSON.stringify(response.getReturnValue()));                          
                        component.set("v.odf",resp);
                        var odf=component.get("v.odf");
                        if(odf!=undefined){
                    		component.set("v.accountFolderId",odf.onedrive_Id__c);
                    		helper.saveContent(component,event);  
                    	}                                      
                    }   
                    component.set("v.showSpinner",false);                   
                });
                $A.enqueueAction(action);
            }else{
                 if(accountFolderId!=undefined && contentFolderId!=undefined){
                	component.set("v.itcupload",true);   
                 }else{
                     var toastEvent = $A.get("e.force:showToast");
                     toastEvent.setParams({
                         "title": "Please Wait...",
                         "message": "Creating Folder in Onedrive..."
                     });
                     toastEvent.fire();
                     helper.doRefresh(component,event);
                 }
            }
        }
    },
    addFeaturedImage: function(component,event,helper){
        console.log('addFeaturedImage');
        component.set("v.itc_feature_select",true);
    },
    dpfileAdded: function(component, event, helper) {       
        try{           
            helper.doRefresh(component,event);           
        }catch(err){
            console.log('Exception:'+err.stack);
        }                
    },
    featuredImageSelect: function(component, event, helper) {
        console.log('--- featuredImageSelect ---');
        
        var filink = event.getParam("FeaturedImageLink");
        console.log('filink: '+filink);
        component.set("v.featuredImage",filink);
        
        try{
            //component.set("v.showSpinner",true);
            helper.doRefresh(component,event);
           // component.set("v.showSpinner",false);
        }catch(err){
            console.log('Exception:'+err.stack);
        }
    },
    edit: function(component,event,helper){
        console.log('edit');
        component.set("v.edit",true);
    },
    deleteic: function(component,event,helper){
        console.log('delete');
        component.set("v.showdelete",true);
    },
    itemContentEdit: function(component, event, helper) {
        console.log('--- itemContentEdit ---');
       
         var id = component.get("v.recordId");
        var container = component.find("container");
        $A.createComponent("force:recordView",
                           {recordId: id,type: "FULL"},
                           function(cmp) {
                               container.set("v.body", [cmp]);
                           });
   } ,
    doSync:function(component,event,helper){
        try{
            
            helper.doRefresh(component,event);
            
        }catch(err){
            console.log('Exception:'+err.stack);
        }
    },
    delsave:function(component,event,helper){
        var action = component.get("c.deleteItemContent");
        action.setParams({ icId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            component.set("v.showdelete",false);
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                console.log('response: '+JSON.stringify(response.getReturnValue()));
                var resp=response.getReturnValue();
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url": "/"+resp
                });
                urlEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    closeModel:function(component,event,helper){
        component.set("v.showdelete",false);
        component.set("v.isDeleteImageModalOpen",false);
        component.set("v.showSpinner",false);
        component.set("v.showAccountAlert",false);
    },
    delImage:function(component,event,helper){
        console.log('delImage success');
        var odimage=event.target.id;
        console.log('odimage:'+odimage);
        component.set("v.odimage",odimage);
        component.set("v.isDeleteImageModalOpen",true);
    }    ,
    delContentData:function(component,event,helper){
        component.set("v.showSpinner",true);
        console.log('delContentData success');
        component.set("v.isDeleteImageModalOpen",false);
        var odimage=component.get("v.odimage");
        var odarr=odimage.split(';');
        var itemId=odarr[0];
        var driveId=odarr[1];
        console.log('itemId:'+itemId);
        console.log('driveId:'+driveId);
        var action = component.get("c.deleteImagefromOnedrive");
        action.setParams({ p_itemId : itemId,
                          p_driveId: driveId});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
                console.log("response"+JSON.stringify(response.getReturnValue()));
                helper.doRefresh(component,event); 
            }
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
        
    } ,
    createSupplier:function(component,event,helper){
        console.log('create Supplier success');
        component.set("v.showSpinner",true);
        var sId=component.get("v.sId");
        var spId=component.get("v.spId");  
        var itc=component.get("v.itc");
        if(sId==null){
            document.getElementById("sp_msg").innerHTML='Supplier Not Selected';
        }else{
            component.set("v.accountFolderId",'');
            component.set("v.contentFolderId",'');                
            component.set("v.showAccountAlert",false);
            var action = component.get("c.createOnedriveFolder");
            action.setParams({ p_accId : sId,
                              p_spId:spId,
                              p_itcId:itc.Id
                             });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {         
                    var resp=response.getReturnValue();
                    console.log("response"+JSON.stringify(response.getReturnValue()));   
                    component.set("v.odf",resp);
                    var odf=component.get("v.odf");
                    console.log('odf:'+odf);
                    if(odf!=undefined){
                    	component.set("v.accountFolderId",odf.onedrive_Id__c);
                    	helper.saveContent(component,event);  
                    }
                }   
                component.set("v.showSpinner",false);
            });
            $A.enqueueAction(action);
        }
    }
})