({
	doRefresh : function(component,event) {
         component.set("v.showSpinner",true);
		 var action = component.get("c.getItemContent");
        action.setParams({ icId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {                
                console.log('response: '+JSON.stringify(response.getReturnValue()));
                var resp=response.getReturnValue();
                component.set("v.accountFolderId",resp.accountFolderId);
                component.set("v.contentFolderId",resp.contentFolderId);
                component.set("v.itc",resp.ic);
                try{
                    var itc=component.get("v.itc");
                    component.set('v.spId',itc.Supplier_Product__c);
                    component.set('v.sId',itc.Supplier_Product__r.Supplier__c);
                    
                    var spId=component.get("v.spId");
                    var sId=component.get("v.sId");                   
                }catch(err){
                    console.log(err.stack);
                }
                console.log('itc: '+JSON.stringify(component.get("v.itc")));
                component.set("v.odilist",resp.odilist); 
				var odilist=component.get("v.odilist");  
                var featuredId=component.get("v.itc").Featured_Image_Link__c;
                if(odilist!=null && featuredId!=null){
                for(var x=0;x<odilist.length;x++){
                    if((featuredId).includes(odilist[x].id)){
                        component.set("v.fimagelink",odilist[x].downloadUrl);
                        break;
                    }
                }
                    console.log('fimagelink:'+component.get("v.fimagelink"));
                }
                
            }  
            
            component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
	},
    saveContent:function(component,event){
        component.set("v.showSpinner",true);
        var itc=component.get("v.itc");
        var odf=component.get("v.odf");
         var action = component.get("c.addContentFolder");
        action.setParams({ p_odf : odf,
                          p_itcId:itc.Id
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {         
                var resp=response.getReturnValue();
                component.set("v.itc",resp.ic);
                component.set("v.accountFolderId",resp.accountFolderId);
                component.set("v.contentFolderId",resp.contentFolderId);                
                try{
                    var itc=component.get("v.itc");
                    component.set('v.spId',itc.Supplier_Product__c);
                    component.set('v.sId',itc.Supplier_Product__r.Supplier__c);
                    var spId=component.get("v.spId");
                    var sId=component.get("v.sId");                   
                }catch(err){
                    console.log(err.stack);
                }
                console.log('itc: '+JSON.stringify(component.get("v.itc")));
                component.set("v.odilist",resp.odilist); 
				var odilist=component.get("v.odilist");  
                var featuredId=component.get("v.itc").Featured_Image_Link__c;
                if(odilist!=null && featuredId!=null){
                for(var x=0;x<odilist.length;x++){
                    if((featuredId).includes(odilist[x].id)){
                        component.set("v.fimagelink",odilist[x].downloadUrl);
                        break;
                    }
                }
                    console.log('fimagelink:'+component.get("v.fimagelink"));
                }
                console.log("response"+JSON.stringify(response.getReturnValue()));
            }   
            component.set("v.showSpinner",false);
        });
        	$A.enqueueAction(action);
    }
})