({
	getAccountDetails : function(component,event) {
		 //get case wrapper
	 	var inv=component.get("v.inv");
       // console.log('inv:'+JSON.stringify(inv));
        var action = component.get("c.getAccountWrapper");
        action.setParams({ p_accountId : ''+component.get("v.accountId")  });        
        action.setCallback(this, function(response) {
            var state = response.getState(); 
            console.log('state: '+state);
            if (state === "SUCCESS") {
                var presult=response.getReturnValue();
                console.log('presult:'+JSON.stringify(presult));
                console.log('presult: '+JSON.stringify(presult));
                component.set("v.cw",presult);
                component.set("v.tclist",presult.tclist);
                component.set("v.customerlist",presult.clist);
                component.set("v.mslist",presult.mslist);
                component.set("v.dmlist",presult.dmlist);
                component.set("v.commlist",presult.commlist);
                component.set("v.aflist",presult.aflist);
                component.set("v.caselist",presult.caselist);                
                component.set("v.xrmslist",presult.mslist);
                component.set("v.xrdmlist",presult.dmlist);
                component.set("v.xraflist",presult.aflist);
                
                component.set("v.itemlist",presult.itemlist);
                inv.Invoice_Number__c=presult.InvNumber;
                component.set("v.inv",inv);
                console.log('inv:'+JSON.stringify(component.get("v.inv")));
                component.set("v.xero_taxrates",presult.xero_taxrates);
            }             
        });
        $A.enqueueAction(action); 
	},
    setInvAmount:function(component){
        console.log('setInvAmount success');
        var tcmlist=component.get("v.tclist");
        console.log('tcmlist size:'+tcmlist.length);
        var tcmId=component.get("v.tcmId");
        console.log('tcmId:'+tcmId);
        var msvalue=0;
        for(var x=0;x<tcmlist.length;x++){
            if(tcmlist[x].Id==tcmId){
                msvalue=tcmlist[x].Milestone_Value__c;               
                break;
            }
        }
        var inv=component.get("v.inv");
        inv.Invoice_Amount__c=msvalue;
        component.set("v.inv",inv);
    },
    setInvWithTax:function(component){
        console.log('calculateInvoiceAmount success');
       var inv=component.get("v.inv");        
      //  console.log('inv:'+JSON.stringify(inv));
        var invamt=inv.Invoice_Amount__c;
        var xero_rates=component.get("v.xero_taxrates");
        var taxtype=inv.XERO_TaxType__c;
        console.log('taxtype:'+taxtype);
        var rate=0.0;
        //get rate
        for(var x=0;x<xero_rates.length;x++){
            if(xero_rates[x].Name==taxtype){
                rate=xero_rates[x].Rate__c;
                break;
            }
        }
        console.log('rate:'+rate);
        var transtype=inv.Transaction_Type__c;   
        console.log('transaction:'+transtype);
        var taxamt=0;
        var totalinvamt=invamt;
        //calculate amounts
        try{
            if(invamt!=null && rate!=0 && transtype!=''){
                if(transtype=='Inclusive of GST / VAT'){
                    taxamt=parseFloat(invamt*(rate/(100+rate))).toFixed(2);
                    totalinvamt=invamt-taxamt; //5000-(5000/(100+10))
                    /*
                    //milestones
                    var mslist=component.get("v.mslist");
                    for(var x=0;x<mslist.length;x++){                        
                        var msvalue=mslist[x].Milestone_Value__c;
                        var mstax=parseFloat(msvalue/(100+rate)).toFixed(2);
                        mslist[x].XERO_Milestone_Value__c=msvalue-mstax;
                    }
                    component.set("v.mslist",mslist);
                    //disbursements
                    var dmlist=component.get("v.dmlist");
                    for(var x=0;x<dmlist.length;x++){
                        var dmvalue=dmlist[x].Milestone_Value__c;
                        var dmtax=parseFloat(dmvalue/(100+rate)).toFixed(2);
                        dmlist[x].XERO_Milestone_Value__c=dmvalue-dmtax;
                    }
                    component.set("v.dmlist",dmlist);
                    
                    //admin fee
                    var aflist=component.get("v.aflist");
                    for(var x=0;x<aflist.length;x++){
                        var afvalue=aflist[x].Value;
                        var aftax=parseFloat(afvalue/(100+rate)).toFixed(2);
                        aflist[x].XERO_Milestone_Value=afvalue-aftax;
                    }
                    component.set("v.aflist",aflist);
                    */
                }
                else if(transtype='Exclusive of GST / VAT'){
                    taxamt=parseFloat(invamt*(rate/(100))).toFixed(2);
                    totalinvamt=parseFloat(invamt)+parseFloat(taxamt);  //5000+(5000%10))   
                    /*
                     //milestones
                    var mslist=component.get("v.mslist");
                    for(var x=0;x<mslist.length;x++){                        
                        var msvalue=mslist[x].Milestone_Value__c;
                        var mstax=parseFloat(msvalue/rate).toFixed(2);
                        mslist[x].XERO_Milestone_Value__c=parseFloat(msvalue)+parseFloat(mstax);
                    }
                    component.set("v.mslist",mslist);
                    //disbursements
                    var dmlist=component.get("v.dmlist");
                    for(var x=0;x<dmlist.length;x++){
                        var dmvalue=dmlist[x].Milestone_Value__c;
                        var dmtax=parseFloat(dmvalue/rate).toFixed(2);
                        dmlist[x].XERO_Milestone_Value__c=parseFloat(dmvalue)+parseFloat(dmtax);
                    }
                    component.set("v.dmlist",dmlist);
                    
                    //admin fee
                    var aflist=component.get("v.aflist");
                    for(var x=0;x<aflist.length;x++){
                        var afvalue=aflist[x].Value;
                        var aftax=parseFloat(afvalue/rate).toFixed(2);
                        aflist[x].XERO_Milestone_Value=parseFloat(afvalue)+parseFloat(aftax);
                    }
                    component.set("v.aflist",aflist); */
                }  
                
            }
        }catch(err){
            console.log('Exception:'+err.stack);
        }
        inv.Tax_Amount__c=taxamt;
        inv.Total_Invoice_Amount__c=totalinvamt;
        component.set("v.inv",inv);
    
    }
})