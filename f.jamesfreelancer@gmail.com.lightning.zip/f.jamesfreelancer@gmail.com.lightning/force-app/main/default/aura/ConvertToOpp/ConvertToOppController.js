({
    myAction : function(component, event, helper) {
        
    },
    doInit : function(component, event, helper) {
        console.log('doInit success');       
        var url="{!URLFOR($Action.Lead.Convert, lead.id, [retURL=URLFOR($Action.Lead.Convert, Lead.Id)], true)}";
        //alert('url:'+url);
      	window.open(url,'_self');
    },
})