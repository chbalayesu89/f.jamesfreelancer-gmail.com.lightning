({
	myAction : function(component, event, helper) {
		
	},
    delete: function(component, event, helper){
			component.set("v.showSpinner",true);
    var action = component.get("c.deleteRoomType");
        action.setParams({ rtId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
               component.set("v.isOpen",false);              
                try{
                    var appEvent = $A.get("e.c:RoomTypeAdded");            
                    appEvent.setParams({
                        "roomtypeslist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }                   
        		component.set("v.showSpinner",false);
            } 
        });
        $A.enqueueAction(action);   
	},
        closeModel:function(component,event,helper){
            component.set("v.isOpen",false);   
        }
})