({
	myAction : function(component, event, helper) {
		
	},
    doinit: function (cmp, event, helper) {
        console.log('ItemGeolocation >> doinit');       
    }
})