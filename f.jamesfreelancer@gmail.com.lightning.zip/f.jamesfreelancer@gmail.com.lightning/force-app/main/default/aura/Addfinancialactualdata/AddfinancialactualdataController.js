({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) { 
		console.log('doInit success');      
       
       console.log('recordId: '+component.get("v.recordId"));       
        var action = component.get("c.getTargetRecord");
        action.setParams({ tId : component.get("v.recordId") });        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                console.log('response: '+JSON.stringify(response.getReturnValue()));
                component.set("v.tgobj",response.getReturnValue());
                //check is he belongs to Financial Team Group
               if(component.get("v.tgobj").login_user_group_name__c!='Finance Team Group'){
                    // show error message
                   component.set("v.showError",true);                    
                }
              //  component.set("v.review",component.get("v.tg").Employee_Review_Records__r);
            }             
        });
        $A.enqueueAction(action);        
	},
    closeModel: function(component, event, helper) {
      // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
       // window.open('/'+component.get("v.recordId"),"_self");
        var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
      "url": "/"+component.get("v.recordId")
    });
    urlEvent.fire();
   },
    saveModel: function(component, event, helper) {
        console.log('saving data to server');        
        var action = component.get("c.saveFAD");
        var faobj=component.get("v.faobj");
        faobj.quarter_budget_target__c=component.get("v.recordId");
        component.set("v.faobj",faobj);
       action.setParams({ fadata : component.get("v.faobj") });          
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    console.log('data saved.'); 
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+component.get("v.recordId")
                    });
                    urlEvent.fire();
                     $A.get("e.force:closeQuickAction").fire();
                }                  
            });
            $A.enqueueAction(action);         
   },    
    enablesavebtn : function(component,event,helper){
        var rdataobj=component.get("v.faobj");
        console.log('faobj: '+JSON.stringify(component.get("v.faobj")));      
        var msg=''; 
       if(rdataobj.Value_achieved__c!=undefined && rdataobj.From_Date__c!=undefined && rdataobj.To_Date__c!=undefined && rdataobj.Name!=undefined &&
          rdataobj.Value_achieved__c!='' && rdataobj.From_Date__c!='' && rdataobj.To_Date__c!='' && rdataobj.Name!=''){
            component.find("savebtn").set("v.disabled",false); 
        }         
        else{
        	component.find("savebtn").set("v.disabled",true); 
        }
    },
     toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
     }
})