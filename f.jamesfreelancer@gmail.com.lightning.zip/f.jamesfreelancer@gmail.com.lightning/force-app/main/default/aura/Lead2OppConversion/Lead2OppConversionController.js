({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component,event,helper){                       
        component.set("v.showSpinner",true);
        console.log('isOpen: '+component.get('v.isOpen'));
        console.log('doInit >>> recordId: '+component.get("v.recordId"));
        var action=component.get("c.setOpportunity");
        action.setParams({leadId:component.get("v.recordId")});
        action.setCallback(this,function(response){
            var state=response.getState();
            if(state==='SUCCESS'){
                component.set("v.opp",response.getReturnValue());
                console.log('opp: '+JSON.stringify(component.get("v.opp")));
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action);
    },
    save : function(component,event,helper){
        console.log('save >> opp: '+JSON.stringify(component.get("v.opp"))); 
        component.set("v.showSpinner",true);
          var action=component.get("c.saveOpportunity");
        action.setParams({opp:component.get("v.opp")});
        action.setCallback(this,function(response){
            var state=response.getState();
            if(state==='SUCCESS'){                
        component.set("v.showSpinner",true);
                var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+response.getReturnValue()
        });
        urlEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    cancel : function(component,event,helper){
        console.log('cancel');
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+component.get("v.recordId")
        });
        urlEvent.fire();
    }
})