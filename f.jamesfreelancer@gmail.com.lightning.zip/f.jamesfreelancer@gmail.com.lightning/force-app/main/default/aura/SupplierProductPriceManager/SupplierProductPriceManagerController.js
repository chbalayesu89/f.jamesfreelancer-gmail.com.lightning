({
    myAction : function(component, event, helper) {
        
    }
    , 	
     managePrice: function(component, event, helper) { 
         try{
             component.set("v.psId",'');
             component.set("v.isModalOpen", true);
             component.set("v.isEditOpen",false);
              var psoptionsvals=[];
    psoptionsvals.push({ value: '', label: '-- None --' });
             component.set("v.psoptions",psoptionsvals);
       var psId=component.get("v.psId");
    	//var roomtypeId=event.target.id;
    	// component.set("v.rtId",roomtypeId);
       // component.set("v.rwplist",[]);
        // Set isModalOpen attribute to false  
        //  console.log('add price');
        var attitemlist=component.get("v.attitemlist");
             console.log('attitemlist:'+JSON.stringify(attitemlist));
        var addons=component.get("v.addonslist");
    	var priceseason=component.get("v.priceseasonlist");
   
    // set ps options
    for(var x=0;x<priceseason.length;x++){
        psoptionsvals.push({ value: priceseason[x].Id, label: priceseason[x].Name });
    }
    component.set("v.psoptions",psoptionsvals);
    	console.log('priceseasons: '+JSON.stringify(priceseason));
        var sp=component.get("v.sp");
        var rwp=component.get("v.rwp");
       
        var rwplist=component.get("v.rwplist");
             var orwplist=[];
             component.set("v.rwplist",orwplist);
      //  console.log('rooms.length:'+JSON.stringify(rooms));
         /*    if(attitemlist!=null){
        for(var p=0;p<attitemlist.length;p++){    
            rwplist.push({'Attraction_Item__c':attitemlist[p]});
            if(addons!=null){
                for(var r=0;r<addons.length;r++){
                    rwplist.push({'Attraction_Item__c':attitemlist[p],
                                  'addon__c':addons[r]});
                }
            }
        }          
       }*/
     
      //  console.log('rwplist:'+JSON.stringify(rwplist));
    	
       // var roomtypeId=event.target.id;
     var spId=component.get("v.sp").Id;
  //  console.log('managePrice roomtype Id:'+roomtypeId);
    
    var action = component.get("c.doManagePrice");
        action.setParams({spId : sp.Id
                          });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {   
                try{
               console.log('pmlist'+JSON.stringify(response.getReturnValue()));
                component.set("v.pmlist",response.getReturnValue());
                 component.set("v.opmlist",component.get("v.pmlist"));
                var duppmlist=[];
                var pmlist=component.get("v.pmlist");
                if(pmlist!=null){
                	for(var a=0;a<pmlist.length;a++){
                        var attId='';
                        var addId='';
                        if(pmlist[a].Attraction_Item__r!=null){
                            attId=pmlist[a].Attraction_Item__r.Id;
                        }
                        if(pmlist[a].Addon__r!=null){
                            addId=pmlist[a].Addon__r.Id;
                        }
                    	duppmlist.push(attId+'_'+addId);
                	}
                }
                console.log('duppmlist:'+JSON.stringify(duppmlist));
                if(attitemlist!=null){
                    for(var p=0;p<attitemlist.length;p++){   
                        console.log('filter1:'+!duppmlist.includes(attitemlist[p].Id+'_'+''));
                        if(!duppmlist.includes(attitemlist[p].Id+'_'+'')){
                        	rwplist.push({'Attraction_Item__c':attitemlist[p],
                                          'Name':attitemlist[p].Name});                            
                        }
                        if(addons!=null){
                            for(var r=0;r<addons.length;r++){
                                console.log('filter2:'+!duppmlist.includes(attitemlist[p].Id+'_'+addons[r].Id));
                                if(!duppmlist.includes(attitemlist[p].Id+'_'+addons[r].Id)){
                                rwplist.push({'Attraction_Item__c':attitemlist[p],
                                              'addon__c':addons[r],
                                              'Name':attitemlist[p].Name+'+'+addons[r].Name});
                                }
                            }
                        }
                    }          
                }
                   component.set("v.rwplist",rwplist);
                console.log('rwplist:'+JSON.stringify(component.get("v.rwplist")));
                var epmlist=[];
               //remove zero and replace it as empty string
                for(var b=0;b<pmlist.length;b++){
                    if(pmlist[b].Attraction_Item__c!=null){
                        if(pmlist[b].Name==null || pmlist[b].Name==''){
                    		pmlist[b].Name=pmlist[b].Attraction_Item__r.Name+'+'+pmlist[b].Addon__r.Name;
                        }
                    	//pmlist[b].Description__c=pmlist[b].Attraction_Item__r.Description__c;
                    }
                    if(pmlist[b].Value__c==0){
                        pmlist[b].Value__c='';
                    }
                    if(pmlist[b].Selling_Price__c==0){
                        pmlist[b].Selling_Price__c='';
                    }
                    if(pmlist[b].Margin_Value__c==0){
                        pmlist[b].Margin_Value__c='';
                    }
                    if(pmlist[b].Margin_Percent__c==0){
                        pmlist[b].Margin_Percent__c='';
                    }
                    epmlist.push(pmlist[b]);                   
                }
                component.set("v.pmlist",epmlist);
                component.set("v.opmlist",epmlist);
            }catch(err){
                console.log('ERROR:'+err.stack);
            }
            }
        });
        $A.enqueueAction(action); 
         }catch(err){
             console.log('Exception:'+err.stack);
         }
    },
    submitDetails:function(component,event,helper){
        try{
        var spId=component.get("v.sp").Id;
        var rwplist=component.get("v.rwplist");
        var psId=component.get("v.psId");
       
        console.log('rwplist:'+JSON.stringify(rwplist));
        var rwpselectedlist=[];
        var validated=true;
        for(var x=0;x<rwplist.length;x++){
            if(rwplist[x].selected__c==true){ 
                if((rwplist[x].Value__c!=null && rwplist[x].Value__c!='') && (rwplist[x].Selling_Price__c==null || rwplist[x].Selling_Price__c=='')){
                  //  component.find("savebtn").set("v.disabled",true);
                    validated=false;
                }
                var attitemId='';
                var addonId='';
                if(rwplist[x].Attraction_Item__c!=undefined){
                    attitemId=rwplist[x].Attraction_Item__c.Id;
                }
                if(rwplist[x].addon__c!=undefined){
                    addonId=rwplist[x].addon__c.Id;
                }
                if(rwplist[x].Name==null || rwplist[x].Name==''){
                    var attName='';
                    var addName='';
                    if(rwplist[x].Attraction_Item__c!=null){
                    	attName=rwplist[x].Attraction_Item__c.Name;
                    }
                    if(rwplist[x].addon__c!=null){
                        addName=rwplist[x].addon__c.Name;
                    }
                    rwplist[x].Name=attName+'+'+addName;
                }
                rwpselectedlist.push({'Attraction_Item__c':attitemId,
                                      'Addon__c':addonId,                                      
                                      'Price_Manager_sheet__c':component.get("v.pmsId"),
                                      'Value__c':rwplist[x].Value__c,
                                      'Selling_Price__c':rwplist[x].Selling_Price__c,
                                      'Margin_Value__c':rwplist[x].Margin_Value__c,
                                      'Margin_Percent__c':rwplist[x].Margin_Percent__c,
                                      'Price_Period__c':psId,
                                      'Name':rwplist[x].Name,
                                      'Description__c':rwplist[x].Description__c});
            }
        }
        console.log('rwpselectedlist:'+JSON.stringify(rwpselectedlist));
        var pmlist=component.get("v.pmlist");
        var selectedpmlist=[];
        for(var j=0;j<pmlist.length;j++){
            if(pmlist[j].selected__c==true){
                if((pmlist[j].Value__c!=null && pmlist[j].Value__c!='') && (pmlist[j].Selling_Price__c==null || pmlist[j].Selling_Price__c=='')){
                   // component.find("savebtn").set("v.disabled",true);
                    validated=false;
                }
                else{
                    pmlist[j].Price_Period__c=psId;
                    pmlist[j].selected__c=false;
                    selectedpmlist.push(pmlist[j]);
                }
                if(pmlist[j].Name==null || pmlist[j].Name==''){
                    var attName='';
                    var addName='';
                    if(pmlist[j].Attraction_Item__c!=null){
                    	attName=pmlist[j].Attraction_Item__r.Name;
                    }
                    if(pmlist[j].Addon__c!=null){
                    	addName=pmlist[j].Addon__r.Name;
                    }
                    pmlist[j].Name=attName+'+'+addName;
                }
            }
        }
        console.log('selectedpmlist:'+JSON.stringify(selectedpmlist));
            
            console.log('validated? '+validated);
        if(validated==true){
         var action = component.get("c.saveRoomwiseprices");
        action.setParams({spId : spId,
                          rwplist:JSON.stringify(rwpselectedlist),
                          pmlist:JSON.stringify(selectedpmlist)});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
              // console.log('response'+JSON.stringify(response.getReturnValue()));
                component.set("v.pmlist",response.getReturnValue());
                component.set("v.isModalOpen", false);
            }
        });
        $A.enqueueAction(action); 
            document.getElementById("errmsg").innerHTML='';
        }else{
            document.getElementById("errmsg").innerHTML='Selling Price Required';
        }
        }catch(err){
            console.log('Exception:'+err.stack);
        }
    } ,
        closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
        deleteRows:function(component,event,helper){
             var rwplist=component.get("v.rwplist");
      //  console.log('rwplist:'+JSON.stringify(rwplist));
        var rwpselectedlist=[];
        for(var x=0;x<rwplist.length;x++){
            if(rwplist[x].selected__c!=true){                
                rwpselectedlist.push(rwplist[x]);
            }
        }
           component.set("v.rwplist",rwpselectedlist); 
            
            //delete pm selected list also
             var pmlist=component.get("v.pmlist");
            console.log('pmlist:'+JSON.stringify(pmlist));
             var pmselectedlist=[];
            var pmdeletelist=[];
            for(var y=0;y<pmlist.length;y++){
                if(pmlist[y].selected__c!=true){                
                    pmselectedlist.push(pmlist[y]);
                }
                else{
                    pmdeletelist.push(pmlist[y]);   
                }
            }
            component.set("v.pmlist",pmselectedlist); 
            console.log('pmdeletelist:'+JSON.stringify(pmdeletelist));
            //delete from backend
            var action = component.get("c.deletepmselected");
            action.setParams({
                delpmlist:JSON.stringify(pmdeletelist)});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {                
                    console.log('response'+JSON.stringify(response.getReturnValue()));               
                }
            });
            $A.enqueueAction(action);
        },
            doFilter:function(component,event,helper){
                console.log('doFilter success');
                var pmlist=component.get("v.opmlist");  
                    var attitemlist=component.get("v.attitemlist");
        var addons=component.get("v.addonslist");
    	var priceseason=component.get("v.priceseasonlist");
                var psId=component.get("v.psId");
                console.log('psId:'+psId);
                var npmlist=[];
                for(var x=0;x<pmlist.length;x++){
                    if(pmlist[x].Price_Period__c==psId){
                        if(pmlist[x].Name==null || pmlist[x].Name==''){
                            var attName='';
                            var addName='';
                            if(pmlist[x].Attraction_Item__c!=null){
                        		attName=pmlist[x].Attraction_Item__r.Name;
                            }
                             if(pmlist[x].Addon__c!=null){
                        		addName=pmlist[x].Addon__r.Name;
                            }
                            pmlist[x].Name=attName+'+'+addName;
                        //	pmlist[x].Description__c=pmlist[x].Attraction_Item__r.Description__c;
                        }
                        npmlist.push(pmlist[x]);                        
                    }
                }
                component.set("v.pmlist",npmlist);
                 console.log('npmlist:'+JSON.stringify(npmlist));
                
                //apply filter on combinations too
                var duppmlist=[];
                 var rwplist=component.get("v.rwplist");
                var orwplist=[];
                
             
                 var pmlist=component.get("v.pmlist");
                if(pmlist!=null){
                	for(var a=0;a<pmlist.length;a++){
                        var attId='';
                        var addId='';
                        if(pmlist[a].Attraction_Item__r!=null){
                            attId=pmlist[a].Attraction_Item__r.Id;
                        }
                        if(pmlist[a].Addon__r!=null){
                            addId=pmlist[a].Addon__r.Id;
                        }
                    	duppmlist.push(attId+'_'+addId);
                	}
                }
                console.log('duppmlist:'+JSON.stringify(duppmlist));
                if(attitemlist!=null){
                    for(var p=0;p<attitemlist.length;p++){    
                        console.log('filter1:'+!duppmlist.includes(attitemlist[p].Id+'_'+''));
                        if(!duppmlist.includes(attitemlist[p].Id+'_'+'')){
                        	orwplist.push({'Attraction_Item__c':attitemlist[p],
                                           'Name':attitemlist[p].Name+'+'});                            
                        }
                        if(addons!=null){
                            for(var r=0;r<addons.length;r++){
                                console.log('filter2:'+!duppmlist.includes(attitemlist[p].Id+'_'+addons[r].Id));
                                if(!duppmlist.includes(attitemlist[p].Id+'_'+addons[r].Id)){
                                orwplist.push({'Attraction_Item__c':attitemlist[p],
                                               'addon__c':addons[r],
                                               'Name':attitemlist[p].Name+'+'+addons[r].Name});
                                }
                            }
                        }
                    }          
                }
                   component.set("v.rwplist",orwplist);
                console.log('rwplist:'+JSON.stringify(component.get("v.rwplist")));                
            },
    editDetails:function(component,event,helper){
        component.set("v.isEditOpen",true);
    }
})