({
	myAction : function(component, event, helper) {
		
	},
    onSingleSelectChange: function(cmp) {
         var selectCmp = cmp.find("InputSelectSingle");
         cmp.set("v.psstatus", selectCmp.get("v.value"));
        console.log('psstatus: '+cmp.get("v.psstatus"));
        //place pslist based on psstatus
         var action = cmp.get("c.getPriceSeasonByStatus");
        action.setParams({ p_status:cmp.get("v.psstatus"),
                          p_spId : cmp.get("v.sp").Id });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                cmp.set("v.priceseasonlist",response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
	 },
    newPriceSeason: function(cmp) {
        console.log('newPriceSeason');
        cmp.set("v.priceseason",true);
    },
    priceSeasonCancel: function(component, event, helper) {
        console.log('--- cloneedit ---');
        component.set("v.priceseason",false);
    },
    priceSeasonAdded: function(component, event, helper) {
        console.log('--- priceSeasonAdded ---');
        var pslist = event.getParam("priceseasonlist");
        component.set("v.priceseasonlist",pslist);
        console.log('priceseasonlist: '+JSON.stringify(component.get("v.priceseasonlist")));
    },
    edit :function(component,event,helper){  
        component.set("v.ps",{'sobjectType':'Price_Period__c'});
        console.log('edit is clicked >> event target Id:'+event.target.id);
        component.set("v.crecordId",event.target.id);
        console.log('crecordId: '+component.get("v.crecordId")); 
        var action = component.get("c.getPriceSeason");
        action.setParams({ psId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.ps",response.getReturnValue());
                component.set("v.isOpen",false);                
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action); 
        component.set("v.editflag",true);        
    },
    delete :function(component,event,helper){  
        component.set("v.crecordId",event.target.id);      
        component.set("v.deleteflag",true);
    }
})