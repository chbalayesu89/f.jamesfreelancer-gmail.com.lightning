({
	myAction : function(component, event, helper) {
		
	},
    save: function(component, event, helper) { 
        console.log('--- save --->> '+component.get("v.sp").Id);
        console.log('spc: '+JSON.stringify(component.get("v.spc")));
        var action = component.get("c.saveItemContent");
        action.setParams({ itcstr : JSON.stringify(component.get("v.spc")),
                          itmId: component.get("v.sp").Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                component.set("v.spclist",response.getReturnValue()); 
				var itcreset=component.get("v.spc"); 
                itcreset.External_Name__c='';
                itcreset.Short_Description__c='';
                itcreset.Voucher_Message__c='';
                component.set("v.spc",itcreset);               
            } 
        });
        $A.enqueueAction(action);
    },
    gotoItemContent: function(component,event,helper){
        console.log('gotoItemContent');
        var contentId=event.target.id;
        console.log('contentId: '+contentId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+contentId
        });
        urlEvent.fire();
    }
})