({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
       var sp=component.get("v.sp");
       var ps=component.get("v.priceseason");
        ps.Supplier_Product__c=sp.Id;
        component.set("v.priceseason",ps);
    }, 
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    roomTypeCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.roomtype",false);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
     	component.set("v.isOpen",false);
    }, 
    save: function(component, event, helper) {       
        console.log('---PriceSeason Model >> Save ----');          
        component.set("v.showSpinner",true);
        // var roomtypeslist=[];
        console.log('ps:'+JSON.stringify(component.get("v.priceseason")));
        var action = component.get("c.updatePriceSeason");
        action.setParams({ ps : component.get("v.priceseason") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.isOpen",false);              
                try{
                    var appEvent = $A.get("e.c:PriceSeasonAdded");            
                    appEvent.setParams({
                        "priceseasonlist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }                   
        		component.set("v.showSpinner",false);
            } 
        });
        $A.enqueueAction(action);   
    }
})