({
	myAction : function(component, event, helper) {
		
	},
    doInIt :function(component,event,helper){
        console.log('>>> doInIt >>>');
    },
	 onGroup: function(cmp, evt) {
		 var selected = evt.getSource().get("v.label");
         console.log('selected: '+selected);
		 cmp.set("v.radioGroupResult", selected);
	 },
    
    saveitc : function(component,event,helper){
         var action = component.get("c.saveIssueTC");
        action.setParams({ tcoptionname : component.get("v.radioGroupResult"),caseId:component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": "/apex/NewContractForm?id="+component.get("v.recordId")
                        });
                        urlEvent.fire();
                }
            });
        $A.enqueueAction(action);
    }
    ,
    cancel : function(component,event,helper){
        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url": "/"+component.get("v.recordId")
                        });
                        urlEvent.fire();
    },
    enablesavebtn : function(component,event,helper){
        console.log('----------enablesavebtn-------');
        var mabox=component.get("v.radioGroupResult");
        console.log('mabox: '+mabox);
        if(mabox){
            component.find("savebtn").set("v.disabled",false);
        }
        else{
            component.find("savebtn").set("v.disabled",true);
        }
    }
})