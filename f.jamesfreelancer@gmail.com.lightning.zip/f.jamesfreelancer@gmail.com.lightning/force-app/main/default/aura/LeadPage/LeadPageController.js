({
	myAction : function(component, event, helper) {
		
	},
    doInit : function(component, event, helper) { 
        console.log('doInit success');
        var recordTypeId = component.get("v.pageReference").state.recordTypeId;
        console.log('recordTypeId: '+recordTypeId);   
        var action = component.get("c.checkRecordType");
        action.setParams({ rtypeId : recordTypeId  });        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                var presult=response.getReturnValue();
                console.log('presult: '+presult);
                if(presult!=''){
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+response.getReturnValue()
                    });
                    urlEvent.fire(); 
                }else{
                    component.set("v.showform",true);
                    console.log("showform: "+component.get("v.showform"));
                }
            }             
        });
        $A.enqueueAction(action);        
    },
     toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
    save : function(component,event,helper){        
        var recordTypeId = component.get("v.pageReference").state.recordTypeId;
        var action = component.get("c.saveLead");
        action.setParams({ led : component.get("v.led"),rTypeId:recordTypeId  });        
        action.setCallback(this, function(response) {
            var state = response.getState();            
            if (state === "SUCCESS") {
                var presult=response.getReturnValue();
                console.log('saved lead id: '+presult);
                if(presult!=''){
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+response.getReturnValue()
                    });
                    urlEvent.fire(); 
                }
            }             
        });
        $A.enqueueAction(action);        
    },
    cancel : function(component,event,helper){
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/lightning/o/Lead/list?filterName=Recent"
        });
        urlEvent.fire(); 
    },
   openModel: function(component, event, helper) {
      // for Display Model,set the "isOpen" attribute to "true"
      component.set("v.isOpen", true);
   },
 
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
       // component.set("v.isOpen", false);       
       // component.set("v.isFormOpen",false);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/lightning/o/Lead/list?filterName=Recent"
        });
        urlEvent.fire(); 
    },
 
   next: function(component, event, helper) {
      // Display alert message on the click on the "Like and Close" button from Model Footer 
      // and set set the "isOpen" attribute to "False for close the model Box.
      //alert('thanks for like Us :)');
      component.set("v.isOpen", false);
       component.set("v.isFormOpen",true);
   },
    
    checkotherbox : function(component,event,helper){
        console.log('checkotherbox success');
        var led=component.get("v.led");
        console.log('led.BB_Reasons__c: '+led.BB_Reasons__c);
        if(led.BB_Reasons__c=='Other' || led.BP_Reasons__c=='Other' || led.BO_Reasons__c=='Other' ||
          led.SB_Reasons__c=='Other' || led.SP_Reasons__c=='Other' || led.SO_Reasons__c=='Other'){
            component.set("v.show_otherbox",true);            
        }else{
            component.set("v.show_otherbox",false);
        }
        console.log('show_otherbox: '+component.get("v.show_otherbox"));    
    },
     toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
     }
})