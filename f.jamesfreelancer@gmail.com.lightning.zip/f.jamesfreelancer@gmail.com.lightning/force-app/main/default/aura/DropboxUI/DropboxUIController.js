({
	myAction : function(component, event, helper) {
		
	},
    doInit: function(component, event, helper){
        component.set("v.showSpinner",true);
        try{
            console.log('Dropbox >> doInit initiated >>'+component.get("v.recordId")); 
            var action = component.get("c.getParentFoldersAndFiles");
            action.setParams({ foldername : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.entrylist",response.getReturnValue());                    
                    console.log('entrylist: '+JSON.stringify(component.get("v.entrylist")));  
                    var folderpath=[];
                    folderpath.push({name:"Home",value:"Home"});
                    component.set("v.folderpath",folderpath);
                    component.set("v.showSpinner",false);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    handleUploadFinished: function (cmp, event) {
        // Get the list of uploaded files
        var uploadedFiles = event.getParam("files");
         cmp.set("v.docslist",uploadedFiles);
       // alert("Files uploaded : " + uploadedFiles.length);
         $A.get('e.force:refreshView').fire();         
    },
    toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    },
    openItem: function(component,event,helper){
        console.log('openItem success');
        var item=event.target.id;
        var itemob=item.split(';');
        var name=itemob[0];
        var tag=itemob[1];
        var path_lower=itemob[2];
        var folderpath=component.get("v.folderpath");       
        folderpath.push({name:name, value:path_lower});
        component.set("v.folderpath",folderpath);
       // alert('item:'+item);
       //check if it is folder
        if(tag=='folder'){
              var action = component.get("c.getFoldersAndFiles");
            action.setParams({ foldername : path_lower });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.entrylist",response.getReturnValue());                    
                    console.log('entrylist: '+JSON.stringify(component.get("v.entrylist")));                  
                    component.set("v.showSpinner",false);                    
                    $A.get('e.force:refreshView').fire();
                }
            });
            $A.enqueueAction(action);
        }
    },
    openPath : function(component,event,helper){
        console.log('openPath success');
        var folderpath=component.get('v.folderpath');
        var path=event.target.id;
      //  var fullpath=folderpath.substr(0, folderpath.indexOf(path)); 
        console.log('path: '+path);
        var fullpath=path;
        if(path=='Home'){
            fullpath=component.get("v.recordId");
        }
        var folderarr=[];
        var folderobjarr=[];
        if(path.includes('/')){
             folderarr=path.split('/');
            console.log('folderarr: '+JSON.stringify(folderarr));
            for(var s=0;s<folderarr.length;s++){
                if(folderarr[s]!=''){
                	folderobjarr.push({name:folderarr[s],value:folderarr[s]});
                }
            }
            //replace id with label Home            
        }     
        folderobjarr[0]={name:'Home',value:component.get("v.recordId")};
        //set folder path
        component.set('v.folderpath',folderobjarr);
         var action = component.get("c.getFoldersAndFiles");
            action.setParams({ foldername : fullpath });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.entrylist",response.getReturnValue());                    
                    console.log('entrylist: '+JSON.stringify(component.get("v.entrylist")));                  
                    component.set("v.showSpinner",false);                    
                    $A.get('e.force:refreshView').fire();
                }
            });
            $A.enqueueAction(action);
    }
})