({
    doInit: function(component, event, helper){
        console.log('doinit success');
        var spId=component.get("v.sp").Id;
         var action = component.get("c.getRoomwiseprices");
        action.setParams({ spId : spId
                         });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
               console.log('response'+JSON.stringify(response.getReturnValue()));
                component.set("v.rwpdisplist",response.getReturnValue());
                component.set("v.isModalOpen", false);
            }
        });
        $A.enqueueAction(action); 
    },
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    addPrice: function(component, event, helper) {
        component.set("v.rwplist",[]);
        // Set isModalOpen attribute to false  
        console.log('add price');
        var rooms=component.get("v.roomtypeslist");
        var addons=component.get("v.spalist");
        var sp=component.get("v.sp");
        var rwp=component.get("v.rwp");
        var bblist=[];
        if(sp.Board_Basis_Room_Only__c==true){
            bblist.push('Room Only');
        }
        if(sp.Board_Basis_Catering__c==true){
            bblist.push('Catering');
        }
        if(sp.Board_Basis_B_B__c==true){
            bblist.push('B&B');
        }        
        if(sp.Board_Basis_Half_Board__c==true){
            bblist.push('Half-Board');
        }
        if(sp.Board_Basis_Full_Board__c==true){
            bblist.push('Full-Board');
        }
        if(sp.BB_Fully_Inclusive_with_Local_leverages__c==true){
            bblist.push('Fully Inclusive with Local beverages');
        }
        var rwplist=component.get("v.rwplist");
        console.log('rooms.length:'+JSON.stringify(rooms));
        for(var p=0;p<rooms.length;p++){
            for(var q=0;q<bblist.length;q++){
                for(var r=0;r<addons.length;r++){
                    rwplist.push({'Room_type__c':rooms[p],
                                  'Board_basis__c':bblist[q],
                                  'addon__c':addons[r]});
                }
            }
        }
        component.set("v.rwplist",rwplist);
        component.set("v.isModalOpen", true);
        console.log('rwplist:'+JSON.stringify(rwplist));
    },
    submitDetails:function(component,event,helper){
        var spId=component.get("v.sp").Id;
        var rwplist=component.get("v.rwplist");
        var rwpselectedlist=[];
        for(var x=0;x<rwplist.length;x++){
            if(rwplist[x].selected__c==true){
                rwplist[x].Room_type__c=rwplist[x].Room_type__c.Id;
                rwplist[x].addon__c=rwplist[x].addon__c.Id;
                rwplist[x].selected__c=false;
                rwplist[x].Supplier_product__c=spId;
                rwpselectedlist.push(rwplist[x]);
            }
        }
        console.log('rwplist:'+JSON.stringify(rwpselectedlist));
         var action = component.get("c.saveRoomwiseprices");
        action.setParams({ spId : spId,
                          rwplist:JSON.stringify(rwpselectedlist)});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
               console.log('response'+JSON.stringify(response.getReturnValue()));
                component.set("v.rwpdisplist",response.getReturnValue());
                component.set("v.isModalOpen", false);
            }
        });
        $A.enqueueAction(action); 

    }
})