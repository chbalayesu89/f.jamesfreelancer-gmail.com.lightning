({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        console.log('RoomTyeModal >> doInit initiated >>'+component.get("v.sp").Id);
    }, 
    openModel: function(component, event, helper) {
        // for Display Model,set the "isOpen" attribute to "true"
        component.set("v.isOpen", true);
    },
    roomTypeCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.roomtype",false);
    },
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"  
     	component.set("v.isOpen",false);
    }, 
    save: function(component, event, helper) {       
        console.log('---RoomTypeModel >> Save ----');          
        component.set("v.showSpinner",true);
        console.log('rt:'+JSON.stringify(component.get("v.roomtype")));
        // var roomtypeslist=[];
        var action = component.get("c.saveRoomType");
        action.setParams({ rt : component.get("v.roomtype") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {component.set("v.isOpen",false);              
                try{
                    var appEvent = $A.get("e.c:RoomTypeAdded");            
                    appEvent.setParams({
                        "roomtypeslist" : response.getReturnValue() });
                    appEvent.fire();
                }catch(err){
                    console.log(err.stack);
                }                   
        		component.set("v.showSpinner",false);
            } 
        });
        $A.enqueueAction(action);   
    }
})