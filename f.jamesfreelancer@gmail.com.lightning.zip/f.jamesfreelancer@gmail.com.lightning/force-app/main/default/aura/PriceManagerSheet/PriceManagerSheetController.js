({
    myAction : function(component, event, helper) {
        
    },    
    afterScriptsLoaded : function(component, event, helper) {
        console.log('----------- afterScriptsLoaded -------------------');
        $(document).ready(function(){
            $('.slds-tabs_default__item').on('click', function(){
                $(this).addClass('slds-is-active');
                $(this).find('a').attr('aria-selected', true);
                var $contentToShow = $('#'+$(this).find('a').attr('aria-controls'));
                $contentToShow.removeClass('slds-hide');
                $contentToShow.addClass('slds-show');
                
                $(this).siblings().removeClass('slds-is-active');
                $(this).siblings().find('a').attr('aria-selected', false);
                $contentToShow.siblings('.slds-tabs_default__content').removeClass('slds-show');
                $contentToShow.siblings('.slds-tabs_default__content').addClass('slds-hide');
            });
        });
    },
    doInit: function(component, event, helper){
        try{
       // console.log('PriceManagerSheet >> doInit initiated >>'+component.get("v.recordId")); 
         var action = component.get("c.getPriceManagerlist");
        action.setParams({ pmsId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
              //  console.log('response: '+JSON.stringify(response.getReturnValue()));
                component.set("v.pmw",response.getReturnValue());
                console.log('pmw: '+JSON.stringify(component.get("v.pmw")));
                component.set("v.pmlist",component.get("v.pmw").pmlist);
                component.set("v.pslist",component.get("v.pmw").pslist);
                component.set("v.rtlist",component.get("v.pmw").rtlist);
                component.set("v.bslist",component.get("v.pmw").bslist);
                component.set("v.adlist",component.get("v.pmw").adlist);
                component.set("v.SupplierProductRecordTypeName",component.get("v.pmw").SupplierProductRecordTypeName);
                component.set("v.sp",component.get("v.pmw").sp);
               // console.log('pmlist: '+JSON.stringify(component.get("v.pmlist")));
               // console.log('pslist: '+JSON.stringify(component.get("v.pslist")));
               // console.log('rtlist: '+JSON.stringify(component.get("v.rtlist")));
                var pmw=component.get("v.pmw");
                if(pmw!=null){                    
                    component.set("v.itemid",pmw.refitemid);
                    component.set("v.itemname",pmw.refitemname);
                }
               
                
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    save : function(component, event, helper) {
        console.log('PriceManagerSheet >>> save');
        component.set("v.showSpinner",true);
        var action = component.get("c.savePriceManagerlist");
        action.setParams({ p_pmsId:component.get("v.recordId"),
                          pmliststr : JSON.stringify(component.get("v.pmlist")) });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.pmlist",response.getReturnValue());
               // console.log('pmlist: '+JSON.stringify(component.get("v.pmlist")));                
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action);
    },
    add5more : function(component,event,helper){        
        component.set("v.showSpinner",true);
       // console.log('>>>> add5more rows >>>>>');
        var action = component.get("c.add5moreAction");
        action.setParams({ pmlist : component.get("v.pmlist") });
          action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.pmlist",response.getReturnValue());                
        		component.set("v.showSpinner",false);
            }
          });
        $A.enqueueAction(action);
    },
   
     closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    addPrices: function(component, event, helper) {
        component.set("v.rwplist",[]);
        // Set isModalOpen attribute to false  
      //  console.log('add price');
        var rooms=component.get("v.rtlist");
        var addons=component.get("v.adlist");
        var sp=component.get("v.sp");
        var rwp=component.get("v.rwp");
        var bblist=[];
        if(sp.Board_Basis_Room_Only__c==true){
            bblist.push('Room Only');
        }
        if(sp.Board_Basis_Catering__c==true){
            bblist.push('Catering');
        }
        if(sp.Board_Basis_B_B__c==true){
            bblist.push('B&B');
        }        
        if(sp.Board_Basis_Half_Board__c==true){
            bblist.push('Half-Board');
        }
        if(sp.Board_Basis_Full_Board__c==true){
            bblist.push('Full-Board');
        }
        if(sp.BB_Fully_Inclusive_with_Local_leverages__c==true){
            bblist.push('Fully Inclusive with Local beverages');
        }
        var rwplist=component.get("v.rwplist");
      //  console.log('rooms.length:'+JSON.stringify(rooms));
        for(var p=0;p<rooms.length;p++){
            for(var q=0;q<bblist.length;q++){
                for(var r=0;r<addons.length;r++){
                    rwplist.push({'Room_type__c':rooms[p],
                                  'Board_basis__c':bblist[q],
                                  'addon__c':addons[r]});
                }
            }
        }
        component.set("v.rwplist",rwplist);
        component.set("v.isModalOpen", true);
      //  console.log('rwplist:'+JSON.stringify(rwplist));
    },
    submitDetails:function(component,event,helper){
        try{
        var spId=component.get("v.sp").Id;
        var rwplist=component.get("v.rwplist");
      //  console.log('rwplist:'+JSON.stringify(rwplist));
        var rwpselectedlist=[];
        for(var x=0;x<rwplist.length;x++){
            if(rwplist[x].selected__c==true){
               // rwplist[x].Room_Type__c=rwplist[x].Room_type__c.value;
               // rwplist[x].Addon__c=rwplist[x].addon__c.value;
              //  rwplist[x].selected__c=false;
              //  rwplist[x].Supplier_product__c=spId;
              var roomtype='';
              var addon='';
                if(rwplist[x].Room_type__c!=undefined){
                    roomtype=rwplist[x].Room_type__c.value;
                }
                if(rwplist[x].addon__c!=undefined){
                    addon=rwplist[x].addon__c.value;
                }                
                rwpselectedlist.push({'Room_Type__c':roomtype,
                                      'Addon__c':addon,                                      
                                      'Price_Manager_sheet__c':component.get("v.recordId"),
                                      'Board_Basis__c':rwplist[x].Board_basis__c,
                                      'Value__c':rwplist[x].value__c});
            }
        }
      //  console.log('rwpselectedlist:'+JSON.stringify(rwpselectedlist));
         var action = component.get("c.saveRoomwiseprices");
        action.setParams({spId : spId,
                          rwplist:JSON.stringify(rwpselectedlist)});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {                
               console.log('response'+JSON.stringify(response.getReturnValue()));
                component.set("v.pmlist",response.getReturnValue());
                component.set("v.isModalOpen", false);
            }
        });
        $A.enqueueAction(action); 
        }catch(err){
            console.log('ERROR:'+err.stack);
        }
    }
})