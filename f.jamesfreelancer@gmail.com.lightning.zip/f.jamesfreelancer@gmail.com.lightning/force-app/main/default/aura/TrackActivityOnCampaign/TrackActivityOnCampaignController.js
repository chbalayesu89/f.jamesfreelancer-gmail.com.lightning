({
    myAction : function(component, event, helper) {
        
    },
    doInit: function(component, event, helper){
        console.log('doinit successful');
          component.set("v.showSpinner",false);
       /*  try{
            console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
            var action = component.get("c.getOpportunity");
            action.setParams({ recId : component.get("v.recordId") });
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.opp",response.getReturnValue());
                    console.log('opp: '+JSON.stringify(component.get("v.opp")));                  
        			component.set("v.showSpinner",false);
                }
            });
            $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }*/
    },
    savepsf : function(component,event,helper){
        console.log('save psf >> ');         
        var tsobj=component.get("v.ts");        
        console.log('tsobj: '+JSON.stringify(tsobj));
        
        var action = component.get("c.saveTimeService");
        action.setParams({ campaignId : component.get("v.recordId"),
                          ts:component.get("v.ts")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var ts=response.getReturnValue();
                if(ts!=null){
                    component.set("v.ts",ts);                    
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/"+component.get("v.ts").Id
                    });
                    urlEvent.fire();                   	  
                }
            }
        });
        $A.enqueueAction(action);
    },
    cancel : function(component,event,helper){
        $A.get("e.force:closeQuickAction").fire();
    },
    enablesavebtn : function(component,event,helper){
        console.log('----------enablesavebtn-------');
        //time service object data validation begins
        var tsobj=component.get("v.ts");           
        if(tsobj.Activity_Description__c!='' && tsobj.Type__c!='' && tsobj.Status__c!='' && tsobj.How_many_minutes__c!='' && tsobj.Comments__c!='' 
           && tsobj.Activity_Description__c!=null && tsobj.Type__c!=null && tsobj.Status__c!=null && tsobj.How_many_minutes__c!=null && tsobj.Comments__c!=null){           
            document.getElementById('msg').innerHTML='';
            component.find("savebtn").set("v.disabled",false);
        }
        else{            
            document.getElementById("msg").innerHTML='Please fill all fields!';                
            component.find("savebtn").set("v.disabled",true);
        }
    },
    toggleSection : function(component, event, helper) {
        // dynamically get aura:id name from 'data-auraId' attribute
        var sectionAuraId = event.target.getAttribute("data-auraId");
        // get section Div element using aura:id
        var sectionDiv = component.find(sectionAuraId).getElement();
        /* The search() method searches for 'slds-is-open' class, and returns the position of the match.
         * This method returns -1 if no match is found.
        */
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        
        // -1 if 'slds-is-open' class is missing...then set 'slds-is-open' class else set slds-is-close class to element
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
     }
})