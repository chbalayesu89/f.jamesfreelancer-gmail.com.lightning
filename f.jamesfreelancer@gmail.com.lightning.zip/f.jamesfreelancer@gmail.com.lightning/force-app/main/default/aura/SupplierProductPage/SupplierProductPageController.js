({
	myAction : function(component, event, helper) {
		
	},
    afterScriptsLoaded : function(component, event, helper) {
		console.log('----------- afterScriptsLoaded -------------------');
         $(document).ready(function(){
             /*   $('.slds-vertical-tabs__nav-item').on('click', function
                    // alert('item clicked');
                    $(this).addClass('slds-is-active');
                    $(this).find('a').attr('aria-selected', true);
                    var $contentToShow = $('#'+$(this).find('a').attr('aria-controls'));
                    $contentToShow.removeClass('slds-hide');
                    $contentToShow.addClass('slds-show');
                    
                    $(this).siblings().removeClass('slds-is-active');
                    $(this).siblings().find('a').attr('aria-selected', false);
                    $contentToShow.siblings('.slds-vertical-tabs__content').removeClass('slds-show');
                    $contentToShow.siblings('.slds-vertical-tabs__content').addClass('slds-hide');
                }); 
             
              $('.slds-tabs_default__item').on('click', function(){
                $(this).addClass('slds-is-active');
                $(this).find('a').attr('aria-selected', true);
                var $contentToShow = $('#'+$(this).find('a').attr('aria-controls'));
                $contentToShow.removeClass('slds-hide');
                $contentToShow.addClass('slds-show');
                
                $(this).siblings().removeClass('slds-is-active');
                $(this).siblings().find('a').attr('aria-selected', false);
                $contentToShow.siblings('.slds-tabs_default__content').removeClass('slds-show');
                $contentToShow.siblings('.slds-tabs_default__content').addClass('slds-hide');
            }); */
            }); 
	},
    doInit: function(component, event, helper){
        try{
        console.log('Items >> doInit initiated >>'+component.get("v.recordId")); 
         var action = component.get("c.getSupplierProduct");
        action.setParams({ spId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.sp",response.getReturnValue());
                var recordtype=component.get("v.sp").Record_Type__c;
                component.set("v.RTName",recordtype);
                console.log('recordtype: '+recordtype);
                if(recordtype!='Attraction' && recordtype!='Restaurant' && recordtype!='Shop' && recordtype!='Car Hire'){
                   component.set("v.showRTandPM",true);
                 }
                else{
                    component.set("v.showRTandPM",false);
                }
                console.log("showRTandPM:"+component.get("v.showRTandPM"));
                component.set("v.roomtypeslist",component.get("v.sp").Room_Types__r);
                component.set("v.priceseasonlist",component.get("v.sp").Price_Period__r);
                component.set("v.itclist",component.get("v.sp").Item_Content__r);
                component.set("v.spalist",component.get("v.sp").Addon__r);
                component.set("v.attitemlist",component.get("v.sp").Attraction_Items__r);
              //  component.set("v.rwplist",component.get("v.sp").Roomwise_Prices__r);
                component.set("v.pmsId",component.get("v.sp").Price_Manager_Sheet__c);
              //  console.log('sp: '+JSON.stringify(component.get("v.sp")));
                //==================================== begin map logic =========================================
                 try{
        var itcomp=component.get("v.sp");           
            console.log('itcomp:'+JSON.stringify(itcomp));
           // var itc=JSON.stringify(itcomp);
            var st='';
            var ct='';
            var ste=''; 
            var lat='';
            var lon='';
            if(itcomp.Street__c!=null)
                st=itcomp.Street__c;
            if(itcomp.City__c!=null)
                ct=itcomp.City__c;
            if(itcomp.State__c!=null)
                ste=itcomp.State__c;
            if(itcomp.LatitudeTEXT__c!=null)
                lat=itcomp.LatitudeTEXT__c;
            if(itcomp.LongitudeTEXT__c!=null)
                lon=itcomp.LongitudeTEXT__c;
            console.log('lat: '+lat);
            console.log('lon: '+lon);
        component.set('v.mapMarkers', [
            {
                location: {
                    Street: ''+st,
                    City: ''+ct,
                    State: ''+ste
                },

                title: ''+st,
                description: ''+ct+','+ste
            }
        ]);
          /*  component.set('v.mapMarkers', [
            {
                location: {
                   'Latitude': lat,
                   'Longitude': lon
                },

                title: ''+st,
                description: ''+ct+','+ste
            }]); */
        component.set('v.zoomLevel', 19);
        }catch(err){
            
            console.log(err.stack);
        }        
        console.log('zoomlevel: '+component.get('v.zoomLevel'));
                //====================================  end map logic  ==========================================
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    },
    overviewTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
            
       var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData'); 
        
        
        //show and Active fruits tab
        $A.util.addClass(tab1, 'slds-is-active');
        $A.util.addClass(TabOnedata, 'slds-show');
        $A.util.removeClass(TabOnedata, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
            
         $A.util.removeClass(tab6, 'slds-is-active');
         $A.util.removeClass(TabSixData, 'slds-show');
         $A.util.addClass(TabSixData, 'slds-hide');
        
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",false);
         
                    
         
            
        }catch(err){
            console.log(err.stack);
        }
	},
    roomtypesTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
            
        var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData');  
        
        
        //show and Active fruits tab
        $A.util.addClass(tab2, 'slds-is-active');
        $A.util.addClass(TabTwoData, 'slds-show');
        $A.util.removeClass(TabTwoData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab1, 'slds-is-active');
        $A.util.removeClass(TabOnedata, 'slds-show');
        $A.util.addClass(TabOnedata, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
             $A.util.removeClass(tab6, 'slds-is-active');
         $A.util.removeClass(TabSixData, 'slds-show');
         $A.util.addClass(TabSixData, 'slds-hide');
            
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",false);
            
                     
        
            
        }catch(err){
            console.log(err.stack);
        }
	},
    pricemanagerTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
         var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData');   
            
        //show and Active fruits tab
        $A.util.addClass(tab3, 'slds-is-active');
        $A.util.addClass(TabThreeData, 'slds-show');
        $A.util.removeClass(TabThreeData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        $A.util.removeClass(tab6, 'slds-is-active');
         $A.util.removeClass(TabSixData, 'slds-show');
         $A.util.addClass(TabSixData, 'slds-hide');
            
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",false);
            
                
         
            
        }catch(err){
            console.log(err.stack);
        }
	},
    contentTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');        
        
         var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData'); 
            
        //show and Active fruits tab
        $A.util.addClass(tab4, 'slds-is-active');
        $A.util.addClass(TabFourData, 'slds-show');
        $A.util.removeClass(TabFourData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        $A.util.removeClass(tab5, 'slds-is-active');
         $A.util.removeClass(TabFiveData, 'slds-show');
         $A.util.addClass(TabFiveData, 'slds-hide');
        
        $A.util.removeClass(tab6, 'slds-is-active');
         $A.util.removeClass(TabSixData, 'slds-show');
         $A.util.addClass(TabSixData, 'slds-hide');
            
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",true);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",false);
                       
         
            
        }catch(err){
            console.log(err.stack);
        }
	},
    mediaTab: function(component,event,helper){
        try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
         var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData'); 
            
        
        //show and Active fruits tab
        $A.util.addClass(tab5, 'slds-is-active');
        $A.util.addClass(TabFiveData, 'slds-show');
        $A.util.removeClass(TabFiveData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
         $A.util.removeClass(tab6, 'slds-is-active');
         $A.util.removeClass(TabSixData, 'slds-show');
         $A.util.addClass(TabSixData, 'slds-hide');
            
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",true);
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",false);
            
                    
        
            
        }catch(err){
            console.log(err.stack);
        }
	},
    addonsTab:function(component,event,helper){
         try{
     var tab1 = component.find('overview');
        var TabOnedata = component.find('overviewData');
        
        var tab2 = component.find('roomtypes');
        var TabTwoData = component.find('roomtypesData');
        
        var tab3 = component.find('pricemanager');
        var TabThreeData = component.find('pricemanagerData');
        
        var tab4 = component.find('content');
        var TabFourData = component.find('contentData');
        
        var tab5 = component.find('media');
        var TabFiveData = component.find('mediaData');
        
          var tab6 = component.find('addons');
         var TabSixData = component.find('addonsData');
             
        //show and Active fruits tab
         $A.util.addClass(tab6, 'slds-is-active');
         $A.util.addClass(TabSixData, 'slds-show');
         $A.util.removeClass(TabSixData, 'slds-hide');
             
        $A.util.removeClass(tab5, 'slds-is-active');
        $A.util.removeClass(TabFiveData, 'slds-show');
        $A.util.addClass(TabFiveData, 'slds-hide');
        
        // Hide and deactivate others tab
        $A.util.removeClass(tab2, 'slds-is-active');
        $A.util.removeClass(TabTwoData, 'slds-show');
        $A.util.addClass(TabTwoData, 'slds-hide');
        
         $A.util.removeClass(tab3, 'slds-is-active');
         $A.util.removeClass(TabThreeData, 'slds-show');
         $A.util.addClass(TabThreeData, 'slds-hide');
        
        $A.util.removeClass(tab4, 'slds-is-active');
         $A.util.removeClass(TabFourData, 'slds-show');
         $A.util.addClass(TabFourData, 'slds-hide');
        
        $A.util.removeClass(tab1, 'slds-is-active');
         $A.util.removeClass(TabOnedata, 'slds-show');
         $A.util.addClass(TabOnedata, 'slds-hide');
        
        
        component.find("slds-vertical-tabs-0__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-1__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-2__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-3__nav").set("v.aria-selected",false);
        component.find("slds-vertical-tabs-4__nav").set("v.aria-selected",false);      
         component.find("slds-vertical-tabs-5__nav").set("v.aria-selected",true);
            
        }catch(err){
            console.log(err.stack);
        }
    }
})