({
    myAction : function(component, event, helper) {
        
    },
    doInit : function(component, event, helper) {
        try{
        console.log('doInit success');
        console.log('recordId: '+component.get("v.recordId"));
        var action = component.get("c.getDisburseMoneyURL");
        action.setParams({ caseId : component.get("v.recordId") });       
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var url=response.getReturnValue();
                console.log('url: '+url);
                window.open(url,"_self");
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Exception: '+err.stack);
        }
    }
})