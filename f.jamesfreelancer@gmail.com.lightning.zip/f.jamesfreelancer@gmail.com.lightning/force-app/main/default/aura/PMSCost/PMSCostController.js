({
	myAction : function(component, event, helper) {
		
	},
    delete : function(component, event, helper){
    component.set("v.showSpinner",true);
  //  console.log(' PMSCost >>> delete >>> id:'+event.target.id);
    	var action = component.get("c.deltePriceManagerById");
        action.setParams({pmid:event.target.id});
        action.setCallback(this, function(response) {
        	component.set("v.pmlist",response.getReturnValue());            
    		component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
	}
})