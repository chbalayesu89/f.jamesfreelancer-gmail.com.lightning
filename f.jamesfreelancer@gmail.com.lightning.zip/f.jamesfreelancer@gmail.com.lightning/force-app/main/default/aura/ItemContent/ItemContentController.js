({
	myAction : function(component, event, helper) {
		
	},
    save: function(component, event, helper) { 
        console.log('--- save --->> '+component.get("v.sp").Id);
        console.log('itc: '+JSON.stringify(component.get("v.itc")));
        var action = component.get("c.saveItemContent");
        action.setParams({ itcstr : JSON.stringify(component.get("v.itc")),
                          itmId: component.get("v.sp").Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('state: '+state);
            if (state === "SUCCESS") {
                component.set("v.itclist",response.getReturnValue()); 
				var itcreset=component.get("v.itc"); 
                itcreset.External_Name__c='';
                itcreset.Short_Description__c='';
                itcreset.Voucher_Message__c='';
                itcreset.Id=null;
                itcreset.Sort__c='';
                component.set("v.itc",itcreset);               
            } 
        });
        $A.enqueueAction(action);
    },
    gotoItemContent: function(component,event,helper){
        console.log('gotoItemContent');
        var contentId=event.target.id;
        console.log('contentId: '+contentId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+contentId
        });
        urlEvent.fire();
    },
    editic:function(component,event,helper){
        console.log('editic');
        component.set("v.showedit",true);
        var icId=event.target.id;
        console.log(' event target Id:'+icId);
       // component.set("v.crecordId",event.target.id);
       // console.log('crecordId: '+component.get("v.crecordId")); 
        var action = component.get("c.getItemContent");
        action.setParams({ icId : icId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.itc",response.getReturnValue());
            }
        });
        $A.enqueueAction(action); 
    },
    deleteic:function(component,event,helper){
        var icId=event.target.id;
        component.set("v.delitcId",icId);
        console.log('deleteic');
        component.set("v.showdelete",true);
    },
    closeModel:function(component,event,helper){
        component.set("v.showdelete",false);
        component.set("v.showedit",false);
    },
    editsave:function(component,event,helper){
         var action = component.get("c.updateItemContent");
        action.setParams({ itc : component.get("v.itc") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            component.set("v.showedit",false);
            if (state === "SUCCESS") {
                component.set("v.itclist",response.getReturnValue());
                console.log('itclist:'+JSON.stringify(component.get("v.itclist")));
                var itcreset=component.get("v.itc"); 
                itcreset.External_Name__c='';
                itcreset.Short_Description__c='';
                itcreset.Voucher_Message__c='';
                itcreset.Sort__c='';
                itcreset.Id=null;
                component.set("v.itc",itcreset);  
            }
        });
        $A.enqueueAction(action); 
    },
     delsave:function(component,event,helper){
         var icId=component.get("v.delitcId");
         var action = component.get("c.deleteItemContent");
        action.setParams({ icId : icId });
        action.setCallback(this, function(response) {
            var state = response.getState();
            component.set("v.showdelete",false);
            if (state === "SUCCESS") {
                component.set("v.itclist",response.getReturnValue());
                console.log('itclist:'+JSON.stringify(component.get("v.itclist")));
                var itcreset=component.get("v.itc"); 
                itcreset.External_Name__c='';
                itcreset.Short_Description__c='';
                itcreset.Voucher_Message__c='';
                itcreset.Id=null;
                itcreset.Sort__c='';
                component.set("v.itc",itcreset);  
            }
        });
        $A.enqueueAction(action); 
    },
})