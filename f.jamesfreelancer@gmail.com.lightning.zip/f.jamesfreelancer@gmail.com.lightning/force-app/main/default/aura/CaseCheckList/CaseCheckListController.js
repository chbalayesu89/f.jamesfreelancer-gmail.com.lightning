({
	doinit : function(component, event, helper) {
        component.set("v.showSpinner",true);
		  var action = component.get("c.getChecklist");
        action.setParams({
            "aid": component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            component.set("v.Checklist", a.getReturnValue());
            console.log('checklist',JSON.stringify(a.getReturnValue()));
        });
        $A.enqueueAction(action);
         var action = component.get("c.getChecklistOptions");
        action.setParams({
            "csId": component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            component.set("v.clwlist", a.getReturnValue());
            console.log('clwlist',JSON.stringify(a.getReturnValue()));            
        	component.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
	},
    createNewChecklist : function(component,event,helper){
        console.log('<< createNewChecklist >> ');
        component.set("v.showNewchecklist",true);
        component.set("v.CreateChecklist",{ 'sobjectType' : 'Checklist__c' });        
    },
    handleSaveChecklist: function(component,event,helper){
        var newCheck = component.get("v.CreateChecklist");
        newCheck['Case__c'] =component.get("v.recordId");
         console.log('chk: '+JSON.stringify(component.get("v.CreateChecklist")));
         if(newCheck['Checklist__c']==null||newCheck['Checklist__c']==''||newCheck['Notes__c']==null||newCheck['Notes__c']==''){
            component.set("v.errMsg","Field can't be Empty");
            return;
        }
        else{
            component.set("v.errMsg",null);
        }
       
        var action = component.get("c.saveChecklist");
        action.setParams({
            "chk": component.get("v.CreateChecklist")
        });
        action.setCallback(this, function(a) {
            component.set("v.Checklist", a.getReturnValue());
            console.log('checklist',a.getReturnValue());
            component.set("v.showNewchecklist",false); 
        });
        $A.enqueueAction(action);       
    },
    handleCancelChecklist: function(component,event,helper){
        component.set("v.showNewchecklist",false);
    },
    editchecklist : function(component,event,helper){
        console.log('<< editchecklist >> event target Id: '+event.target.id);
        component.set("v.editId",event.target.id);
       component.set("v.showEditchecklist",true); 
    },
    deletechecklist : function(component,event,helper){       
        console.log('<< editchecklist >>'+event.target.id); 
         var action = component.get("c.deleteCheckList");
        action.setParams({
            "chkId": event.target.id,
            "caseId":component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            component.set("v.Checklist", a.getReturnValue());
            console.log('checklist',JSON.stringify(a.getReturnValue()));
        });
        $A.enqueueAction(action); 
    },
    handleEditChecklist : function(component,event,helper){ 
        console.log('Checklist: '+JSON.stringify(component.get("v.Checklist")));
        var action = component.get("c.editsaveChecklist");
        action.setParams({
            "chklist": component.get("v.Checklist")
        });
        action.setCallback(this, function(a) {
            component.set("v.Checklist", a.getReturnValue());
            console.log('checklist',JSON.stringify(a.getReturnValue()));
            component.set("v.showNewchecklist",false); 
            component.set("v.editId",null);
        });
        $A.enqueueAction(action);       
    },
    handleEditCancelChecklist: function(component,event,helper){
        component.set("v.showEditchecklist",false); 
    }
    
})