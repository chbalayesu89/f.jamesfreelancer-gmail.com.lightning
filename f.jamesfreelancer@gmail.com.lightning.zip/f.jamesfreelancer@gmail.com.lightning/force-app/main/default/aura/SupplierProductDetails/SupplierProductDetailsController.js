({
	myAction : function(component, event, helper) {
		
	},
    save : function(component, event, helper) {
        console.log('--- save ---');
        try{        
            component.find("spedit").get("e.recordSave").fire();
            $A.get('e.force:refreshView').fire();
            component.set("v.flag",true);
        }catch(err){
            console.log(err.stack);
        }        
    },
    edit : function(component, event, helper) {
        component.set("v.flag",false);
    },
    cloneedit : function(component, event, helper) {
        console.log('--- cloneedit ---');
        component.set("v.cloneflag",true);
    },
    cloneItemCancel : function(component, event, helper) {
        console.log('--- cloneItemCancel ---');
        component.set("v.cloneflag",false);
    },
    cancel : function(component, event, helper) {
        component.set("v.flag",true);
    },
    delete : function(component, event, helper) {
         var action = component.get("c.deleteSupplierProduct");
        action.setParams({ ItemId : component.get("v.recordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                window.location.href='https://lightning-sandbox--lightning.lightning.force.com/lightning/o/Items__c/list?filterName=Recent';
            }
        });
        $A.enqueueAction(action);
    },
    clone : function(component, event, helper) {
        try{ 
          // component.find("cedit").get("e.recordSave").fire();   
           var csp=component.get("v.csp");
            console.log('itm: '+JSON.stringify(itm));
         var action = component.get("c.setcloneSupplierProduct");
        action.setParams({ csp : JSON.stringify(component.get("v.csp")) });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var cId=response.getReturnValue();
                console.log('redirecting...'+cId);
                window.location.href='/'+cId;
            }
        });
        $A.enqueueAction(action);
        }catch(err){
            console.log('Excetion: '+err.stack);
        }
    }
})