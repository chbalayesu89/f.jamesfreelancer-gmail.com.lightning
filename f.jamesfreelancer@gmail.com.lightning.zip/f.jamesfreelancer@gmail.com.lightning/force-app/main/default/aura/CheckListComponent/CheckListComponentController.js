({
    doinit : function(component,event,helper){
        component.find("recordEditor").getNewRecord(
            "Checklist__c", // sObject type (objectApiName)
            null,      // recordTypeId
            false,     // skip cache?
            $A.getCallback(function() {
                var rec = component.get("v.newChecklist");
                var error = component.get("v.newChecklistError");
                if(error || (rec === null)) 
                {   
                    return;
                }
            }));
        console.log('hello one1');
        var action = component.get("c.getChecklist");
        action.setParams({
            "aid": component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            component.set("v.Check", a.getReturnValue());
            console.log('hellotest121',a.getReturnValue());
        });
        $A.enqueueAction(action);
    },
    isRefreshed : function(component,event,helper)
    {
      console.log("Method is running");  
    },
    hide : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'none';
    },
    show : function(component,event,helper){
        var elements = document.getElementsByClassName("myTest");
        elements[0].style.display = 'block';
    },
    handleSaveChecklist: function(component, event, helper)
    {
        var str = window.location.href;
        
        var splitted = str.split('/');
        
        var newCheck = component.get("v.CreateChecklist");
        
        if(splitted==null||splitted==undefined||splitted==''||splitted.length<6){
            return;
        }
        
        newCheck['Case__c'] = splitted[6];
        var saveCount = component.get("v.saveCount");
        if(saveCount%2==0){
            newCheck['Checklist__c']=component.find("checkL1").get("v.value");
            newCheck['Notes__c']=component.find("checkL2").get("v.value");   
        }
        else if(saveCount%2==1){
            newCheck['Checklist__c']=component.find("checkLe1").get("v.value");
            newCheck['Notes__c']=component.find("checkLe2").get("v.value"); 
        }
        
        if(newCheck['Checklist__c']==null||newCheck['Checklist__c']==''||newCheck['Notes__c']==null||newCheck['Notes__c']==''){
            component.set("v.errMsg","Field can't be Empty");
            return;
        }
        else{
            component.set("v.errMsg",null);
        }
        
        component.find("recordEditor").set("v.CreateChecklist",newCheck);
        component.find("recordEditor").saveRecord(function(saveResult){
            if (saveResult.state === "SUCCESS" || saveResult.state === "DRAFT") {
                console.log('success!qwqw');
				
                component.set("v.saveCount", (component.get("v.saveCount")+1));
                component.set("v.errMsg",null);
                //component.set("v.saveCount",null);
                component.find("recordEditor").getNewRecord(
                    "Checklist__c", // sObject type (objectApiName)
                    null,      // recordTypeId
                    false,     // skip cache?
                    $A.getCallback(function() {
                        var rec = component.get("v.newChecklist");
                        
                        var error = component.get("v.newChecklistError");
                        if(error || (rec === null)) 
                        {   
                            return;
                        }
                    }));
               
                
                
            }
            else
            {
                console.log('failed rec');
            }
        }); 
        var action = component.get("c.getChecklist");
        action.setParams({
            "aid": component.get("v.recordId")
        });
        action.setCallback(this, function(a) {
            component.set("v.Check", a.getReturnValue());
            
        });
        $A.enqueueAction(action);
    },
    handleRecordUpdated : function(component, event, helper) {
        var eventParams = event.getParams();
        if(eventParams.changeType === "LOADED") {
            // record is loaded (render other component which needs record data value)
            console.log("Record is loaded successfully.");
        } else if(eventParams.changeType === "CHANGED") {
            console.log("Record is loaded CHANGED.");
            //   component.find("recordUpdator").reloadRecord();
            // record is changed
        } else if(eventParams.changeType === "REMOVED") {
            console.log("Record is loaded REMOVED.");
            // record is deleted
        } else if(eventParams.changeType === "ERROR") {
            console.log("Record is loaded ERROR.");
            // there’s an error while loading, saving, or deleting the record
        }
    },
    afterRecordUpdated : function(component, event, helper) {
        //var checkListId = component.get("v.checklistID");//event.currentTarget.getAttribute("data-value");
        console.log("vj!!",checkListId);
        var checkListId=component.get("v.checklistID");
        console.log("Heels",checkListId);
        var check='';
        var notess='';
        var saveCount = component.get("v.saveCount");
        if(saveCount%2==0){
            check=component.find("check1").get("v.value");
        	notess=component.find("check2").get("v.value");
           //newCheck['Checklist__c']=component.find("checkL1").get("v.value");
           // newCheck['Notes__c']=component.find("checkL2").get("v.value");   
        }
        else if(saveCount%2==1){
            check=component.find("checke1").get("v.value");
        	notess=component.find("checke2").get("v.value");
           // newCheck['Checklist__c']=component.find("checkLe1").get("v.value");
           // newCheck['Notes__c']=component.find("checkLe2").get("v.value"); 
        }
        
        if(check==null||check==''||notess==null||notess==''){
            component.set("v.errMsg","Field can't be Empty");
            return;
        }
        else{
            component.set("v.errMsg",null);
        }
        
        var action=component.get("c.UpdateCheckList");
        action.setParams({
            "Id"  : checkListId,
            "checklist" : check,
            "notes" : notess
        });
        
        action.setCallback(this, function(a) {
            if (a.getState() === "SUCCESS") {
                component.set("v.checklistID",null);
                component.set("v.CreateChecklist",null);
                component.set("v.saveCount", (component.get("v.saveCount")+1));
                component.set("v.errMsg",null);
                component.find("recordEditor").getNewRecord(
                    "Checklist__c", // sObject type (objectApiName)
                    null,      // recordTypeId
                    false,     // skip cache?
                    $A.getCallback(function() {
                        var rec = component.get("v.newChecklist");
                        var error = component.get("v.newChecklistError");
                        if(error || (rec === null)) 
                        {   
                            return;
                        }
                    }));
                
                console.log("Vj",a.getReturnValue());
            } else if (a.getState() === "ERROR") {
                $A.log("Errors", a.getError());
            }
        });
        $A.enqueueAction(action);
        var action1 = component.get("c.getChecklist");
        action1.setParams({
            "aid": component.get("v.recordId")
        });
        action1.setCallback(this, function(a) {
            component.set("v.Check", a.getReturnValue());
            console.log('hellotest121',a.getReturnValue());
        });
        $A.enqueueAction(action1);
    },
    
    recordUpdate : function(component, event, helper) {
        
        var action=component.get("v.UpdateCheckList");
        component.set("v.checklistID",null);
        var checkListId = event.currentTarget.getAttribute("data-value");
        console.log("vj!!",checkListId);
        component.set("v.checklistID",checkListId);
        
    },
    handleCancelChecklist: function(component, event, helper)
    {
        component.set("v.saveCount", (component.get("v.saveCount")+1));
        component.set("v.checklistID",null);
        component.set("v.errMsg",null);
        
    },
   /* getConfirmation: function(component,event,helper)
    {
               var retVal = confirm("Do you want to Delete this record?");
        console.log('retBal',retVal);
               if( retVal == true )
               {
                   console.log('You are in');
                  var action= component.get('c.delRec');
                   $A.enqueueAction(action);
               //   return true;
               }
               else{
                  return false;
               }
    },*/
    delRec: function(component, event, helper)
    {
        
        var retVal = confirm("Do you want to Delete this record?");
        console.log('retBal',retVal);
        if( retVal == true )
        {
            var copyid=event.currentTarget.dataset.value;
            console.log('Dataset value',event.currentTarget.dataset.value);
            var itr = component.get("v.Check");
            
            var action=component.get("c.dltcheckList");
            action.setParams({
                checkList  : copyid
            });
            
            action.setCallback(this, function(a) {
                if (a.getState() === "SUCCESS") {
                    console.log(a.getReturnValue());
                    component.set("v.saveCount", (component.get("v.saveCount")+1));
                    component.set("v.checklistID",null);
                    component.set("v.errMsg",null);
                } else if (a.getState() === "ERROR") {
                    $A.log("Errors", a.getError());
                }
            });
            $A.enqueueAction(action);
            var action1 = component.get("c.getChecklist");
            action1.setParams({
                "aid": component.get("v.recordId")
            });
            action1.setCallback(this, function(a) {
                component.set("v.Check", a.getReturnValue());
                console.log('hellotest121',a.getReturnValue());
            });
            $A.enqueueAction(action1);
        }
        else{
            return false;
        }
    },
    editRec: function(component, event, helper)
    {
        var copyid=event.currentTarget.dataset.value;
        console.log('Dataset value',event.currentTarget.dataset.value);
        var itr = component.get("v.Check");
        for(var i=0;i<itr.length;i++)
        {
            if(itr[i].Id == copyid)
            {
                var newCheck = component.get("v.CreateChecklist");
                //console.log('checklist__c',newCheck['checklist__c']); 
                newCheck['Checklist__c'] = itr[i].Checklist__c;
                newCheck['Notes__c'] = itr[i].Notes__c;
                console.log('newafter1',itr[i].Notes__c);
                console.log('newafter',newCheck['Id']);
                component.find("recordEditor").set("v.CreateChecklist",newCheck);
            }
        }
        var action1 = component.get("c.getChecklist");
        action1.setParams({
            "aid": component.get("v.recordId")
        });
        action1.setCallback(this, function(a) {
            component.set("v.Check", a.getReturnValue());
            console.log('hellotest121',a.getReturnValue());
        });
        $A.enqueueAction(action1);
    }
})