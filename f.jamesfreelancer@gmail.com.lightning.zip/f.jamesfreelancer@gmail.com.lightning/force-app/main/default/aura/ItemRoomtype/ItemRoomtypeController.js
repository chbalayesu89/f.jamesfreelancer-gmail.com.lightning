({
    myAction : function(component, event, helper) {
        
    },    
    openRoomTypeModal : function(component, event, helper) {
        component.set("v.showSpinner", true);
        console.log('--- cloneedit ---');
        component.set("v.roomtype",true);
        setTimeout(function()
                   { 
                       component.set("v.showSpinner", false);
                   }, 2000);
    },
    roomTypeCancel: function(component, event, helper) {
        console.log('--- cloneedit ---');
        component.set("v.roomtype",false);
    },
    roomTypeAdded: function(component, event, helper) {
        console.log('--- roomTypeAdded ---');
        var rtlist = event.getParam("roomtypeslist");
        component.set("v.roomtypeslist",rtlist);
    },
    save: function(component, event, helper){
        console.log('--- save ----');
        var action = component.get("c.saveboardbasisAction");
        var itm=component.get("v.itm");
        action.setParams({itmid:itm.Id,
                          roomonly:itm.Board_Basis_Room_Only__c,
                          catering:itm.Board_Basis_Catering__c,
                          bandb:itm.Board_Basis_B_B__c,
                          hb:itm.Board_Basis_Half_Board__c,
                          fb:itm.Board_Basis_Full_Board__c,
                          fullyinclusive:itm.BB_Fully_Inclusive_with_Local_leverages__c});
        action.setCallback(this, function(response) {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                "title": "Success!",
                "message": "Board Basis has been Saved successfully."
            });
            toastEvent.fire();        	
        });
        $A.enqueueAction(action);
    },
    edit :function(component,event,helper){  
        component.set("v.rt",{'sobjectType':'Room_Type__c'});
        console.log('edit is clicked >> event target Id:'+event.target.id);
        component.set("v.crecordId",event.target.id);
        console.log('crecordId: '+component.get("v.crecordId")); 
        var action = component.get("c.getRoomType");
        action.setParams({ rtId : component.get("v.crecordId") });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.rt",response.getReturnValue());
                component.set("v.isOpen",false);                
        		component.set("v.showSpinner",false);
            }
        });
        $A.enqueueAction(action); 
        component.set("v.editflag",true);        
    },
    delete :function(component,event,helper){  
        component.set("v.crecordId",event.target.id);      
        component.set("v.deleteflag",true);
    }
})