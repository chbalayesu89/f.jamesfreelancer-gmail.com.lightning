declare module "@salesforce/apex/UploadDocsAndSubmitCtrl.getLeaveRequest" {
  export default function getLeaveRequest(param: {p_lrId: any}): Promise<any>;
}
declare module "@salesforce/apex/UploadDocsAndSubmitCtrl.submitLR" {
  export default function submitLR(param: {p_lrId: any}): Promise<any>;
}
declare module "@salesforce/apex/UploadDocsAndSubmitCtrl.cancelUploads" {
  export default function cancelUploads(param: {p_docslist_str: any}): Promise<any>;
}
