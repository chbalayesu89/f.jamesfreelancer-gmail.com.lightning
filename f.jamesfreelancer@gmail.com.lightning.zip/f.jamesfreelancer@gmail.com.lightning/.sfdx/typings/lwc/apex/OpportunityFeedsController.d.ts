declare module "@salesforce/apex/OpportunityFeedsController.getOpportunityFeeds" {
  export default function getOpportunityFeeds(param: {cId: any, recId: any}): Promise<any>;
}
