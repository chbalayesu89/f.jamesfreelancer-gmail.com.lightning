declare module "@salesforce/apex/DropboxUIController.getParentFoldersAndFiles" {
  export default function getParentFoldersAndFiles(param: {foldername: any}): Promise<any>;
}
declare module "@salesforce/apex/DropboxUIController.createFolder" {
  export default function createFolder(param: {folderpath: any}): Promise<any>;
}
declare module "@salesforce/apex/DropboxUIController.listFolder" {
  export default function listFolder(param: {folderpath: any}): Promise<any>;
}
declare module "@salesforce/apex/DropboxUIController.getFoldersAndFiles" {
  export default function getFoldersAndFiles(param: {foldername: any}): Promise<any>;
}
