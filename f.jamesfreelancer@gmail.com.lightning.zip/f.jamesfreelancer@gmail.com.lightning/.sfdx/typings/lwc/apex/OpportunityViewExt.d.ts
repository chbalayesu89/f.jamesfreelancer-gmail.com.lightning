declare module "@salesforce/apex/OpportunityViewExt.getOpportunityFeeds" {
  export default function getOpportunityFeeds(param: {oppId: any}): Promise<any>;
}
