declare module "@salesforce/apex/checklistController.getChecklist" {
  export default function getChecklist(param: {aid: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.dltcheckList" {
  export default function dltcheckList(param: {checkList: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.UpdateCheckList" {
  export default function UpdateCheckList(param: {Id: any, checklist: any, notes: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.saveChecklist" {
  export default function saveChecklist(param: {chk: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.editsaveChecklist" {
  export default function editsaveChecklist(param: {chklist: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.deleteCheckList" {
  export default function deleteCheckList(param: {chkId: any, caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/checklistController.getChecklistOptions" {
  export default function getChecklistOptions(param: {csId: any}): Promise<any>;
}
