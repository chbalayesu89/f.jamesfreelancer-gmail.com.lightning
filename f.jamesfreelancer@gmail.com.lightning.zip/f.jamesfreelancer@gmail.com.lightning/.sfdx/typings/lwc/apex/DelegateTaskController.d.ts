declare module "@salesforce/apex/DelegateTaskController.saveDelegatedTask" {
  export default function saveDelegatedTask(param: {p_dtask: any}): Promise<any>;
}
