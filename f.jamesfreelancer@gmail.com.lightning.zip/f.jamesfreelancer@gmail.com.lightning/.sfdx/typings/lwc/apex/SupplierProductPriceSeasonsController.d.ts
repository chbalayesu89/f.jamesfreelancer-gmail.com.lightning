declare module "@salesforce/apex/SupplierProductPriceSeasonsController.getPriceSeason" {
  export default function getPriceSeason(param: {psId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceSeasonsController.savePriceSeason" {
  export default function savePriceSeason(param: {ps: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceSeasonsController.updatePriceSeason" {
  export default function updatePriceSeason(param: {ps: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceSeasonsController.deletePriceSeason" {
  export default function deletePriceSeason(param: {psId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceSeasonsController.getPriceSeasonByStatus" {
  export default function getPriceSeasonByStatus(param: {p_status: any, p_spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceSeasonsController.getSupplierProduct" {
  export default function getSupplierProduct(param: {spId: any}): Promise<any>;
}
