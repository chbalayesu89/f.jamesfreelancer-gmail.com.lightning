declare module "@salesforce/apex/SobjectLookupController.getIconDetails" {
  export default function getIconDetails(param: {objectName: any}): Promise<any>;
}
declare module "@salesforce/apex/SobjectLookupController.getSearchedArray" {
  export default function getSearchedArray(param: {objName: any, searchTerm: any}): Promise<any>;
}
