declare module "@salesforce/apex/ObjectHierarchy_ComponentController.getObjectHierarchyData" {
  export default function getObjectHierarchyData(param: {recordId: any, nameFieldAPIName: any, parentFieldAPIName: any, fieldsToDisplay: any, hierarchyLevel: any}): Promise<any>;
}
