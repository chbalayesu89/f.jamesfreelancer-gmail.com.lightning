declare module "@salesforce/apex/CaseFeedsController.getCaseFeeds" {
  export default function getCaseFeeds(param: {cId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseFeedsController.getCase2" {
  export default function getCase2(param: {csId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseFeedsController.getCase" {
  export default function getCase(param: {csId: any}): Promise<any>;
}
