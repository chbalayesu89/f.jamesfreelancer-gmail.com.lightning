declare module "@salesforce/apex/XEROErrorMessageCtrl.getErrorMessage" {
  export default function getErrorMessage(param: {p_recordId: any}): Promise<any>;
}
