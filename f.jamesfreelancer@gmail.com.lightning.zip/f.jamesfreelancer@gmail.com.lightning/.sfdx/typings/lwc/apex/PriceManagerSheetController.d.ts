declare module "@salesforce/apex/PriceManagerSheetController.getPriceManagerlist" {
  export default function getPriceManagerlist(param: {pmsId: any}): Promise<any>;
}
declare module "@salesforce/apex/PriceManagerSheetController.savePriceManagerlist" {
  export default function savePriceManagerlist(param: {p_pmsId: any, pmliststr: any}): Promise<any>;
}
declare module "@salesforce/apex/PriceManagerSheetController.deltePriceManagerById" {
  export default function deltePriceManagerById(param: {pmid: any}): Promise<any>;
}
declare module "@salesforce/apex/PriceManagerSheetController.add5moreAction" {
  export default function add5moreAction(param: {pmlist: any}): Promise<any>;
}
declare module "@salesforce/apex/PriceManagerSheetController.saveRoomwiseprices" {
  export default function saveRoomwiseprices(param: {spId: any, rwplist: any}): Promise<any>;
}
