declare module "@salesforce/apex/Opp2CaseB1B2Controller.saveCaseRecord" {
  export default function saveCaseRecord(param: {p_oppId: any, p_milestoneList: any}): Promise<any>;
}
declare module "@salesforce/apex/Opp2CaseB1B2Controller.getOpportunity" {
  export default function getOpportunity(param: {p_recordId: any}): Promise<any>;
}
