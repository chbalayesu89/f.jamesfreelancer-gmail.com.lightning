declare module "@salesforce/apex/LeadFeedsController.getLeadFeeds" {
  export default function getLeadFeeds(param: {leadId: any}): Promise<any>;
}
