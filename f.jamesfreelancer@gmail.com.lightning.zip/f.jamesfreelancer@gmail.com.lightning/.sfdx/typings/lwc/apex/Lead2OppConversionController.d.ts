declare module "@salesforce/apex/Lead2OppConversionController.setOpportunity" {
  export default function setOpportunity(param: {leadId: any}): Promise<any>;
}
declare module "@salesforce/apex/Lead2OppConversionController.saveOpportunity" {
  export default function saveOpportunity(param: {opp: any}): Promise<any>;
}
