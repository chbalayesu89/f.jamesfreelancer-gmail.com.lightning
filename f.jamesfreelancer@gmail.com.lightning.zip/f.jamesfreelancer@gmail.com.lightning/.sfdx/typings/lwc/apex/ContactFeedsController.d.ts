declare module "@salesforce/apex/ContactFeedsController.getContactFeeds" {
  export default function getContactFeeds(param: {conId: any}): Promise<any>;
}
