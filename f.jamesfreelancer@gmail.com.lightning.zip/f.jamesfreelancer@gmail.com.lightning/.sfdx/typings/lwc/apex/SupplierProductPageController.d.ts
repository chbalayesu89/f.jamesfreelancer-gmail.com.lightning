declare module "@salesforce/apex/SupplierProductPageController.getSupplierProduct" {
  export default function getSupplierProduct(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPageController.saveItemContent" {
  export default function saveItemContent(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPageController.getDocslist" {
  export default function getDocslist(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPageController.getItemContent" {
  export default function getItemContent(param: {icId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPageController.deleteItemContent" {
  export default function deleteItemContent(param: {icId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPageController.updateItemContent" {
  export default function updateItemContent(param: {itc: any}): Promise<any>;
}
