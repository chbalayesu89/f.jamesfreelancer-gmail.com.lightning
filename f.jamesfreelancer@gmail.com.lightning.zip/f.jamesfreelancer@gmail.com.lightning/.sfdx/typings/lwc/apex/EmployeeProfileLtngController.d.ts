declare module "@salesforce/apex/EmployeeProfileLtngController.getEmployeeProfile" {
  export default function getEmployeeProfile(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/EmployeeProfileLtngController.createTargetRecord" {
  export default function createTargetRecord(param: {tg: any, empId: any}): Promise<any>;
}
declare module "@salesforce/apex/EmployeeProfileLtngController.getEmployeeProfileForStaff" {
  export default function getEmployeeProfileForStaff(param: {userId: any}): Promise<any>;
}
