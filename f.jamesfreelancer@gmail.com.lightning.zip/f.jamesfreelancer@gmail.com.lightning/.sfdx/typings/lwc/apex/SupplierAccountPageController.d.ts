declare module "@salesforce/apex/SupplierAccountPageController.checkRecordType" {
  export default function checkRecordType(param: {rtypeId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierAccountPageController.saveSupplierAccount" {
  export default function saveSupplierAccount(param: {acc: any, rTypeId: any}): Promise<any>;
}
