declare module "@salesforce/apex/ContactGraphicVisualController.getContact" {
  export default function getContact(param: {conId: any}): Promise<any>;
}
