declare module "@salesforce/apex/LeadPageController.checkRecordType" {
  export default function checkRecordType(param: {rtypeId: any}): Promise<any>;
}
declare module "@salesforce/apex/LeadPageController.saveLead" {
  export default function saveLead(param: {led: any, rTypeId: any}): Promise<any>;
}
