declare module "@salesforce/apex/LHQuotePageLinkController.getOpportunityId" {
  export default function getOpportunityId(param: {p_recordId: any}): Promise<any>;
}
