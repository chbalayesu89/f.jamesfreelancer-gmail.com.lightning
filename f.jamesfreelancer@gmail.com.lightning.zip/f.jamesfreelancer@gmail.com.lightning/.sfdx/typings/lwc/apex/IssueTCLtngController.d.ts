declare module "@salesforce/apex/IssueTCLtngController.saveIssueTC" {
  export default function saveIssueTC(param: {tcoptionname: any, caseId: any}): Promise<any>;
}
