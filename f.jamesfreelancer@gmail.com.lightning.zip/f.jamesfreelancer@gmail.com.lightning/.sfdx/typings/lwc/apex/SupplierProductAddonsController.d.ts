declare module "@salesforce/apex/SupplierProductAddonsController.saveAddonDetails" {
  export default function saveAddonDetails(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductAddonsController.editAddonDetails" {
  export default function editAddonDetails(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductAddonsController.delAddonDetails" {
  export default function delAddonDetails(param: {itcstrId: any, itmId: any}): Promise<any>;
}
