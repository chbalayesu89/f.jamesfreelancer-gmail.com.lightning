declare module "@salesforce/apex/SupplierProductContentController.saveItemContent" {
  export default function saveItemContent(param: {itcstr: any, itmId: any}): Promise<any>;
}
