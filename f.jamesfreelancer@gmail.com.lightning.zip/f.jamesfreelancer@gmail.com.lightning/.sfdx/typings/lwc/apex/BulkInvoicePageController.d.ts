declare module "@salesforce/apex/BulkInvoicePageController.getAccountWrapper" {
  export default function getAccountWrapper(param: {p_accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/BulkInvoicePageController.processInvoice" {
  export default function processInvoice(param: {p_bulkinv: any, selectedMilestones: any, selectedDisbursements: any, tcmId: any, selectedCommissionMilestones: any}): Promise<any>;
}
