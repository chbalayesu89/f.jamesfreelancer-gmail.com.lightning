declare module "@salesforce/apex/OneDriveGrantAccessController.getOnedriveUserslist" {
  export default function getOnedriveUserslist(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveGrantAccessController.savePermissionlist" {
  export default function savePermissionlist(param: {p_sfulist: any, p_recordId: any}): Promise<any>;
}
