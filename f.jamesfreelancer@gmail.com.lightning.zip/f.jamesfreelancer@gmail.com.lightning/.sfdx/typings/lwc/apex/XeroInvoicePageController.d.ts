declare module "@salesforce/apex/XeroInvoicePageController.getCaseWrapper" {
  export default function getCaseWrapper(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/XeroInvoicePageController.processInvoice" {
  export default function processInvoice(param: {inv: any, selectedMilestones: any, selectedDisbursements: any, tcmId: any, selectedAdminFee: any, selectedCommissionMilestones: any, region: any}): Promise<any>;
}
