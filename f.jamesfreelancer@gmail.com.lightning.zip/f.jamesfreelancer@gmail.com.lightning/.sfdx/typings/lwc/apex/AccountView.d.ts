declare module "@salesforce/apex/AccountView.getAccountFeeds" {
  export default function getAccountFeeds(param: {accId: any}): Promise<any>;
}
