declare module "@salesforce/apex/CampaignHierarchyController.getCampaignChilds" {
  export default function getCampaignChilds(param: {p_cmpId: any}): Promise<any>;
}
