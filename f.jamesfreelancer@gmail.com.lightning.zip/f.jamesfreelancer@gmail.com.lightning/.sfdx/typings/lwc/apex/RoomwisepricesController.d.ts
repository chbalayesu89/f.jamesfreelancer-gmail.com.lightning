declare module "@salesforce/apex/RoomwisepricesController.getRoomwiseprices" {
  export default function getRoomwiseprices(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/RoomwisepricesController.saveRoomwiseprices" {
  export default function saveRoomwiseprices(param: {spId: any, rwplist: any}): Promise<any>;
}
