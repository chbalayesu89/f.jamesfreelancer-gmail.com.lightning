declare module "@salesforce/apex/OneDriveAppController.loadFiles" {
  export default function loadFiles(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.addOnedriveFolder" {
  export default function addOnedriveFolder(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.getOneDriveFolder" {
  export default function getOneDriveFolder(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.listFiles" {
  export default function listFiles(param: {odf: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.saveUploads" {
  export default function saveUploads(param: {recordId: any, uploadedFiles: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.getFolderName" {
  export default function getFolderName(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.shareWithAllLHGlobalUsers" {
  export default function shareWithAllLHGlobalUsers(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.shareFolderWithUsers" {
  export default function shareFolderWithUsers(param: {p_recordId: any, p_selectedUsers: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.getselectOptions" {
  export default function getselectOptions(): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.loadFolder" {
  export default function loadFolder(param: {p_driveId: any, p_Id: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.sendRequestForShare" {
  export default function sendRequestForShare(param: {p_odf: any, p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.getOnedriveUsers" {
  export default function getOnedriveUsers(): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.removeAllPermissions" {
  export default function removeAllPermissions(param: {p_odf: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.removeAccessAction" {
  export default function removeAccessAction(param: {p_recordId: any, p_selectedUsers: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.dogetOneDriveFolder" {
  export default function dogetOneDriveFolder(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OneDriveAppController.getOneDrivePermission" {
  export default function getOneDrivePermission(param: {p_recordId: any, p_odf: any}): Promise<any>;
}
