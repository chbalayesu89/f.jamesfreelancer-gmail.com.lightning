declare module "@salesforce/apex/IssueQuoteLtngController.getIqWrapper" {
  export default function getIqWrapper(param: {oppId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuoteLtngController.createIssueQuote" {
  export default function createIssueQuote(param: {opp: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuoteLtngController.saveIssueQuote" {
  export default function saveIssueQuote(param: {oppId: any, iq: any, p_opp: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuoteLtngController.getOpportunity" {
  export default function getOpportunity(param: {recId: any}): Promise<any>;
}
