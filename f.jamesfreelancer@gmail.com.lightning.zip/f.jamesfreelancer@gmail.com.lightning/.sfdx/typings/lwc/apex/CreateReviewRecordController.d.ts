declare module "@salesforce/apex/CreateReviewRecordController.getReviewRecord" {
  export default function getReviewRecord(param: {rId: any}): Promise<any>;
}
declare module "@salesforce/apex/CreateReviewRecordController.saveReviewRecord" {
  export default function saveReviewRecord(param: {rdata: any}): Promise<any>;
}
