declare module "@salesforce/apex/SupplierProductDetailsController.getSupplierProduct" {
  export default function getSupplierProduct(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductDetailsController.deleteSupplierProduct" {
  export default function deleteSupplierProduct(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductDetailsController.setCloneSupplierProduct" {
  export default function setCloneSupplierProduct(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductDetailsController.cancelCloneSupplierProduct" {
  export default function cancelCloneSupplierProduct(param: {cspId: any}): Promise<any>;
}
