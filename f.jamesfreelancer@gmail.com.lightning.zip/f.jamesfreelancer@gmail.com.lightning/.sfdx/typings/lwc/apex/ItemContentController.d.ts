declare module "@salesforce/apex/ItemContentController.getItemContent" {
  export default function getItemContent(param: {icId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.setFeaturedImage" {
  export default function setFeaturedImage(param: {dpfId: any, parentId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.saveItemContent" {
  export default function saveItemContent(param: {itc: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.saveUploads" {
  export default function saveUploads(param: {recordId: any, uploadedFiles: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.addOnedriveFolder" {
  export default function addOnedriveFolder(param: {p_recordId: any, accId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.listFiles" {
  export default function listFiles(param: {odf: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.deleteItemContent" {
  export default function deleteItemContent(param: {icId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.deleteImagefromOnedrive" {
  export default function deleteImagefromOnedrive(param: {p_itemId: any, p_driveId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.createOnedriveFolder" {
  export default function createOnedriveFolder(param: {p_accId: any, p_spId: any, p_itcId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemContentController.addContentFolder" {
  export default function addContentFolder(param: {p_odf: any, p_itcId: any}): Promise<any>;
}
