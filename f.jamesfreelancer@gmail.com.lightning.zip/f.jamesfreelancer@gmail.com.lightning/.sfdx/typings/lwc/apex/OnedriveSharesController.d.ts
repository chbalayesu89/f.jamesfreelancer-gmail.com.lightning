declare module "@salesforce/apex/OnedriveSharesController.getFolders" {
  export default function getFolders(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OnedriveSharesController.loadFiles" {
  export default function loadFiles(param: {p_recordId: any, p_folderId: any}): Promise<any>;
}
declare module "@salesforce/apex/OnedriveSharesController.listFiles" {
  export default function listFiles(param: {odf: any}): Promise<any>;
}
declare module "@salesforce/apex/OnedriveSharesController.addOnedriveFolder" {
  export default function addOnedriveFolder(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/OnedriveSharesController.saveUploads" {
  export default function saveUploads(param: {recordId: any, uploadedFiles: any}): Promise<any>;
}
declare module "@salesforce/apex/OnedriveSharesController.shareFolderWithUser" {
  export default function shareFolderWithUser(param: {p_shareId: any, p_recordId: any}): Promise<any>;
}
