declare module "@salesforce/apex/AccountFeedController.getAccountFeeds" {
  export default function getAccountFeeds(param: {accId: any}): Promise<any>;
}
