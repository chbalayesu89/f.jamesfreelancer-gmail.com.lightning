declare module "@salesforce/apex/TrackActivityOnCampaignController.saveTimeService" {
  export default function saveTimeService(param: {campaignId: any, ts: any}): Promise<any>;
}
