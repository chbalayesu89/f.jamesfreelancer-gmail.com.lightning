declare module "@salesforce/apex/addDeleteController.saveContacts" {
  export default function saveContacts(param: {ListContact: any}): Promise<any>;
}
