declare module "@salesforce/apex/AddfinancialactualdataController.getTargetRecord" {
  export default function getTargetRecord(param: {tId: any}): Promise<any>;
}
declare module "@salesforce/apex/AddfinancialactualdataController.saveTargetRecord" {
  export default function saveTargetRecord(param: {tdata: any}): Promise<any>;
}
declare module "@salesforce/apex/AddfinancialactualdataController.saveFAD" {
  export default function saveFAD(param: {fadata: any}): Promise<any>;
}
