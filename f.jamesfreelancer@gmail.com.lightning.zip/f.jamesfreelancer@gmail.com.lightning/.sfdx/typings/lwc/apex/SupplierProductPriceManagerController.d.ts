declare module "@salesforce/apex/SupplierProductPriceManagerController.saveRoomwiseprices" {
  export default function saveRoomwiseprices(param: {spId: any, rwplist: any, pmlist: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceManagerController.doManagePrice" {
  export default function doManagePrice(param: {spId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductPriceManagerController.deletepmselected" {
  export default function deletepmselected(param: {delpmlist: any}): Promise<any>;
}
