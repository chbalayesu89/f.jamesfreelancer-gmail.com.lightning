declare module "@salesforce/apex/SupplierProductRoomtypeController.getRoomType" {
  export default function getRoomType(param: {rtId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.saveRoomType" {
  export default function saveRoomType(param: {rt: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.deleteRoomType" {
  export default function deleteRoomType(param: {rtId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.saveboardbasisAction" {
  export default function saveboardbasisAction(param: {spId: any, roomonly: any, catering: any, bandb: any, hb: any, fb: any, fullyinclusive: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.addRoomType" {
  export default function addRoomType(param: {rt: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.saveRoomwiseprices" {
  export default function saveRoomwiseprices(param: {rtId: any, rwplist: any, pmlist: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.doManagePrice" {
  export default function doManagePrice(param: {rtId: any}): Promise<any>;
}
declare module "@salesforce/apex/SupplierProductRoomtypeController.deletepmselected" {
  export default function deletepmselected(param: {delpmlist: any}): Promise<any>;
}
