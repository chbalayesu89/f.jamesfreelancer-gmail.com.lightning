declare module "@salesforce/apex/select2TestCtrl.getselectOptions" {
  export default function getselectOptions(): Promise<any>;
}
declare module "@salesforce/apex/select2TestCtrl.saveAccount" {
  export default function saveAccount(param: {acc: any}): Promise<any>;
}
