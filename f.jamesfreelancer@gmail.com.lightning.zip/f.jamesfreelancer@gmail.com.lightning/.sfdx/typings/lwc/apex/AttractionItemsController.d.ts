declare module "@salesforce/apex/AttractionItemsController.saveAttractionItemDetails" {
  export default function saveAttractionItemDetails(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/AttractionItemsController.editAttractionItemDetails" {
  export default function editAttractionItemDetails(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/AttractionItemsController.delAttractionItemDetails" {
  export default function delAttractionItemDetails(param: {itcstrId: any, itmId: any}): Promise<any>;
}
