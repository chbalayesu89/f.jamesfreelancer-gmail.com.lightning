declare module "@salesforce/apex/IssueQuotePageController.getQuoteWrapper" {
  export default function getQuoteWrapper(param: {p_recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.saveAttractionToDay" {
  export default function saveAttractionToDay(param: {attId: any, dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.removeAttractionFromDay" {
  export default function removeAttractionFromDay(param: {attId: any, dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getContentLibrary" {
  export default function getContentLibrary(param: {dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.saveContentLibrary" {
  export default function saveContentLibrary(param: {imglinks: any, dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getIssueQuoteDay" {
  export default function getIssueQuoteDay(param: {dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.updateIssueQuoteDay" {
  export default function updateIssueQuoteDay(param: {iqd: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.deleteIssueQuoteDay" {
  export default function deleteIssueQuoteDay(param: {dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.addIssueQuoteDay" {
  export default function addIssueQuoteDay(param: {quoteId: any, iqd: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.saveQuoteDetails" {
  export default function saveQuoteDetails(param: {iq: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getAccpmList" {
  export default function getAccpmList(param: {p_dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getAttpmList" {
  export default function getAttpmList(param: {p_dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getRespmList" {
  export default function getRespmList(param: {p_dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getCarHire" {
  export default function getCarHire(param: {p_dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.saveCostingData" {
  export default function saveCostingData(param: {p_accpmList: any, p_attpmList: any, p_respmList: any, p_carHire: any, dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getAttractionList" {
  export default function getAttractionList(param: {dayId: any}): Promise<any>;
}
declare module "@salesforce/apex/IssueQuotePageController.getDPMTotalCost" {
  export default function getDPMTotalCost(param: {dpm: any}): Promise<any>;
}
