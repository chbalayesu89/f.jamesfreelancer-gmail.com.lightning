declare module "@salesforce/apex/CalenderClass.getAllEvents" {
  export default function getAllEvents(): Promise<any>;
}
declare module "@salesforce/apex/CalenderClass.saveCalendarMeeting" {
  export default function saveCalendarMeeting(param: {p_cm: any, p_maList: any}): Promise<any>;
}
declare module "@salesforce/apex/CalenderClass.getMeetingDetails" {
  export default function getMeetingDetails(param: {p_meetingId: any}): Promise<any>;
}
