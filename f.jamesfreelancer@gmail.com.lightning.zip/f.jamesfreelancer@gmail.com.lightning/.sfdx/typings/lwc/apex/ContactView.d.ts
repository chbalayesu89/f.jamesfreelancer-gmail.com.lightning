declare module "@salesforce/apex/ContactView.getContactFeeds" {
  export default function getContactFeeds(param: {conId: any}): Promise<any>;
}
