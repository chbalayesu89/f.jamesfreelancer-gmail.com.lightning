declare module "@salesforce/apex/CampaignTimeservicelistController.gettslist" {
  export default function gettslist(param: {cmpId: any}): Promise<any>;
}
