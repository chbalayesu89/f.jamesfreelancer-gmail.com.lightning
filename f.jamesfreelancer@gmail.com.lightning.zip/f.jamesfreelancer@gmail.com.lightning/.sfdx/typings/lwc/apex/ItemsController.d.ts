declare module "@salesforce/apex/ItemsController.getItem" {
  export default function getItem(param: {ItemId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.deleteItem" {
  export default function deleteItem(param: {ItemId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.setCloneItem" {
  export default function setCloneItem(param: {itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.cancelCloneItem" {
  export default function cancelCloneItem(param: {cItmId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.addRoomType" {
  export default function addRoomType(param: {rt: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.getRoomType" {
  export default function getRoomType(param: {rtId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.saveRoomType" {
  export default function saveRoomType(param: {rt: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.deleteRoomType" {
  export default function deleteRoomType(param: {rtId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.setPriceSeason" {
  export default function setPriceSeason(param: {itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.cancelPriceSeason" {
  export default function cancelPriceSeason(param: {psId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.saveItemContent" {
  export default function saveItemContent(param: {itcstr: any, itmId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.saveboardbasisAction" {
  export default function saveboardbasisAction(param: {itmid: any, roomonly: any, catering: any, bandb: any, hb: any, fb: any, fullyinclusive: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.getPriceSeason" {
  export default function getPriceSeason(param: {psId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.savePriceSeason" {
  export default function savePriceSeason(param: {ps: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.deletePriceSeason" {
  export default function deletePriceSeason(param: {psId: any}): Promise<any>;
}
declare module "@salesforce/apex/ItemsController.getPriceSeasonByStatus" {
  export default function getPriceSeasonByStatus(param: {p_status: any, p_ItemId: any}): Promise<any>;
}
