declare module "@salesforce/apex/CaseQuickActions.getDisburseMoneyURL" {
  export default function getDisburseMoneyURL(param: {caseId: any}): Promise<any>;
}
